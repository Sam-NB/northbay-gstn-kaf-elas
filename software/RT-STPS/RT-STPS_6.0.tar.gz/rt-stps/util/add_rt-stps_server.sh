#!/bin/bash
# An RT-STPS utility script for adding new RT-STPS JSW server instances on Linux.
# See printUsageAndExit for required arguments and usage examples
#
######################################################################################
# Variables
######################################################################################
# First, find out where we are
case $0 in
         /*)  SHELLFILE=$0 ;;
		./*)  SHELLFILE=${PWD}${0#.} ;;
        ../*) SHELLFILE=${PWD%/*}${0#..} ;;
          *)  SHELLFILE=$(type -P "$0") ; if [ "${SHELLFILE:0:1}" != "/" ]; then SHELLFILE="${PWD}/$SHELLFILE" ; fi ;;
esac

# readlink -m makes sure SHELLDIR is a simple absolute path
SHELLDIR=`readlink -m "${SHELLFILE%/*}"`

# So the RT-STPS root directory should be one directory above
RTSTPS_HOME="$SHELLDIR/.."

# And the templates for JSW configurations is in the same directory
TEMPLATE_HOME="$SHELLDIR/DRL_templates"

######################################################################################
# Functions:
######################################################################################
# Complain and exit function

function printUsageAndExit () {
	echo "Usage:"
	echo "  add_rt-stps_server.sh"
	echo "REQUIRED parameters:"
	echo "  servername <Desired name for the new RT-STPS JSW server instance, in double-quotes > \\ "
	echo "  dataport <Desired port number for telemetry data input > \\ "
	echo "  rmiport <Desired port number for Java RMI for the new server instance > \\ "
	echo "  controlport <Desired port number for the new server instance's alternate server interface > \\ "
	echo ""
	echo "Example usage:"
	echo "  ./add_rt-stps_server.sh servername \"rtstps2\" dataport 4900 rmiport 4901 controlport 4902"
	echo ""
	echo "WARNING - The following values are reserved for the default RT-STPS server instance and may NOT be used"
	echo "for additional, non-default instances:"
	echo "servername: \"A\", port numbers: 1099, 4935, 5935"
	exit 1
}

function printUsage () {
	echo "WARNING - The following values are reserved for the default RT-STPS server instance and may NOT be used for additional, non-default instances:"
	echo "server name: \"A\", port numbers: 1099, 4935, 5935"
}

######################################################################################
# Script starts here:
######################################################################################
# Initialize the input parameters
servername=""
dataport=""
rmiport=""
controlport=""

# Parse the input arguments
while [[ "$1" != "" ]]; do
	key="$1"
	shift
	value="$1"
	shift
	case "$key" in
		"servername") servername="$value";;
		"dataport") dataport="$value";;
		"rmiport") rmiport="$value";;
		"controlport") controlport="$value";;
	esac
done

# Check if all require arguments were provided, and complain if any are missing
if [ -z "$servername" ] || [ -z "$dataport" ] || [ -z "$rmiport" ] || [ -z "$controlport" ]; then
	echo ""
	echo "ERROR - Not all required arguments were provided:"
	echo "servername=$servername dataport=$dataport rmiport=$rmiport controlport=$controlport"
	printUsageAndExit
fi

# Now check the parameters and see if they use any reserved values. Immediately complain and exit if any do.
defvaluesfound=0
if [ "$servername" == "A" ]; then
	defvaluesfound=1
elif [ "$rmiport" -eq 1099 ] || [ "$rmiport" -eq 4935 ] || [ "$rmiport" -eq 5935 ]; then
	defvaluesfound=1
elif [ "$dataport" -eq 1099 ] || [ "$dataport" -eq 4935 ] || [ "$dataport" -eq 5935 ]; then
	defvaluesfound=1
elif [ "$controlport" -eq 1099 ] || [ "$controlport" -eq 4935 ] || [ "$controlport" -eq 5935 ]; then
	defvaluesfound=1
fi

if [ $defvaluesfound -gt 0 ]; then
	echo ""
	echo "WARNING - Cannot create new server instance; one or more of the provided arguments use values reserved for the default RT-STPS JSW server instance:"
	echo "servername=$servername dataport=$dataport rmiport=$rmiport controlport=$controlport"
	printUsage
	exit 1
fi

# Do not continue if the default RT-STPS JSW server instance is running
RTSTPS_ACTIVE=`"$RTSTPS_HOME/jsw/bin/rt-stps-server.sh" status | grep -c "is running"`
if [ "$RTSTPS_ACTIVE" -gt 0 ]; then
	echo ""
	echo "WARNING - The default RT-STPS JSW server is currently running; please stop the default RT-STPS server before continuing:"
	echo "Command: $RTSTPS_HOME/jsw/bin/rt-stps-server.sh stop"
	exit 1
fi

# Also do not continue if a JSW server instance of the same name is already running
if [ -d "$RTSTPS_HOME/jsw_$servername/" ]; then
	RTSTPS_ACTIVE=`"$RTSTPS_HOME/jsw_$servername/bin/rt-stps-server.sh" status | grep -c "is running"`
	if [ "$RTSTPS_ACTIVE" -gt 0 ]; then
		echo ""
		echo "WARNING - RT-STPS JSW server instance named \"$servername\" is currently running; please stop this RT-STPS server before continuing:"
		echo "Command: $RTSTPS_HOME/jsw_$servername/bin/rt-stps-server.sh stop"
		exit 1
	fi
fi

# Then, check if there are already instances that share the same server name, do not continue if there are
if [ -f "$RTSTPS_HOME/info/server_info_$servername" ]; then
	echo "WARNING - Cannot create new JSW server instance; RT-STPS server instance \"$servername\" already exists!"
	echo "Server info location: $RTSTPS_HOME/info/server_info_$servername"
	exit 1
fi

# Make a recursive copy of RT-STPS's jsw/ directory, but with the new instance's name appended to the end
# 5.9: And then clean up the new copy's jsw/logs directory
if [ ! -d "$RTSTPS_HOME/jsw_$servername" ]; then
	cp -r "$RTSTPS_HOME/jsw" "$RTSTPS_HOME/jsw_$servername"
	rm -f "$RTSTPS_HOME/jsw_$servername/logs/rt-stps-server.log*"
fi

# Copy the filled-out JSW configuration templates into the new instance's jsw conf directory
sed -e "s:<servername>:$servername:g" -e "s:<dataport>:$dataport:g" -e "s:<rmiport>:$rmiport:g" -e "s:<controlport>:$controlport:g" \
"$TEMPLATE_HOME/rt-stps-server64.conf" > "$RTSTPS_HOME/jsw_$servername/conf/rt-stps-server64.conf"

if [ "$?" -ne 0 ]; then
	echo "ERROR - Failed to fill out template for rt-stps-server64.conf"
	exit 1
fi

sed -e "s:<servername>:$servername:g" -e "s:<dataport>:$dataport:g" -e "s:<rmiport>:$rmiport:g" -e "s:<controlport>:$controlport:g" \
"$TEMPLATE_HOME/rt-stps-server32.conf" > "$RTSTPS_HOME/jsw_$servername/conf/rt-stps-server32.conf"

if [ "$?" -ne 0 ]; then
	echo "ERROR - Failed to fill out template for rt-stps-server32.conf"
	exit 1
fi

sed -e "s:<servername>:$servername:g" -e "s:<dataport>:$dataport:g" -e "s:<rmiport>:$rmiport:g" -e "s:<controlport>:$controlport:g" \
"$TEMPLATE_HOME/rt-stps-server64i.conf" > "$RTSTPS_HOME/jsw_$servername/conf/rt-stps-server64i.conf"

if [ "$?" -ne 0 ]; then
	echo "ERROR - Failed to fill out template for rt-stps-server64i.conf"
	exit 1
fi

# Clean up the new instance's jsw logs and pids directory
pushd "$RTSTPS_HOME/jsw_$servername/logs/"
rm -f *.log
popd
pushd "$RTSTPS_HOME/jsw_$servername/pids/"
rm -f *.status
rm -f *.pid
popd

# Create a source-able text file containing this server instance's parameters
echo "servername=$servername" > "$RTSTPS_HOME/jsw_$servername/server_info"
echo "dataport=$dataport" >> "$RTSTPS_HOME/jsw_$servername/server_info"
echo "controlport=$controlport" >> "$RTSTPS_HOME/jsw_$servername/server_info"
echo "rmiport=$rmiport" >> "$RTSTPS_HOME/jsw_$servername/server_info"

# Print out status message
echo "New RT-STPS JSW server instance created at $RTSTPS_HOME/jsw_$servername"
echo "Server instance information can be found at $RTSTPS_HOME/jsw_$servername/server_info"
