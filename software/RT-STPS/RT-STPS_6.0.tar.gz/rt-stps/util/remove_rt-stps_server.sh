#!/bin/bash
# An RT-STPS utility script for stopping and removing additional RT-STPS JSW server instances on Linux.
# See printUsageAndExit for required arguments and usage examples
#
######################################################################################
# Variables
######################################################################################
# First, find out where we are
case $0 in
         /*)  SHELLFILE=$0 ;;
		./*)  SHELLFILE=${PWD}${0#.} ;;
        ../*) SHELLFILE=${PWD%/*}${0#..} ;;
          *)  SHELLFILE=$(type -P "$0") ; if [ "${SHELLFILE:0:1}" != "/" ]; then SHELLFILE="${PWD}/$SHELLFILE" ; fi ;;
esac

# readlink -m makes sure SHELLDIR is a simple absolute path
SHELLDIR=`readlink -m "${SHELLFILE%/*}"`

# So the RT-STPS root directory should be one directory above
RTSTPS_HOME="$SHELLDIR/.."

# And the templates for JSW configurations is in the same directory
TEMPLATE_HOME="$SHELLDIR/DRL_templates"

######################################################################################
# Functions:
######################################################################################
# Complain and exit function

function printUsageAndExit () {
	echo "Usage:"
	echo "  remove_rt-stps_server.sh"
	echo "REQUIRED parameters:"
	echo "  servername <The server name of the RT-STPS JSW server instance to remove, in double-quotes > \\ "
	echo ""
	echo "Example usage:"
	echo "  ./remove_rt-stps_server.sh servername \"rtstps2\""
	echo ""
	exit 1
}

######################################################################################
# Script starts here:
######################################################################################
#Initialize the input parameters
servername=""

# Parse the input arguments
while [[ "$1" != "" ]]; do
	key="$1"
	shift
	value="$1"
	shift
	case "$key" in
		"servername") servername="$value";;
	esac
done

# Check if all require arguments were provided, and complain if any are missing
if [ -z "$servername" ]; then
	echo ""
	echo "ERROR - Not all required arguments were provided:"
	echo "servername=$servername"
	printUsageAndExit
fi

# Make sure user isn't trying to delete the default RT-STPS JSW server instance
if [ "$servername" == "A" ]; then
	echo "ERROR - server name specified is for the default RT-STPS JSW server instance"
	exit 1
fi

# Check if there exists an instance with the given server name. If so, stop and delete it.
if [ -d "$RTSTPS_HOME/jsw_$servername/" ]; then
	# Stop the JSW server instance
	"$RTSTPS_HOME/jsw_$servername/bin/rt-stps-server.sh" stop
	
	# Delete the JSW files for this instance only if the server was stopped successfully
	if [ "$?" -eq 0 ]; then
		# Double check; do a ps aux and make sure it's not running
		sameServerRunning=`ps aux | grep "rt-stps" | grep -c "gov.nasa.gsfc.drl.rtstps.server.TcpServer $servername"`

		# Delete associated files if double check reveals no rogues
		if [ "$sameServerRunning" -eq 0 ]; then
			echo "INFO - Deleting files for RT-STPS server instance \"$servername\""
			rm -rf "$RTSTPS_HOME/jsw_$servername/"
			echo "Done"
		else
			echo ""
			echo "WARNING - Detected a running RT-STPS server instance named \"$servername\"; server may not have been stopped successfully!"
			exit 1
		fi
	else
		echo "WARNING - Non-zero return code for server stop command; server may not have been stopped successfully!"
		exit 1
	fi
else
	echo "ERROR - RT-STPS JSW server named \"$servername\" does not exist!"
	exit 1
fi
