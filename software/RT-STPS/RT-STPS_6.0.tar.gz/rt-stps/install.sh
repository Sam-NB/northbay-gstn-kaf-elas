#!/bin/bash
# DRL standard module install script
# Original template - Bob Bane, DRL, NASA/GSFC

# The usual junk about finding out where we are...
case $0 in
         /*)  SHELLFILE=$0 ;;
		./*)  SHELLFILE=${PWD}${0#.} ;;
        ../*) SHELLFILE=${PWD%/*}${0#..} ;;
          *)  SHELLFILE=$(type -P "$0") ; if [ "${SHELLFILE:0:1}" != "/" ]; then SHELLFILE="${PWD}/$SHELLFILE" ; fi ;;
esac

# readlink -m makes sure SHELLDIR is a simple absolute path
SHELLDIR=`readlink -m "${SHELLFILE%/*}"`

# 6.0: We no longer make references to standalone/IPOPP mode. RT-STPS is not part of IPOPP.
echo "Configuring RT-STPS..."

if [ -f "${SHELLDIR}/../data" ] ; then
	echo "Found file ${SHELLDIR}/../data ... skipping creation of data directory"
elif [ -L "${SHELLDIR}/../data" ] ; then 
	echo "Found symbolic link ${SHELLDIR}/../data ... skipping creation of data directory"
elif [ -d "${SHELLDIR}/../data" ] ; then 
	echo "Found directory ${SHELLDIR}/../data ... skipping creation of data directory"
else
	echo "Making directory: ${SHELLDIR}/../data"
	mkdir "${SHELLDIR}/../data"
fi
    
echo "Configuration complete."
