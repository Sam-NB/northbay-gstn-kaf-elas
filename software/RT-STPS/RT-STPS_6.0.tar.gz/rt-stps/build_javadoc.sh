#!/bin/bash

echo "Building Javadoc"

rm -rf docs/javadoc/*

javadoc -private -d docs/javadoc \
src/gov/nasa/gsfc/drl/rtstps/*.java \
src/gov/nasa/gsfc/drl/rtstps/clients/*.java \
src/gov/nasa/gsfc/drl/rtstps/clients/spooler/*.java \
src/gov/nasa/gsfc/drl/rtstps/core/*.java \
src/gov/nasa/gsfc/drl/rtstps/core/ccsds/*.java \
src/gov/nasa/gsfc/drl/rtstps/core/ccsds/path/*.java \
src/gov/nasa/gsfc/drl/rtstps/core/fs/*.java \
src/gov/nasa/gsfc/drl/rtstps/core/fs/clock/*.java \
src/gov/nasa/gsfc/drl/rtstps/core/output/*.java \
src/gov/nasa/gsfc/drl/rtstps/core/output/hdf5/*.java \
src/gov/nasa/gsfc/drl/rtstps/core/output/hdf5/UnitTest/*.java \
src/gov/nasa/gsfc/drl/rtstps/core/status/*.java \
src/gov/nasa/gsfc/drl/rtstps/core/xstps/*.java \
src/gov/nasa/gsfc/drl/rtstps/core/xstps/pds/*.java \
src/gov/nasa/gsfc/drl/rtstps/library/*.java \
src/gov/nasa/gsfc/drl/rtstps/library/layout/*.java \
src/gov/nasa/gsfc/drl/rtstps/sender/*.java \
src/gov/nasa/gsfc/drl/rtstps/server/*.java \
src/gov/nasa/gsfc/drl/rtstps/testing/*.java \
src/gov/nasa/gsfc/drl/rtstps/viewer/*.java \
src/gov/nasa/gsfc/drl/rtstps/viewer/bulbs/*.java \
src/gov/nasa/gsfc/drl/rtstps/viewer/commands/*.java \
src/gov/nasa/gsfc/drl/rtstps/viewer/path/*.java \
src/gov/nasa/gsfc/drl/rtstps/viewer/status/*.java \
src/gov/nasa/gsfc/drl/rtstps/viewer/tables/*.java

echo "Done."

