/*
Copyright (c) 1999-2007, United States Government, as represented by
the Administrator for The National Aeronautics and Space Administration.
All rights reserved.

Change history:

5.8.1:
	- Deprecated the getMaxPacketCount method as RDRName.java now records that information for
	  each RDR type, and provides a get method for them
*/
package gov.nasa.gsfc.drl.rtstps.core.output.rdr;

import gov.nasa.gsfc.drl.rtstps.core.ccsds.Packet;
import gov.nasa.gsfc.drl.rtstps.Version;
import gov.nasa.gsfc.drl.rtstps.core.RtStpsException;

// 6.0: Necessary imports from java.util
import java.util.Iterator;
import java.util.HashMap;

public class GranuleBoundaryCalculator{

	// 6.0: Static data structure that keeps track of all granule lengths created and registered.
	// Make sure that this map is cleared during a pipeline flush(), to prepare for the next run.
	private final static HashMap<String, Long> granuleLengths = new HashMap<String, Long>();

	// 6.0: This will serve as the access (read/write) lock to the static granule lengths hash map. 
	private final static Object accessLock = new Object();

	/**
	 * 6.0: Insert a CSN/Granule length key/value pair into the granuleLengths static map
	 * @param rdrCSN the collection short name of the RDR to add
	 * @param granLength Long object representing the RDR's granule length in microseconds
	 */
	public static void addGranuleLength(String rdrCSN, Long granLength){
		synchronized(accessLock){
			// 6.0: First check to see if the given CSN is already present
			if(granuleLengths.containsKey(rdrCSN)){
				System.out.println("WARNING - Granule length map already has " + rdrCSN +
									"; replacing previous registration.");
			}

			// 6.0: Add it to the static granule lengths map
			granuleLengths.put(rdrCSN, granLength);
		}
	}

	/**
	 * 6.0: Clear the static granules map
	 */
	public static void clearGranuleLengths(){
		// 6.0: Clear the granule map
		synchronized(accessLock){
			granuleLengths.clear();
			System.out.println("INFO - Granule lengths map successfully cleared.");
		}
	}

	/**
	 * 6.0: Returns the number of granule lengths currently registered in the static map
	 * @return int representing the number of granule lengths currently registered
	 */
	public static int granuleLengthCount(){
		// 6.0: Return the current number of granule lengths in the static map
		int rcount = 0;
		synchronized(accessLock){
			rcount = granuleLengths.size();
		}

		return rcount;
	}

	/*
	* Takes in a RawApplicationPackets object, and calculates its start boundary (in IET time)
	* @param rap the RawApplicationPackets object whose start/end boundary is to be calculated
	* @param boundary value indicating which boundary to be calculated; 0 for start, 1 for end.
	* @return a long representing the boundary in IET time.
	*
	* RT-STPS 5.7: Added support for CERES-SCIENCE-RDR
	*/
	public static long getBoundary(RawApplicationPackets rap, int boundary) throws RtStpsException{
		// First, convert the RawApplicationPackets' first CDS time into IET
		long ietTime =  LeapDate.getMicrosSinceEpoch(rap.getFirstTime());
		RDRName rdrName = rap.getRdrName();

		// 5.7: We can get ALL the granule boundaries now
		// 6.0: Use the generic methods now as the per-case basis for boundary calculation is no longer necessary
		if(boundary == 0)
			return GranuleBoundaryCalculator.getStartBoundary(ietTime, GenericGranule.getBaseTime(), rdrName);
		else
			return GranuleBoundaryCalculator.getEndBoundary(ietTime, GenericGranule.getBaseTime(), rdrName);
	}

	/*
	* Takes in a RawApplicatinPackets, and returns its granule size according to CDFCB/MDFCB/DD documents
	* @param rdrname the RawApplicationPackets whose granule size is to be returned
	*
	* Note: FIXME Legacy method preserved for backwards compatibility. Updated version of the method is 
	* getGranuleSize(RDRName)
	* @return a long representing the granule size in microseconds
	*
	*/
	public static long getGranuleSize( RawApplicationPackets rap ) throws RtStpsException {
		// First get the Raw Application Packet's RDR Name
		RDRName rdrName = rap.getRdrName();

		// 6.0: Use the generic methods now as the per-case basis for granule size is no longer necessary
		return GranuleBoundaryCalculator.getGranuleSize(rdrName);
	}

	/*
	* Takes in an RDRName, and returns its granule size according to CDFCB/MDFCB/DD documents
	* @param rdrname the RDRName whose granule size is to be returned
	* @return a long representing the granule size in microseconds
	*
	* RT-STPS 5.7: Newly-added method
	*/
	public static long getGranuleSize(RDRName rdrname) {
		// RT-STPS 5.7: Granule sizes based on CDFCB-X Vol.II Block 1.2.4
		// RT-STPS 6.0: Dynamic HashMap approach is now used instead of hardcoded cases

		// 6.0: First get the RDR collection short name (CSN) from the provided RDR Name object
		String rdrCSN = rdrname.getShortName();
		if(rdrCSN == null){
			System.out.println("WARNING - GranuleBoundaryCalculator Encountered null argument;" +
								" cannot calculate granule size!" + 
								" Using default granule size of 85.35 seconds");
			return 85350000L;
		}

		// 6.0: Now get the granule length from the map using the RDR short name
		Long granLength = null;
		synchronized(accessLock){
			granLength = granuleLengths.get(rdrCSN);
		}

		// 6.0: If null, use a default value. Otherwise, return the long value
		if(granLength != null){
			return granLength.longValue();
		}
		else{
			System.out.println("WARNING - Unknown RDR " + rdrname.getRDRStringName() + "; Using default granule size of 85.35 seconds");
			return 85350000L;
		}
	}

	public static long adjustedEndBoundary( long startBoundary, long granuleSize, long granuleTimeSpan){
		// Take floor value of granule time span divided by granule size, which will give us the
		// number of complete granules that can fit within granuleTimeSpan. Default value is 1.		
		long numGran = granuleTimeSpan / granuleSize;
		if(numGran < 1L)
			numGran = 1L;

		// Return the adjusted end boundary:
		return ( startBoundary + (numGran * granuleSize) );
	}

	public static long getAdjustedEndBoundary( RawApplicationPackets rap, long granTimeSpan ) throws RtStpsException{
		return adjustedEndBoundary( getBoundary(rap, 0), getGranuleSize(rap), granTimeSpan );
	}

	/**
	* Taken from InfUtil_GranuleID.cpp; these two methods are used to calculate CERES-SCIENCE-RDR
	* granule start/stop boundaries given an arbitrary packet IET time (converted from CDS time)
	* ----------------------------------------------------------------------
	* The following steps calculate the granule ID, granule start time, and
	* granule end time:
	*	1.) Subtract the spacecraft base time from the arbitrary time to obtain
	*		an elapsed time.
	*	2.) Divide the elapsed time by the granule size to obtain the granule number; 
	*		the integer division will give the desired FLOOR value.
	*	3.) Multiply the granule number by the granule size, then add the spacecraft
	*		base time to obtain the granule start boundary time. Add the granule
	*		size to the granule start boundary time to obtain the granule end
	*		boundary time.
	* ----------------------------------------------------------------------
	*/
	public static long getStartBoundary(long arbitraryTime, long baseTime, RDRName rdrname) {
		long granuleSize = GranuleBoundaryCalculator.getGranuleSize(rdrname);
		long elapsedTime = arbitraryTime - baseTime;
		long granuleNumber = elapsedTime / granuleSize;
		long startBoundary = (granuleNumber * granuleSize) + baseTime;
		return startBoundary;
	}

	public static long getEndBoundary(long arbitraryTime, long baseTime, RDRName rdrname) {
		long granuleSize = GranuleBoundaryCalculator.getGranuleSize(rdrname);
		long elapsedTime = arbitraryTime - baseTime;
		long granuleNumber = elapsedTime / granuleSize;

		// Calculate and print granule ID. For logging purposes only
		long granuleIDValue = (granuleNumber * granuleSize) / 100000;
		//System.out.println(rdrname.getRDRStringName() + " granule ID = " + granuleIDValue);

		long startBoundary = (granuleNumber * granuleSize) + baseTime;
		long endBoundary = startBoundary + granuleSize;
		return endBoundary;
	}
}
