/*
Copyright (c) 1999-2007, United States Government, as represented by
the Administrator for The National Aeronautics and Space Administration.
All rights reserved.
*/
package gov.nasa.gsfc.drl.rtstps.core.output.rdr;

import gov.nasa.gsfc.drl.rtstps.core.RtStpsException;


/**
 * A factory class & method for creating specific RDR based on various input parameters.
 * This class is used while processing packets in real time from an input stream.
 * 
 * RT-STPS 5.7: Enabled support for other spacecraft/missions other than S-NPP
 * RT-STPS 6.0 comments:
 *   - This class is used to create specialized RDR objects based on instrument. Preferably,
 *     this class shouldn't exist and all RDR types will use Generic_RDR.java; however, there
 *     are some sensor-specific processing that necessitate some sensors to have their own
 *     specific implementation of RDR.java
 *   - If certain RDR types in the future require a special implementation of RDR.java, make
 *     sure to add them here...
 */
final public class RDRFactory {

	/**
	 * Create the RDR of interest using the supplied argumets.  If no RDR match is found, a default or basic RDR is created 
	 * using this class {@link BasicRDR}
	 * @param anRdrName the RDRName
	 * @param allData the All_Data object
	 * @param dataProducts the DataProducts object
	 * @param spid the spacecraft id (RT-STPS 5.7)
	 * @param dev the DRL domain
	 * @return a specific RDR
	 * @throws RtStpsException wraps any HDF exceptions
	 */
	public static RDR createRDR(RDRName anRdrName,
								AllData allData, 
								DataProducts dataProducts, 
								SpacecraftId spid, 
								FixedDomainDescription dev) throws RtStpsException 
	{
		// RT-STPS 5.7: Added support for CERES-SCIENCE-RDR
		// 6.0: RDR Name is now a class and not enum values; adjust checks appropriately
		if (anRdrName.getShortName().equals("VIIRS-SCIENCE-RDR")) {
			return new VIIRS_RDR_MultiGranule(allData, dataProducts, spid, dev);
		} else if (anRdrName.getShortName().equals("ATMS-SCIENCE-RDR")) {
			return new ATMS_RDR(allData, dataProducts, spid, dev, 12);
		} else if (anRdrName.getShortName().equals("CRIS-SCIENCE-RDR")) {
			return new CRIS_RDR(allData, dataProducts, spid, dev, 4);
		} else if (anRdrName.getShortName().equals("OMPS-LPSCIENCE-RDR")) {
			return new ROLPS_RDR(allData, dataProducts, spid, dev, 4);
		} else if (anRdrName.getShortName().equals("OMPS-NPSCIENCE-RDR")) {
			return new RONPS_RDR(allData, dataProducts, spid, dev, 4);
		} else if (anRdrName.getShortName().equals("OMPS-TCSCIENCE-RDR")) {
			return new ROTCS_RDR(allData, dataProducts, spid, dev, 4);
		} else if (anRdrName.getShortName().equals("CERES-SCIENCE-RDR")) {
			return new RCERS_RDR(allData, dataProducts, spid, dev);
		} else {
			// 5.7: Support for all RDR types using "Generic" RDR
			return new Generic_RDR(allData, dataProducts, spid, dev, anRdrName);
		}
	}

	public static RDR createRDR(Stats stats, 
								RDRName anRdrName, 
								AllData allData, 
								DataProducts dataProducts, 
								SpacecraftId spid, 
								FixedDomainDescription dev) throws RtStpsException 
	{
		// RT-STPS 5.7: Added support for CERES-SCIENCE-RDR
		// RT-STPS 5.7: Added "stats" argument to OMPS RDR creation
		// 6.0: RDR Name is now a class and not enum values; adjust checks appropriately
		if (anRdrName.getShortName().equals("VIIRS-SCIENCE-RDR")) {
			return new VIIRS_RDR_MultiGranule(stats, allData, dataProducts, spid, dev);
		} else if (anRdrName.getShortName().equals("ATMS-SCIENCE-RDR")) {
			return new ATMS_RDR(stats, allData, dataProducts, spid, dev, 12);
		} else if (anRdrName.getShortName().equals("CRIS-SCIENCE-RDR")) {
			return new CRIS_RDR(stats, allData, dataProducts, spid, dev, 4);
		} else if (anRdrName.getShortName().equals("OMPS-LPSCIENCE-RDR")) {
			return new ROLPS_RDR(stats, allData, dataProducts, spid, dev, 4);
		} else if (anRdrName.getShortName().equals("OMPS-NPSCIENCE-RDR")) {
			return new RONPS_RDR(stats, allData, dataProducts, spid, dev, 4);
		} else if (anRdrName.getShortName().equals("OMPS-TCSCIENCE-RDR")) {
			return new ROTCS_RDR(stats, allData, dataProducts, spid, dev, 4);
		} else if (anRdrName.getShortName().equals("CERES-SCIENCE-RDR")) {
			return new RCERS_RDR(stats, allData, dataProducts, spid, dev);
		} else {
			// 5.7: Support for all RDR types using "Generic" RDR
			return new Generic_RDR(stats, allData, dataProducts, spid, dev, anRdrName);
		}
	}

}
