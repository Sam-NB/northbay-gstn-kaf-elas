/*
Copyright (c) 1999-2007, United States Government, as represented by
the Administrator for The National Aeronautics and Space Administration.
All rights reserved.
*/

package gov.nasa.gsfc.drl.rtstps.core.xstps.pds;
import gov.nasa.gsfc.drl.rtstps.core.RtStpsException;

public class PDSGranuleCalculator{

	// S-NPP's base epoch time, used for calculating granule boundaries!
	// TODO: Are these still applicable for JPSS-1?
	// 5.9 Patch 3: This was changed to 1698019200000000 from 1698019234000000 to eliminate a 34-second
	// bias when "granulated" mode PDS are ingested by IPOPP
	private static long baseTime = 1698019200000000L;

	public static void setBaseTime(long newBaseTime){
		baseTime = newBaseTime;
	}

	public static long getBaseTime(){
		return baseTime;
	}

	public static long adjustedEndBoundary(long startBoundary, long granuleSize, long granuleTimeSpan){
		// Take floor value of granule time span divided by granule size, which will give us the
		// number of complete granules that can fit within granuleTimeSpan. Default value is 1.		
		long numGran = granuleTimeSpan / granuleSize;
		if(numGran < 1L)
			numGran = 1L;

		// Return the adjusted end boundary:
		return ( startBoundary + (numGran * granuleSize) );
	}

	/**
	* Taken from InfUtil_GranuleID.cpp; these two methods are used to calculate
	* granule start/stop boundaries given an arbitrary packet IET time (converted from CDS time)
	* ----------------------------------------------------------------------
	* The following steps calculate the granule ID, granule start time, and
	* granule end time:
	*	1.) Subtract the spacecraft base time from the arbitrary time to obtain
	*		an elapsed time.
	*	2.) Divide the elapsed time by the granule size to obtain the granule number; 
	*		the integer division will give the desired FLOOR value.
	*	3.) Multiply the granule number by the granule size, then add the spacecraft
	*		base time to obtain the granule start boundary time. Add the granule
	*		size to the granule start boundary time to obtain the granule end
	*		boundary time.
	* ----------------------------------------------------------------------
	*/
	public static long getStartBoundary(long arbitraryTime, long baseTime, long granuleSize) {
		long elapsedTime = arbitraryTime - baseTime;
		long granuleNumber = elapsedTime / granuleSize;

		long startBoundary = (granuleNumber * granuleSize) + baseTime;
		return startBoundary;
	}

	public static long getEndBoundary(long arbitraryTime, long baseTime, long granuleSize) {
		long elapsedTime = arbitraryTime - baseTime;
		long granuleNumber = elapsedTime / granuleSize;

		long startBoundary = (granuleNumber * granuleSize) + baseTime;
		long endBoundary = startBoundary + granuleSize;
		return endBoundary;
	}
}
