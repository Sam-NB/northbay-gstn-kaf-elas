/*
Copyright (c) 1999-2007, United States Government, as represented by
the Administrator for The National Aeronautics and Space Administration.
All rights reserved.
*/
package gov.nasa.gsfc.drl.rtstps.core.output.rdr;

/**
 * Official designation of the platform shortname
 * RT-STPS 5.7: Updated with JPSS-1/2
 *
 */
public enum PlatformShortName {
	NPP("npp"), 
	N01("n01"), 
	N02("n02"),
	J01("j01"),
	J02("j02"),
	GW1("gw1"),
	SPP("spp"), 
	S01("s01"), 
	S02("s02");

	private String spacecraftID;

	private PlatformShortName(String spacecraftID){
		this.spacecraftID = spacecraftID;
	}

	/**
	 * Return the description of the identifier
	 * @return the description in a String
	 */
	public String getSpacecraftID() {
		return spacecraftID;
	}
}
