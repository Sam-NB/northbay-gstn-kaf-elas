/*
Copyright (c) 1999-2007, United States Government, as represented by
the Administrator for The National Aeronautics and Space Administration.
All rights reserved.
*/
package gov.nasa.gsfc.drl.rtstps.core.output.rdr;

import gov.nasa.gsfc.drl.rtstps.core.RtStpsException;

/**
 * RT-STPS 5.7:
 * The CERES-SCIENCE-RDR specialization of the RDR class which creates the /All_Data/XXX-RDR_All and /Data_Products/XXX-RDR structures.
 * This overrides the createRawApplicationPackets method, the bulk of the work is still done by the base RDR class.
 * 
 * RT-STPS 5.7: Removed definitions of stats in this subclass; stats is now a protected member of RDR.java
 */
public class RCERS_RDR extends RDR {

	private static int scansPerGranule = 100; // default

	/**
	 * Create a new instance of this class for building the RDR structures
	 * @param allData The {@link AllData} object which created the /All_Data structure
	 * @param dataProds The [@link DataProducts} objects which created the /Data_Products structure
	 * @param dev The Development domain is where the processing is being done, although passed in, this is fixed when the instance is created
	 * @throws RtStpsException Wraps HDF library exceptions
	 */
	public RCERS_RDR(AllData allData, DataProducts dataProds, SpacecraftId spid, FixedDomainDescription dev) throws RtStpsException {
		// 6.0: RDR Name is now a class and not an enum value
		super(null, RDRName.fromRDRNameStr("CERES-SCIENCE-RDR"), allData, dataProds, spid, dev);
	}

	public RCERS_RDR(Stats stats, AllData allData, DataProducts dataProds, SpacecraftId spid, FixedDomainDescription dev) throws RtStpsException {
		// 6.0: RDR Name is now a class and not an enum value
		super(stats, RDRName.fromRDRNameStr("CERES-SCIENCE-RDR"), allData, dataProds, spid, dev);
	}

	/**
	 * Create the specific {@link RCERSRawApplicationPackets}, this overrides the base RDR method
	 * @return RawApplicationPackets returns the instance as a generic {@link RawApplicationPackets} object
	 */
	protected RawApplicationPackets createRawApplicationPackets(RDRName rdrName) {
		RawApplicationPackets rap = new RCERSRawApplicationPackets(stats, spid, getSetNum(), scansPerGranule, getPacketPool());
		this.getRaps().push(rap);
		return rap;
	}
}
