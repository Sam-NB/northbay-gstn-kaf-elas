/*
Copyright (c) 1999-2007, United States Government, as represented by
the Administrator for The National Aeronautics and Space Administration.
All rights reserved.
*/

package gov.nasa.gsfc.drl.rtstps.core.xstps.pds;

import gov.nasa.gsfc.drl.rtstps.core.ccsds.Packet;
import gov.nasa.gsfc.drl.rtstps.core.output.rdr.LeapDate;

import java.io.BufferedOutputStream;
import java.io.DataOutput;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;

import java.util.Iterator;
import java.util.HashMap;
import java.util.TreeMap;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.ArrayDeque;
import java.util.Set;

import java.lang.Integer;
import java.lang.Long;
import java.lang.Boolean;

/**
 * Internal class that represents one construct for a "scan"
 */
public class ScanConstruct {

	// Keeps track of expected no. of APIDs, and number of "completed" APIDs
	protected int numAPIDs;
	protected int fullGroupAPIDs = 0;

	// Key is APID, value is an arraylist of packet payloads for that APID.
	// This is made a tree map so that APID packets may be written to file
	// in the correct APID numerical order:
	private TreeMap<Integer, ScanPacketWrapper> APIDs;

	// Hash map to keep track of each APID's completion status
	private HashMap<Integer, Boolean> APIDStatus;

	/**
	 * Constructor
	 */
	public ScanConstruct(int numapids){
		numAPIDs = numapids;
		APIDs = new TreeMap<Integer, ScanPacketWrapper>();
		APIDStatus = new HashMap<Integer, Boolean>();
	}

	/**
	 * Put a packet in this scan construct
	 */
	public void putPacket(Packet p){
		// This packet's APID:
		Integer papid = Integer.valueOf(p.getApplicationId());

		// Add new entry for this APID if it's not registered in the maps yet
		if(!APIDs.containsKey(papid)){
			APIDs.put(papid, new ScanPacketWrapper());
			APIDStatus.put(papid, Boolean.valueOf(false));
		}

		// Copy the packet's byte payload into this APID's total byte payload, only
		// if this APID has not satisfied the "completion" condition yet:
		boolean apidstatus = APIDStatus.get(papid).booleanValue();
		if(!apidstatus){
			APIDs.get(papid).addData(p.getData(), p.getSize());
		}

		// Now check if this packet was either a Standalone or Last packet:
		//   - If Standalone (sequence flag: 3), this satisfies the "completion" condition
		//   - If Last (sequence flag: 2) and we have a scan time established from a First
		//     packet, then this satisfies the "completion" condition
		int seqFlag = p.getSequenceFlags();
		if(seqFlag > 1 && !apidstatus){
			APIDStatus.put(papid, Boolean.valueOf(true));
			fullGroupAPIDs++;
		}
	}

	/**
	 * Function to determine if all APID groups are complete. The "completion" condition
	 * for a single APID is as follows:
	 *    - A group is completed (First, n-Middle, and Last packets)
	 *    - Packet for the APID is Standalone
	 * If all APIDs are deemed complete, then the whole scan construct is also complete
	 */
	public boolean isComplete(){
		return (numAPIDs > 0) && (fullGroupAPIDs >= numAPIDs);
	}

	/**
	 * Function to write this scan's packets to file, in proper APID numerical/temporal order
	 */
	public void flushToFile(OutputStream osm){
		// VIIRS Science PDS special case: write APID 826 (engineering) packets first
		if(APIDs.containsKey(Integer.valueOf(826))){
			ScanPacketWrapper spw = APIDs.remove(Integer.valueOf(826));
			try{
				if(spw != null){
					byte[] pktpayload = spw.getData();
					osm.write(pktpayload, 0, pktpayload.length);
				}
			}
			catch(IOException ioe){
				System.out.println("ERROR - IOException encountered during APID 826 " + 
									"packet write to PDS file!");
			}
			spw.flushData();
		}

		// Iterate through the ascending-order keys of the tree map, and
		// write the actual packet data into the file 
		Set<Integer> apidkeys = APIDs.keySet();
		for(Integer apidkey : apidkeys){
			ScanPacketWrapper spw = APIDs.get(apidkey);
			try{
				if(spw != null){
					byte[] pktpayload = spw.getData();
					osm.write(pktpayload, 0, pktpayload.length);
				}
			}
			catch(IOException ioe){
				System.out.println("ERROR - IOException encountered during APID " + 
										apidkey.intValue() + "packet write to PDS file!");
			}
			spw.flushData();
		}

		// This scan construct has been written to file. Clean up
		APIDs.clear();
		APIDStatus.clear();
	}
}
