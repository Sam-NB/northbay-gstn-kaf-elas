/*
Copyright (c) 1999-2007, United States Government, as represented by
the Administrator for The National Aeronautics and Space Administration.
All rights reserved.
*/

package gov.nasa.gsfc.drl.rtstps.core.output.rdr;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FilenameFilter;
import java.io.IOException;
import java.nio.charset.Charset;

/* 5.9: The new static Leapsec class */
import gov.nasa.gsfc.drl.rtstps.core.Leapsec;

import gov.nasa.gsfc.drl.rtstps.core.output.rdr.PDSDate.MissionCal;

/**
 * Add leap seconds calculation to PDSDates
 * @author krice
 *
 */
public class LeapDate extends PDSDate {
	private static final long TAILeap = 10L;  // 10 seconds added in 1972
	private MissionCal adjCal = new MissionCal(); // leap adjusted
	private long adjPacketTime;  // leap adjusted
	private long adjDay;  // leap adjusted
	private long adjMillis; // leap adjusted
	private long adjMicros; // leap adjusted
	//private static long staticLeapsecCount = 0;
	
	public LeapDate(long packetTime) {
		super(packetTime);
		
		// locally calculate the packetTime's micros
		long micros = PDSDate.getMicrosSinceEpoch(packetTime);
		
		//System.out.println("micros from super -- " + micros);

		/* 5.9: Use the new Leapsec class for leapsec calculations */
		//long leap = TAILeap + leapsSince72(super.getDaySegment());
		long leap = getLeapsecs(super.getDaySegment(), 
								super.getMillisSegment(),
								super.getMicrosSegment());

		micros += (leap * MicrosPerSecond);
				
		adjDay = micros / MicrosPerDay;
		
		micros = micros - (adjDay * MicrosPerDay);
		
		adjMillis = ( micros / 1000L);
		
		adjMicros = micros - (adjMillis * 1000L);
		
		adjPacketTime =   ((adjDay << 48)    & 0xffff000000000000L);
		adjPacketTime |= ((adjMillis << 16)  & 0x0000ffffffff0000L);
		adjPacketTime |=  (adjMicros         & 0x000000000000ffffL);
	
		calendar(adjDay, adjMillis, adjMicros, adjCal);
	}
	

	public LeapDate(int year, int month, int day, int hour, int minute, int second, int milliseconds, int microseconds) {		
		super(year, month, day, hour, minute, second, milliseconds, microseconds);
		
		// locally calculate the packetTime's micros
		long rawDays = super.getDaySegment();
		long rawMillis = super.getMillisSegment();
		long rawMicros = super.getMicrosSegment();
		
		long micros = rawDays * MicrosPerDay;
		micros += rawMillis * 1000L;
		micros += rawMicros;
		
		/* 5.9: Use the new Leapsec class for leapsec calculation */
		//long leap = TAILeap + leapsSince72(rawDays);
		long leap = getLeapsecs(rawDays, rawMillis, rawMicros);
		
		micros += (leap * MicrosPerSecond);
		
		adjDay = micros / MicrosPerDay;
		
		micros = micros - (adjDay * MicrosPerDay);
		
		adjMillis = ( micros / 1000L);
		
		adjMicros =  micros - (adjMillis * 1000L);
		
		adjPacketTime =   ((adjDay << 48)    & 0xffff000000000000L);
		adjPacketTime |= ((adjMillis << 16)  & 0x0000ffffffff0000L);
		adjPacketTime |=  (adjMicros         & 0x000000000000ffffL);
	
		
		calendar(adjDay, adjMillis, adjMicros, adjCal);
		
	}

	


	/**
	 * Return the 64-bit timestamp adjusted by leap seconds
	 * @return long
	 */
	public long getPacketTime() {
		return adjPacketTime;
	}
	
	/**
	 * Get the day segment from the packet time which may have been leap adjusted
	 * @return a long
	 */
	public long getDaySegment() {
		return adjDay;
	}
	
	/**
	 * Get the milliseconds segment from the packet time which may have been leap adjusted
	 * @return a long
	 */
	public long getMillisSegment() {
		return adjMillis;
	}
	
	/**
	 * Get the microseconds segment from the packet time which may have been leap adjusted
	 * @return a long
	 */
	public long getMicrosSegment() {
		return adjMicros;
	}
	
	/**
	 * Get the calculated month of the year
	 * @return a long
	 */
	public long getMonth() {
		return adjCal.month;
	}
	/**
	 * Get the calculated year, four digits
	 * @return a long
	 */
	public long getYear() {
		return adjCal.year;
	}
	/**
	 * Get the calculated day of month
	 * @return an integer
	 */
	public long getDayOfMonth() {
		return adjCal.day;
	}
	/**
	 * Get the calculated day of the year
	 * @return an integer
	 */
	public long getDayOfYear() {
		return adjCal.dayOfYear;
	}
	/**
	 * Get the calculated milliseconds of second
	 * @return a long
	 */
	public long getMilliseconds() {
		return adjCal.milliseconds;
	}
	
	/**
	 * Get any remaining microseconds of millisecond
	 * @return a long
	 */
	public long getMicroseconds() {
		return adjCal.microseconds;
	}
	/**
	 * Get the calculated seconds of minute
	 * @return a long
	 */
	public long getSeconds() {
		return adjCal.seconds;
	}
	/**
	 * Get the calculated minutes of hour
	 * @return a long
	 */
	public long getMinutes() {
		return adjCal.minutes;
	}
	/**
	 * Get the calculated hours of day
	 * @return a long
	 */
	public long getHours() {
		return adjCal.hours;
	}
	
	/**
	 * Remove the leaps segments by recalculating it based on the day segment value
	 * and remove it, and remaking a new PDSDate.
	 * @param dateTime
	 * @return a new PDSDate
	 */
	public static PDSDate removeLeap(PDSDate dateTime) {
		long daySegment = dateTime.getDaySegment();

		/* 5.9: Use the new Leapsec class for leapsec calculations */
		//long leap = TAILeap + leapsSince72(daySegment);
		long leap = getLeapsecs(daySegment,
								dateTime.getMillisSegment(),
								dateTime.getMicrosSegment());

		long micros = dateTime.getMicrosSinceEpoch() - (leap * MicrosPerSecond);
		
		long daySeg = micros / MicrosPerDay;
		
		micros = micros - (daySeg * MicrosPerDay);
		
		long millisSeg = ( micros / 1000L);
		
		long microsSeg =  micros - (millisSeg * 1000L);
		
		long packetTime =   ((daySeg << 48)    & 0xffff000000000000L);
		packetTime |= ((millisSeg << 16)  & 0x0000ffffffff0000L);
		packetTime |=  (microsSeg         & 0x000000000000ffffL);

		return new PDSDate(packetTime);
	}

	/**
	* Removes leap seconds from an IET time and converts it to a PDSDate
	* object.
	*/
	public static PDSDate ietToPDSNoLeap(long arbIET){
		// Compute the pre-leapsec removal day segment
		long ietTime = arbIET;
		long tempDaySegment = (ietTime / MicrosPerDay);

		// Subtract leap seconds from arbitrary IET time
		/* 5.9: Slightly more complicated; first convert IET to PDSDate, then use the 
		   PDSDate methods to get rawDay/Millis/Micros */
		//long leap = TAILeap + leapsSince72(tempDaySegment);
		PDSDate tempPDS = PDSDate.ietToPDS(arbIET);
		long leap = getLeapsecs(tempPDS.getDaySegment(),
								tempPDS.getMillisSegment(),
								tempPDS.getMicrosSegment());

		ietTime = ietTime - ( leap * MicrosPerSecond );

		// Compute day segment, subtract from total
		long eqDaySegment = (ietTime / MicrosPerDay);
		ietTime = ietTime - (eqDaySegment * MicrosPerDay);

		// Compute the millisecond segment, subtract from total; remains are micros. segment.
		long eqMillisSegment = ( ietTime / MicrosPerMillis );
		long eqMicrosSegment = ietTime - (eqMillisSegment * MicrosPerMillis);

		long packetTime =   ((eqDaySegment << 48)    & 0xffff000000000000L);
		packetTime |= ((eqMillisSegment << 16)  & 0x0000ffffffff0000L);
		packetTime |=  (eqMicrosSegment         & 0x000000000000ffffL);

		return new PDSDate(packetTime);
	}
	
	/**
	 * Static variation given a 64-bit mission time (segmented)
	 * @param packetTime 48 bits of time, 16 bits millis and 16 bits of micros
	 * @return the micros since epoch in a signed 64-bit quantity
	 */
	public static long getMicrosSinceEpoch(long packetTime) {
		long daySegment = (packetTime >> 48) & 0x0ffffL;
		long millisSegment = (packetTime >> 16) & 0x0ffffffffL;
		long microsSegment = packetTime & 0x0ffffL;

		long millis = (daySegment * MillisPerDay) + millisSegment; 

		/* 5.9: Use the new Leapsec class to calculate leapsecs */
		//long leap = TAILeap + leapsSince72(daySegment);
		long leap = getLeapsecs(daySegment, millisSegment, microsSegment);

		millis += (leap * 1000L);
		
		long micros = (millis * 1000L) + microsSegment;

		return micros;
	}

	/**
     * 5.9: Finds the latest leapsec file in the root directory and initializes
	 * the Leapsec static class
     */
	private static void initializeLeapsec() {
		/* 5.9: Find all the leapsec files in the root directory by using a FilenameFilter
		   that accepts filenames starting with "leapsec" and ending with "dat" */
		File rootDirectory = new File("./");
		String leapsecPath = "";
		int numLeapsecFiles = 0;

		File[] rootDirectoryFiles = rootDirectory.listFiles(new FilenameFilter(){
			public boolean accept(File dir, String name)
			{
				if(name.startsWith("leapsec") && name.endsWith("dat"))
					return true;
				else
					return false;
			}
		});

		/* 5.9: Get the absolute path of the latest leapsec file, which should be the
		   last file in the File array */
		numLeapsecFiles = rootDirectoryFiles.length;
		if(numLeapsecFiles > 0){
			leapsecPath = rootDirectoryFiles[numLeapsecFiles-1].getAbsolutePath();
		}
		else{
			System.out.println("ERROR - No leapsec files found in RT-STPS root directory!");
			System.exit(1);
		}

		/* 5.9: Now initialize the Leapsec static class with latest leapsec file */
		if(Leapsec.setLeapsec(leapsecPath) != 0){
			System.out.println("ERROR - Error during leapsec file initialization!");
			System.exit(1);
		}
	}

	/**
     * 5.9: Given raw day/millis/micros, calculate the number of relevant leap seconds
	 * using the initialized Leapsec static class
	 *
	 * @param rawday long representing raw days from CCSDS packet time
	 * @param rawmillis long representing raw milliseconds from CCSDS packet time
	 * @param rawmicros long representing raw microseconds from CCSDS packet time
	 * @return long representing the number of relevant leap seconds
     */
	private static long getLeapsecs(long rawday, long rawmillis, long rawmicros){
		if(!Leapsec.isLoaded()){
			System.out.println("INFO - Initializing leapsec file");
			initializeLeapsec();
		}
		return Leapsec.calcLeapsecs(rawday, rawmillis, rawmicros);
	}
}
