/*
	Copyright (c) 1999-2007, United States Government, as represented by
	the Administrator for The National Aeronautics and Space Administration.
	All rights reserved.
*/
package gov.nasa.gsfc.drl.rtstps;
import gov.nasa.gsfc.drl.rtstps.core.Builder;
import gov.nasa.gsfc.drl.rtstps.core.Configuration;
import gov.nasa.gsfc.drl.rtstps.core.RtStpsException;
import gov.nasa.gsfc.drl.rtstps.core.RtStpsNode;
import gov.nasa.gsfc.drl.rtstps.core.ccsds.PacketReceiver;
import gov.nasa.gsfc.drl.rtstps.core.status.StatusItem;

import gov.nasa.gsfc.drl.rtstps.core.ccsds.Packet;
import gov.nasa.gsfc.drl.rtstps.core.ccsds.PacketI;
import gov.nasa.gsfc.drl.rtstps.core.output.rdr.PacketFactoryI;
import gov.nasa.gsfc.drl.rtstps.core.output.rdr.PDSDate;
import gov.nasa.gsfc.drl.rtstps.core.output.rdr.LeapDate;
import gov.nasa.gsfc.drl.rtstps.core.output.rdr.IETTime;

import gov.nasa.gsfc.drl.rtstps.core.output.rdr.tools.*;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileReader;
import java.util.Collection;
import java.util.Iterator;
import java.util.TreeMap;

import org.xml.sax.InputSource;

/**
 * This class is the main entry for the RT-STPS Packet Service Processor. 
 * PacketSerivce is a standalone, comand-line-invoked program that reads 
 * a CCSDS packet file and produces RT-STPS-supported output file types
 * (PDS files, RDR files, etc.)
 * 
 */
public final class PacketDriver
{
	/* Default buffer size for the packet reader is 1024 kB x 100 */
	public static final int BUFFER_SIZE = 1024 * 100;

    public static void main(String[] args){

		/* Complain if not all required arguments were provided */
		if (args.length != 2){
			System.err.println("Options: [-Droot=<stp.dtdDirectory>] [-Dsetup=<directory>] [-Draw=<directory>]");
			System.err.println("Arguments: [setupFile] [dataFile]");
			System.exit(1);
		}

		PacketReceiver fs = null;
		Configuration configuration = null;

		/* Open the configuration file and create a data pipeline from it */
		try{
			/* Open the configuration file */
			String directory = System.getProperty("setup");
			File setupFile = new File(directory,args[0]);
			BufferedReader br = new BufferedReader(new FileReader(setupFile));
			InputSource setup = new InputSource(br);

			/* Get the "root" system property */
			String root = System.getProperty("root", "file://localhost/");

			// 6.0: Make sure to add a file separator at the end of the root to tell
			// this that the root is a path to the top-level RT-STPS directory
			setup.setSystemId(root + File.separator);

			/* Create a Builder from the configuration file, to get a Packet
			   Receiver starting node */
			Builder builder = new Builder();
			fs = builder.createPacketReceiver(setup);
			configuration = builder.getConfiguration();
			br.close();
        }
		catch (java.io.IOException ifnf){
			System.err.println(ifnf.getMessage());
			System.exit(-1);
		}
		catch (RtStpsException be){
			System.err.println(be.getMessage());
			be.printStackTrace();
			System.exit(-2);
		}

		/* The second argument is the absolute path to packet file. Create 
		   the file packet reader object */
		FilePacketReader fpr = null;
		try{
			fpr = new FilePacketReader(new CopyPacketFactory(), args[1]);
		}
		catch (RtStpsException rte){
			System.out.println("ERROR - RT-STPS Exception occurred on initialization!");
			rte.printStackTrace();

			try{
				fs.flush();
			}
			catch(RtStpsException e){
				System.out.println("WARNING - RT-STPS Exception occurred during flush!");
			}

			fs = null;
			System.exit(-3);
		}

		/* Keep reading through the file until EOF is reached; print out packet information
		   in the order that they are read */
		try{
			while(fpr.hasNext()){
				/* Continue if we get a null packet */
				Packet packet = (Packet)fpr.next();
				if(packet == null)
					continue;

				/* Put packet in the Packet Receiver */
				fs.putPacket(packet);
			}

			/* Once done, shutdown the data pipeline */
			try{
				fs.flush();
			}
			catch(RtStpsException e){
				System.out.println("WARNING - RT-STPS Exception occurred during flush!");
			}
		}
		catch(RtStpsException rte){
			System.out.println("ERROR - RT-STPS Exception occurred during processing!");
			rte.printStackTrace();
			fs = null;
		}

		/* Now print out all status items */
		TreeMap<String, RtStpsNode> nodes = configuration.getStpsNodes();
		Iterator<RtStpsNode> i = nodes.values().iterator();
		while (i.hasNext()){
			RtStpsNode node = (RtStpsNode)i.next();
			Collection<StatusItem> status = node.getStatusItems();
			if (status != null){
				System.out.println(node);
				Iterator<StatusItem> ii = status.iterator();
				while (ii.hasNext()){
					StatusItem si = (StatusItem)ii.next();
					System.out.println("    " + si);
				}
			}
		}
	} /* END main() */
}
