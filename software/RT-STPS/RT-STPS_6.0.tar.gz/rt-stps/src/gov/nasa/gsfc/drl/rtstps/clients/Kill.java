/*
Copyright (c) 1999-2007, United States Government, as represented by
the Administrator for The National Aeronautics and Space Administration.
All rights reserved.
*/
package gov.nasa.gsfc.drl.rtstps.clients;
import gov.nasa.gsfc.drl.rtstps.server.RtStpsServices;

/**
 * A program to terminate the server.
 * 
 */
public class Kill
{
    public static void main(String args[])
    {
        String host = (args.length > 0)? args[0] : "localhost";

		// 5.7F: Add RMI registry port number as an additional argument
		String rmiPort = (args.length > 2)? args[2] : "1099";

		// 5.7F: Added the RMI port no. so RMI URL now look like:
		// "rmi://host:port/RtStpsServices.ServerName"
        //String target = "//" + host + "/RtStpsServices";
		String target = "//" + host + ":" + rmiPort + "/RtStpsServices";

		// 5.7F: Changed "==" to ">=" to accomodate new argument
        if (args.length >= 2)
        {
            target += "." + args[1];
        }
        

        try
        {
            RtStpsServices server = (RtStpsServices)java.rmi.Naming.lookup(target);
            server.stopServer();
            System.exit(0);
        }
        catch (java.rmi.UnmarshalException uex)
        {
            //normal because the server probably won't answer.
            System.exit(0);
        }
        catch (Exception ex)
        {
            System.err.println("Lookup error. "+target);
            System.err.println(ex);
            System.exit(100);
        }
    }
}
