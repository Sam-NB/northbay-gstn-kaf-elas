/*
Copyright (c) 1999-2007, United States Government, as represented by
the Administrator for The National Aeronautics and Space Administration.
All rights reserved.
*/
package gov.nasa.gsfc.drl.rtstps.core.output.rdr;

import gov.nasa.gsfc.drl.rtstps.core.status.LongStatusItem;

public class Stats {
	// 5.7: Changed the string description for these to accomodate new RDR types
	public LongStatusItem sci_createdGranules = new LongStatusItem("Created Granules");
	public LongStatusItem sci_discardedGranules = new LongStatusItem("Discarded Granules");
	public LongStatusItem sci_freePoolPackets = new LongStatusItem("Free Pool Packets");
	public LongStatusItem sci_createdPackets = new LongStatusItem("Created Packets");
	public LongStatusItem sci_packetsMemory = new LongStatusItem("Packets Memory");
	public LongStatusItem ae_createdGranules = new LongStatusItem("AE Created Granules");
	public LongStatusItem ae_discardedGranules = new LongStatusItem("AE Discarded Granules");
	public LongStatusItem ae_freePoolPackets = new LongStatusItem("AE Free Pool Packets");
	public LongStatusItem ae_createdPackets = new LongStatusItem("AE Created Packets");
	public LongStatusItem ae_packetsMemory = new LongStatusItem("AE Packets Memory");
	public LongStatusItem drop = new LongStatusItem("Unsupported RDR packets");;
}
