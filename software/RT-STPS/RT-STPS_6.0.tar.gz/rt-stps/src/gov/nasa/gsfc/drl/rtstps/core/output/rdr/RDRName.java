/*
Copyright (c) 1999-2007, United States Government, as represented by
the Administrator for The National Aeronautics and Space Administration.
All rights reserved.
*/
package gov.nasa.gsfc.drl.rtstps.core.output.rdr;

import gov.nasa.gsfc.drl.rtstps.core.RtStpsException;

// 6.0: Necessary imports as of RT-STPS 6.0
import java.util.Iterator;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Set;

/**
 * Currently defined RDRs, note that only some of these are actually active by having corresponding concrete {@link RDR}.
 * This can be determined as well by looking at the EnumSet of each -- if its just 'NoName' then the set is not really defined.
 * If the entry has an EnumSet.range then its active and the range are the individual names packets (corresponding to app ids)
 * for that RDR.
 * 
 * TODO: And if any set has (APID) overlaps with another, then that will be a problem...
 *
 * 5.8.1 Notes:
 *  - Number of APIDs per RDR is found in respective Data Dictionaries, under the "numAPIDs" field
 *  - Number of expected packets per RDR is found in respective Data Dictionaries, under the "Pkt Tracker List" field;
 *    the size of the "IngSmdCommon_PktTrackerType" is the number of expected packets/packet trackers per RDR
 *      e.g. IngSmdCommon_PktTrackerType[262] -> expected no. of packets is 262
 *  - If these above values differ based on spacecraft, make sure to handle them as special cases
 */
public class RDRName {

	// 6.0: These are the members of an RDRName object, which are parsed from the XML definitions file
	private String productID;
	private String shortName;
	private String satellite;
	private String sensor;
	private String typeID;
	private int defaultNumPackets;	// 6.0: Number of APIDs
	private int granuleSize;
	private int expectedPackets;	// 6.0: Number of Packet Trackers (per granule)

	// 6.0: Legacy value
	public static int ApplicationPacketCount = 100;

	// 6.0: Data structure that keeps a record of all packets belonging to this RDR type.
	// A LinkedHashMap is used because some RDRs require APIDs to be listed in a specific order in the
	// APID list, and LinkedHashMap guarantees iteration order based on order of insertion (i.e. APIDs
	// will be inserted on the order they are listed in the XML definitions file).
	private LinkedHashMap<Integer, PacketName> packetsInRDR;

	// 6.0: Static data structure that keeps track of all RDRNames created and registered.
	// Make sure that this map is cleared during a pipeline flush(), to prepare for the next run.
	private final static HashMap<String, RDRName> rdrNames = new HashMap<String, RDRName>();

	// 6.0: This will serve as the access lock to the static RDR names hash map. A thread must have access
	// to this lock before it can read or write the RDR names static hash map.
	private final static Object accessLock = new Object();

	/**
	 * 6.0: Constructor which accepts parameters parsed from the XML definitions file:
	 * @param sensor the Sensor of interest
	 * @param typeID the type ID
	 * @param defaultNumPackets the number of APIDs associated with the RDR
	 * @param packetsInRDR and Set of packets (names) in the RDR
	 * @param granuleSize the granule size is intepreted by each sensor implementation as is appropriate
	 * @param expectedpackets the expected number of packets per granule
	 */
	public RDRName( String productID, String shortName,
					String satellite, String sensor,
					String typeID, int defaultNumPackets,
					int granuleSize, int expectedPackets )
	{
		// 6.0: Initialize the member variables
		this.productID = productID;
		this.shortName = shortName;
		this.satellite = satellite;
		this.sensor = sensor;
		this.typeID = typeID;
		this.defaultNumPackets = defaultNumPackets;
		this.granuleSize = granuleSize;
		this.expectedPackets = expectedPackets;

		// 6.0: Initialize the map for packets in this RDR
		packetsInRDR = new LinkedHashMap<Integer, PacketName>();
	}
	
	/**
	 * 6.0: Return the Product Identifier String
	 * @return a String representing the RDRName's Product Identifier
	 */
	public String getProductID(){
		return productID;
	}

	/**
	 * 6.0: Return the Collection Short Name String
	 * @return a String representing the RDRName's Collection Short Name (CSN)
	 */
	public String getShortName(){
		return shortName;
	}

	/**
	 * 6.0: Return the Satellite name
	 * @return a String representing the RDRName's satellite name
	 */
	public String getSatellite(){
		return satellite;
	}

	/**
	 * Return the granule size
	 * @return an integer value interpreted by the caller
	 */
	public int getGranuleSize() {
		return granuleSize;
	}

	/**
	 * 6.0: Return the sensor as a String
	 * @return the {@link String}
	 */
	public String getSensor() {
		return sensor;
	}
	
	/**
	 * 6.0: Return the Type ID as a String
	 * @return the {@link String}
	 */
	public String getTypeID() {
		return typeID;
	}
	
	/**
	 * Return the default number of APIDs
	 * @return the number of APIDs as an <code>int</code>
	 */
	public int getDefaultNumPackets() {
		return defaultNumPackets;
	}

	/**
	 * 5.8.1: Return the expected number of packets
	 * @return the expected number of packets as an <code>int</code>
	 */
	public int getExpectedPackets() {
		// 6.0: No more need to handle special cases as these are now defined in each spaceraft's unique
		// XML definitions file
		return expectedPackets;
	}

	/**
	 * Count the number of distinct packet (app ids) in the RDR and return that count.
	 * @return int the count of packets (app ids) -- 0 means the RDR is not currently supported.
	 */
	public int getNumberOfAppIdsInRDR() {
		// 6.0: No more need to handle special cases as these are now defined in each spaceraft's unique
		// XML definitions file
		return defaultNumPackets;
	}

	/**
	 * 6.0: Return the map of application packet types for this RDR
	 * @return LinkedHashMap of PacketName objects <code>null</code>
	 */
	public LinkedHashMap<Integer,PacketName> getPacketsInRDR() {
		return packetsInRDR;
	}

	/**
	 * 6.0: Add packet names to this RDRName's packet map
	 * @param packetApid Integer representing the packet APID, used as key
	 * @param packetName PacketName object for the given APID, used as value
	 */
	public void addPacketToRDR(Integer packetApid, PacketName packetName){
		// 6.0: First check if the provided APID is already present in the packet map
		if(packetsInRDR.containsKey(packetApid)){
			System.out.println("WARNING - RDR name " + shortName + 
								"already contains APID " + packetApid.intValue() +
								"; replacing previous registration");
		}

		// 6.0: Now put this apid/packetName key/value pair into this RDRName's packet map
		packetsInRDR.put(packetApid, packetName);
	}

	/**
	 * 6.0: Initialize the RDR names static map by reading the RDRNames.xml file for the
	 * specified satellite name
	 * @param satName String representing RDR collection short name
	 * @param rdrName RDRName object for the given collection short name
	 */
	public static void addRDRName(String rdrCSN, RDRName rdrName){
		synchronized(accessLock){
			// 6.0: First check to see if the given CSN is already present
			boolean hasCSN = rdrNames.containsKey(rdrCSN);

			// 6.0: Give a warning if CSN is already present; it will be overwritten.
			if(hasCSN){
				System.out.println("WARNING - RDR map already has " + rdrCSN +
									"; replacing previous registration.");
			}

			// 6.0: Add it to the static RDR name map
			rdrNames.put(rdrCSN, rdrName);
		}
	}

	/**
	 * 6.0: Clear the static RDR map
	 */
	public static void clearRDRNames(){
		synchronized(accessLock){
			// 6.0: Clear the RDR map
			rdrNames.clear();
			System.out.println("INFO - RDR names map successfully cleared.");
		}
	}

	/**
	 * 6.0: Return the proper RDRName from the given application id
	 * @param appId the application identifier of a packet in the RDR
	 * @return one of RDR short names or <code>null</code>
	 */
	public static RDRName fromAppId(int appId) {
		// 6.0: Call upon PacketName's static method to get the proper RDR key corresponding to the APID.
		// This method should return null if the APID isn't registered.
		String rdrKey = PacketName.getRdrFromAppId(Integer.valueOf(appId));

		// 6.0: Simply return null if the RDR key returned is null
		if(rdrKey == null){
			System.out.println("WARNING - APID not found from registered RDR types: " + appId);
			return null;
		}

		// 6.0: Otherwise, use the obtained key to return the appropriate RDRName
		RDRName returnVal = null;
		synchronized(accessLock){
			returnVal = rdrNames.get(rdrKey);
		}

		// 6.0: Print a little warning if the desired RDR name wasn't found
		if(returnVal == null)
			System.out.println("WARNING - RDR name not found from registered RDR types: " + rdrKey);

		return returnVal;
	}
	
	/**
	 * 6.0: Returns the RDR's collection short name. Functionally the same as getShortName(); this is preserved
	 * for backwards compatibility purposes.
	 * Example: 
	 *   SPACECRAFT-DIARY-RDR, VIIRS-SCIENCE-RDR, etc.
	 * @return the collection short name
	 */
	public String getRDRStringName() {
	    // 6.0: No more need to handle special cases as these are now defined in each spaceraft's unique
		// XML definitions file
		return shortName;
	}

	/**
	 * 6.0: Returns the RDR's collection short name. Functionally the same as getShortName(); this is preserved
	 * for backwards compatibility purposes.
	 * Example: 
	 *   SPACECRAFT-DIARY-RDR, VIIRS-SCIENCE-RDR, etc.
	 * @return the collection short name
	 */
	public String toString() {
		return shortName;
	}

	/**
	 * The counting depth; this is associated with an old implementation and probably
	 * should be deprecated
	 */
	public int getDepth() {
		int depth = 0;

		// 6.0: Get the set of keys for the packets in this RDR
		Set<Integer> packetKeys = packetsInRDR.keySet();

		// 6.0: Iterate through each packet entry and add up the total packet group counts
		for (Integer packetApid : packetKeys) {
			depth += packetsInRDR.get(packetApid).getTotalGroupCount();
		}

		if (depth < ApplicationPacketCount) {
			depth = ApplicationPacketCount;
		}

		return depth;
	}

	/**
	 * 6.0: Given an already existing product name such as SPACECRAFT-DIARY-RDR,
	 * convert that to the appropriate RDRName.
	 * @param rdrNameStr the name of pre-existing RDR item
	 * @throws RtStpsException wraps any HDF exceptions
	 */
	public static RDRName fromRDRNameStr(String rdrNameStr){
		// 6.0: This will return null if the RDR name string is not found
		RDRName returnVal = null;
		synchronized(accessLock){
			returnVal = rdrNames.get(rdrNameStr);
		}

		// 6.0: Print a little warning if the desired RDR name wasn't found
		if(returnVal == null)
			System.out.println("WARNING - RDR name not found from registered RDR types: " + rdrNameStr);

		return returnVal;
	}
	
	/**
	 * 6.0: Iterates through all registered RDRNames and returns the entry with the matching
	 * sensor and type ID
	 * @param sensor the sensor name as a String
	 * @param typeID the Type ID String
	 * @throws RtStpsException wraps any HDF exceptions
	 */
	public static RDRName fromSensorAndTypeID(String sensor, String typeID){
		synchronized(accessLock){
			// 6.0: First get a set of all keys registered
			Set<String> keySet = rdrNames.keySet();

			// 6.0: Now iterate through each entry until the correct one is found
			for(String key : keySet){
				// 6.0: Get the RDRName associated with this key; skip if null
				RDRName rdrname = rdrNames.get(key);
				if(rdrname == null) continue;

				// 6.0: Return this RDRName if it matches the sensor and type ID provided
				String rsensor = rdrname.getSensor();
				String rtypeID = rdrname.getTypeID();

				// 6.0: Do not proceed if either are null
				if(rsensor == null || rtypeID == null) continue;

				// 6.0: Now compare and return this RDRName if sensor and type ID match
				if(rsensor.equals(sensor) && rtypeID.equals(typeID)){
					return rdrname;
				}
			}
		}

		// 6.0: Print a little warning if the desired RDR name wasn't found
		System.out.println("WARNING - " + sensor + " & " + typeID +
							" pair not found from registered RDR types.");

		// 6.0: If nothing is returned after complete iteration, return null
		return null;
	}
	
	/**
	 * 6.0: Iterates through all registered RDRNames and returns the entry with the matching
	 * product identifier (e.g. RNSCA)
	 * @param productIdentifier a String representing the product identifier
	 * @return an RDRName if found, null otherwise
	 * @throws RtStpsException not sure this comes into play, perhaps if its not found it should throw the exception
	 */
	public static RDRName fromProductIdentifier(String productIdentifier){
		synchronized(accessLock){
			// 6.0: First get a set of all keys registered
			Set<String> keySet = rdrNames.keySet();

			// 6.0: Now iterate through each entry until the correct one is found
			for(String key : keySet){
				// 6.0: Get the RDRName associated with this key; skip if null
				RDRName rdrname = rdrNames.get(key);
				if(rdrname == null) continue;

				// 6.0: Return this RDRName if it matches the product ID provided
				String prodid = rdrname.getProductID();

				// 6.0: Do not proceed if null
				if(prodid == null) continue;

				// 6.0: Now compare and return this RDRName if the product ID match
				if(prodid.equals(productIdentifier)){
					return rdrname;
				}
			}
		}

		// 6.0: Print a little warning if the desired RDR name wasn't found
		System.out.println("WARNING - " + productIdentifier + " not found from registered RDR types.");

		// 6.0: If nothing is returned after complete iteration, return null
		return null;
	}
}
