/*
	Copyright (c) 1999-2007, United States Government, as represented by
	the Administrator for The National Aeronautics and Space Administration.
	All rights reserved.
*/
package gov.nasa.gsfc.drl.rtstps.core;

import java.io.RandomAccessFile;
import java.io.IOException;
import java.lang.Double;

/**
 * 5.9: Class that represents a "leapsec.dat" ancillary file; takes in the path
 * to the leapsec file as input, and populates data structures representing
 * the various contents of the leapsec file.
 *
 * This class is intended to be static so the entire RT-STPS data pipeline
 * is able to access. Hence:
 *   - class is final: prevent extensions
 *   - constructor is private: prevent instantiations
 *   - all members/methods are static
 *
 * Since an RT-STPS data pipeline instance only uses one leapsec file at a time,
 * and does not change mid-way, a static implementation of this class makes sense.
 *
 * This class's methods were derived mainly from the SDP Toolkit C code, PGS_TD_LeapSec.c
 */
public final class Leapsec {

	/**
	 * Member variables: all static as this is a static class
	 */

	/* Array for the Julian Day field */
	private static double[] jd;

	/* Array for the leap seconds field */
	private static double[] leapsec;

	/* Array for the base days field */
	private static double[] baseday;

	/* Array for the slopes field */
	private static double[] slope;

	/* Length of the leapsec file (number of leap second entries) */
	private static int leap_len = 0;

	/* Indicates if this class is already (successfully) loaded with a leapsec file */
	private static boolean isloaded = false;

	/**
	 * Default constructor: private as this is a static class
	 */
	private Leapsec(){

	}

	/**
	 * Method to give this class a path to the leapsec file, and
	 * have it populate its members with data from the provided
	 * file.
	 *
	 * @param leapsecPath Sring path to the leapsec file
	 * @return int return status; 0 if successful, > 0 otherwise
	 */
	public static int setLeapsec(String leapsecPath){

		/* Local variables used by this method */
		String nextline = "";
		String stholder = "";
		int nextindex = 0;
		int endindex = 0;
		int leapindex = 0;

		/* Open the leapsec file and complain if unsuccessful */
		RandomAccessFile raFile = null;

		try{
			raFile = new RandomAccessFile(leapsecPath, "r");
				
			/* Extra sanity check to make sure leapsec file was opened properly */
			if(raFile == null){
				System.out.println("ERROR - leapsec file initialization returned null!");
				clearLeapsec();
				return 1;
			}

			/* First we count the number of entries in this leapsec file; leapsec files
			   start with a header line, so read and skip the first line */
			nextline = raFile.readLine();

			while(nextline != null){
				nextline = raFile.readLine();
				if(nextline != null){
					leap_len++;
				}
			}

			/* Now that we know the number of leapsec entries, initialize the members */
			jd = new double[leap_len];
			leapsec = new double[leap_len];
			baseday = new double[leap_len];
			slope = new double[leap_len];

			/* Reset the file pointer back to the start of the file, and read the header line */
			raFile.seek(0);
			nextline = raFile.readLine();

			/* If leapsec file is somehow empty, terminate with an error */
			if(nextline == null){
				System.out.println("ERROR - Null returned when reading leapsec file!" + 
									" Please ensure leapsec file is not empty!");
				clearLeapsec();
				return 1;
			}

			/* Now iterate through every leapsec entry and populate members appropriately; do an
			   initial read outside of the loop to skip past the header line */
			nextline = raFile.readLine();
			while (nextline != null){

				/**********************************************************************************
				 * Parsing Julian Date
				 **********************************************************************************/
				/* Get the index of the Julian Date field, then increment by 3 to get the
				   start index of the actual value */
				nextindex = nextline.indexOf("JD ");

				/* If Julian Date is found, parse value. Otherwise, use default value */
				if(nextindex != -1){
					nextindex += 3;

					/* Get end index of JD, which is the first space encountered at nextindex */
					endindex = nextline.indexOf(" ", nextindex);

					/* Now parse the JD using the next/end indices, and be sure to remove any
					   leading/ending whitespaces */
					stholder = nextline.substring(nextindex, endindex);
					stholder = stholder.trim();

					/* Finally, convert the JD to double and assign to the proper array */
					jd[leapindex] = Double.valueOf(stholder).doubleValue();
				}
				else{
					jd[leapindex] = 0.0;
				}

				/**********************************************************************************
				 * Parsing Leap Seconds
				 **********************************************************************************/
				/* Get the index of the leap second field, then increment by 8 to get the
				   start index of the actual value (there may be leading whitespaces) */
				nextindex = nextline.indexOf("TAI-UTC=");

				/* If leap second is found, parse value. Otherwise, use default value */
				if(nextindex != -1){
					nextindex += 8;

					/* Get end index of leap second, which is the first space encountered at nextindex.
					   In this case, add 5 to nextindex to skip over leading whitespaces. */
					endindex = nextline.indexOf(" ", (nextindex + 5));

					/* Now parse the leap second using the next/end indices, and be sure to remove any
					   leading/ending whitespaces */
					stholder = nextline.substring(nextindex, endindex);
					stholder = stholder.trim();

					/* Finally, convert the leap second to double and assign to the proper array */
					leapsec[leapindex] = Double.valueOf(stholder).doubleValue();
				}
				else{
					leapsec[leapindex] = 0.0;
				}

				/**********************************************************************************
				 * Parsing Base Day
				 **********************************************************************************/
				/* Get the index of the base day field, then increment by 6 to get the
				   start index of the actual value (there may be leading whitespaces) */
				nextindex = nextline.indexOf("MJD - ");

				/* If base day is found, parse value. Otherwise, use default value */
				if(nextindex != -1){
					nextindex += 6;

					/* Get end index of base day, which is the ".)" encountered starting at nextindex. */
					endindex = nextline.indexOf(".)", nextindex);

					/* Now parse the base day using the next/end indices, and be sure to remove any
					   leading/ending whitespaces */
					stholder = nextline.substring(nextindex, endindex);
					stholder = stholder.trim();

					/* Finally, convert the base day to double and assign to the proper array */
					baseday[leapindex] = Double.valueOf(stholder).doubleValue();
				}
				else{
					baseday[leapindex] = 0.0;
				}

				/**********************************************************************************
				 * Parsing Slope
				 **********************************************************************************/
				/* Get the index of the slope field, then increment by 1 to get the
				   start index of the actual value (there may be leading whitespaces) */
				nextindex = nextline.indexOf("X");

				/* If slope is found, parse value. Otherwise, use default value */
				if(nextindex != -1){
					nextindex += 1;

					/* Get end index of slope, which is the "S" encountered starting at nextindex. */
					endindex = nextline.indexOf("S", nextindex);

					/* Now parse the slope using the next/end indices, and be sure to remove any
					   leading/ending whitespaces */
					stholder = nextline.substring(nextindex, endindex);
					stholder = stholder.trim();

					/* Finally, convert the slope to double and assign to the proper array */
					slope[leapindex] = Double.valueOf(stholder).doubleValue();
				}
				else{
					slope[leapindex] = 0.0;
				}

				/* Finally, read in the next line and increment leapsec index*/
				nextline = raFile.readLine();
				leapindex++;
			}

			System.out.println("INFO - The following leap second data have been initialized: ");
			for(int i = 0; i < leap_len; i++){
				System.out.println("INFO - JD: " + jd[i] + " leapsec: " + leapsec[i] + " baseday: " + baseday[i] + " slope: " + slope[i]);
			}
		}
		catch(IOException ioe){
			/* Upon error, complain and null everything */
			System.out.println("ERROR - IO Exception occurred when reading leapsec file!");
			clearLeapsec();
			return 1;
		}

		/* Finally, indicate that this class is successfully loaded then return */
		isloaded = true;
		return 0;
	}

	/**
	 * Method to remove all leapsec information currently registered in
	 * this class; a "clean-up" method.
	 */
	public static void clearLeapsec(){
		System.out.println("INFO - Cleaning up registered leapsec data");
		jd = null;
		leapsec = null;
		baseday = null;
		slope = null;
		leap_len = 0;
		isloaded = false;
	}

	/**
	 * Method that returns this class's status of whether a leapsec file is
	 * loaded or not
	 */
	public static boolean isLoaded(){
		return isloaded;
	}

	/**
     * Given raw day/millis/micros, calculate the number of relevant leap seconds.
	 * Equations are derived from the SDP Toolkit's "TD" source tree, from the
	 * PGS_TD_LeapSec.c C source code
	 *
	 * @param rawday long representing raw days from CCSDS CDS packet time
	 * @param rawmillis long representing raw milliseconds from CCSDS CDS packet time
	 * @param rawmicros long representing raw microseconds from CCSDS CDS packet time
	 * @return long representing the number of relevant leap seconds
     */
	public static long calcLeapsecs(long rawday, long rawmillis, long rawmicros){
		/* EOS Epoch: 1958-01-01 00:00 */
		double EPOCH_DATE = 2436204.5;

		/* milliseconds per day */
		int msPerDay = 86400000;

		/* Indicator of whether input date is on a leap second */
		boolean onLeapSecond = false;

		/* Be sure to check first if the date passed is on a leap second */
		long adjmillis = rawmillis;
		if(rawmillis >= msPerDay){
			adjmillis = rawmillis - 1000;
			onLeapSecond = true;
		}

		/* Calculate the UTC Julian Date fields; based on JD UTC calculations for EOS PM GIIS
		   timestamps from SDP Toolkit's "TD" source code */
		double jdUTC0 = ((double)rawday) + EPOCH_DATE;
		double jdUTC1 = ((double)adjmillis + ((double)rawmicros)/1000.0) / ((double)msPerDay);

		/* Add the two calculated JD UTC values into one number */
		double jdUTCsum = jdUTC0 + jdUTC1;

		/* From SDP Toolkit: "If the Julian day fraction is greater than 0.99, subtract 0.000001 
		   to avoid computer round-off errors to the next Julian day" */
		if((jdUTC1 % 1.0) > 0.99){
			jdUTCsum -= 1.0E-6;
		}

		/* This will contain the calculated leapseconds */
		double leapseconds = 0.0;

		/* Set the leapsec index to start at the latest julian date from the leapsec file */
		int jdIndex = jd.length - 1;

		/* Now, find the first CLOSEST leapsec file entry whose julian date is less than or 
		   equal to the provided date */
		while(jdIndex >= 0){
			if(jd[jdIndex] > jdUTCsum)
				jdIndex--;
			else
				break;
		}

		/* If index goes below zero, no leapsecond entry was found since input date is earlier
		   than the earliest leapsec entry. Hence, don't use leap seconds. */
		if(jdIndex < 0)
			return 0L;

		/* If the relevant leapsec entry contains a non-zero slope, leapsecond has to be calculated
		   using a linear equation. Otherwise, return the leapseconds as is */
		if(slope[jdIndex] == 0.0){
			leapseconds = leapsec[jdIndex];
		}
		else{
			leapseconds = leapsec[jdIndex] + slope[jdIndex] * 
							(jdUTCsum - 2400000.5 - baseday[jdIndex]);
		}

		/* RT-STPS requires leap seconds to be casted to long */
		return (long)leapseconds;
	}
}
