/*
Copyright (c) 1999-2007, United States Government, as represented by
the Administrator for The National Aeronautics and Space Administration.
All rights reserved.
*/

package gov.nasa.gsfc.drl.rtstps.core.output.rdr;
import gov.nasa.gsfc.drl.rtstps.core.RtStpsException;

// 6.0: Imports for reading files
import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileReader;

// 6.0: Imports for XML parsing
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;
import org.xml.sax.SAXParseException;

/**
 * 6.0 This class exists to read in the XML definition files for RDRs, and initialize the
 * dynamic reference classes with the information parsed from the XML definitions files
 * 
 */
public class Definitions {

	// 6.0: Values indicating states for this class
	public final static short NOT_INITIALIZED = 0;
	public final static short INITIALIZED = 1;

	// 6.0: Variables which indicates this class's current state
	private static short currentState = 0;
	private static String currentSat = "";

	// 6.0: Object to serve as a state lock for this class
	private final static Object stateLock = new Object();

	/**
	 * Default Constructor; does nothing
	 */
	public Definitions(){
	}

	/**
	 * Class which initializes all the RDR reference classes
	 * @param satName String the satellite name (platform short name, e.g. NPP, J01, etc)
	 */
	public static void initDefs(String satName){
		synchronized(stateLock){
			// 6.0: If the map is already initialized for the given satellite name, do nothing
			if(currentSat.equals(satName) && currentState == INITIALIZED){
				System.out.println("INFO - RDR definitions already initialized for satellite " + satName);
				return;
			}

			// 6.0: Clear out the reference classes
			RDRName.clearRDRNames();
			PacketName.clearPacketNames();
			GranuleBoundaryCalculator.clearGranuleLengths();

			// 6.0: Initialize a document builder and factory
			DocumentBuilder documentBuilder = null;
			DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
			DefinitionsErrorHandler defErrHandler = new DefinitionsErrorHandler();

			// 6.0: set the properties of the document builder factory. This class does not use a dtd file,
			// so set validating to false
			dbf.setValidating(false);
			dbf.setIgnoringComments(true);
			dbf.setIgnoringElementContentWhitespace(true);

			try{
				documentBuilder = dbf.newDocumentBuilder();
				documentBuilder.setErrorHandler(defErrHandler);
			}
			catch (ParserConfigurationException pce){
				System.err.println(pce.getMessage());
            	System.exit(-1);
			}

			// 6.0: Now load the XML definitions file by using the root system variable and the satellite name
			try{
				// 6.0: Get the RT-STPS root directory
				String root = System.getProperty("root");

				// 6.0: Now get the RDRNames.xml definitions file from the root
				String defsPath = root + File.separator + "data" +  File.separator + "defs" +
								File.separator + satName + File.separator + "RDR_DEFS.xml";

				File defsFile = new File(defsPath);

				// 6.0: Check that this file exists
				if(!defsFile.exists() || !defsFile.isFile()){
					throw new RtStpsException("ERROR - Could not open RDR definitions file " + defsPath);
				}

				// 6.0: Start up a buffered reader and input source for the definitions file
				BufferedReader br = new BufferedReader(new FileReader(defsFile));
				InputSource setup = new InputSource(br);
				setup.setSystemId(root);

				// 6.0: Now parse the definitions files
				Document document = documentBuilder.parse(setup);

				// 6.0: The root element is the top of the document.
				Element rootElement = document.getDocumentElement();
				if (!rootElement.getTagName().equals("RDR_DEFS")) {
					throw new RtStpsException("ERROR - Root element RDR_DEFS for RDR definitions file not found!");
				}

				// 6.0: Parse the satellite name and record it 
				String satellite = rootElement.getAttribute("satellite");
				if(satellite == null || satellite.isEmpty()){
					throw new RtStpsException("ERROR - Root element RDR_DEFS must have the \"satellite\" attribute defined!");
				}
				currentSat = satellite;

				// 6.0: Now iterate through all child nodes and initialize the appropriate classes
				NodeList list = rootElement.getChildNodes();
				int length = list.getLength();

				for (int n = 0; n < length; n++){
					// 6.0: Always do Element checks because newlines are treated as text nodes
					if(list.item(n).getNodeType() == Node.ELEMENT_NODE){
						// 6.0: Get this child node's name and call the appropriate method
						Element element = (Element)list.item(n);
						String id = element.getTagName();

						if(id.equals("RDR_NAMES")){
							initRDRNames(element, satellite);
						}
						else if(id.equals("GRAN_CFG")){
							initGranuleLengths(element, satellite);
						}
						else{
							System.out.println("WARNING - Unknown element from RDR definitions file: " + id);
						}
					}
				}

				// 6.0: Close the buffered reader once done
				br.close();
			}
			catch (SAXException se)
			{
		    	System.err.println(se.getMessage());
            	System.exit(-1);
			}
			catch (java.io.IOException ifnf){
            	System.err.println(ifnf.getMessage());
            	System.exit(-2);
			}
			catch (RtStpsException be){
				System.err.println(be.getMessage());
				be.printStackTrace();
				System.exit(-3);
			}

			// 6.0: Update the current state after initialization
			currentState = INITIALIZED;
			currentSat = satName;
		}
	}

	/**
	 * 6.0: Class which cleans up all the initialized RDR reference classes
	 */
	public static void clearDefs(){
		synchronized(stateLock){
			// 6.0: Do nothing if the maps are already uninitialized
			if(currentState == NOT_INITIALIZED) return;

			// 6.0: Clear the following static maps
			RDRName.clearRDRNames();
			PacketName.clearPacketNames();
			GranuleBoundaryCalculator.clearGranuleLengths();

			// 6.0: Set the state to uninitialized
			currentState = NOT_INITIALIZED;
			currentSat = "";
		}
	}

	/**
	 * 6.0: Class initializes the RDRName.java class
	 * @param root Element object representing the RDR_NAMES element of the XML definitions file
	 */
	private static void initRDRNames(Element element, String satellite) throws RtStpsException{
		// 6.0: Get the child nodes of the RDR_NAMES element
		NodeList rnList = element.getChildNodes();
		int length = rnList.getLength();

		// 6.0: Counters for status messages, number of elements found vs. initialized
		int numElems = 0;
		int numInit = 0;

		// 6.0: Iterate through each RDR Names entry
		for(int c = 0; c < length; c++){
			// 6.0: Always do Element checks because newlines are treated as text nodes
			if(rnList.item(c).getNodeType() == Node.ELEMENT_NODE){
				// 6.0: Get the element from the node list
				Element rname = (Element)rnList.item(c);
				numElems++;

				// 6.0: Make sure this is an RDR Name entry; do not proceed if it isn't
				if(!rname.getTagName().equals("RDRName")) continue;

				/**************************************************************************************
				*   6.0: Create a new RDRName object from this element's attributes; do not proceed if
				*   any attributes are missing:
				***************************************************************************************/
				// 6.0: Parse the RDR's product ID
				String productID = rname.getAttribute("productID");
				if(productID == null || productID.isEmpty()) continue;

				// 6.0: Parse the RDR's collection short name (CSN):
				String csn = rname.getAttribute("csn");
				if(csn == null || csn.isEmpty()) continue;

				// 6.0: Parse the RDR's sensor
				String sensor = rname.getAttribute("sensor");
				if(sensor == null || sensor.isEmpty()) continue;

				// 6.0: Parse the RDR's type ID
				String typeID = rname.getAttribute("typeID");
				if(typeID == null || typeID.isEmpty()) continue;

				// 6.0: Parse the RDR's number of APIDs. The value cannot be zero as that is illogical
				Integer numAPIDs = null;
				try{
					numAPIDs = Integer.valueOf(rname.getAttribute("numAPIDs"));
					if(numAPIDs == null || numAPIDs.intValue() <= 0) continue;
				} 
				catch(NumberFormatException nfe){
					System.out.println("ERROR - non-integer value for numAPIDs attribute encountered!");
					continue;
				}

				// 6.0: Parse the RDR's number of packet trackers. The value cannot be zero as that is illogical
				Integer numPktTrackers = null;
				try{
					numPktTrackers = Integer.valueOf(rname.getAttribute("numPktTrackers"));
					if(numPktTrackers == null || numPktTrackers.intValue() <= 0) continue;
				} 
				catch(NumberFormatException nfe){
					System.out.println("ERROR - non-integer value for numPktTrackers attribute encountered!");
					continue;
				}

				// 6.0: Parse the RDR's granule size. The value cannot be zero as that is illogical
				Integer granSize = null;
				try{
					granSize = Integer.valueOf(rname.getAttribute("granSize"));
					if(granSize == null || granSize.intValue() <= 0) continue;
				} 
				catch(NumberFormatException nfe){
					System.out.println("ERROR - non-integer value for granSize attribute encountered!");
					continue;
				}

				// 6.0: Create the RDRName object that will be added to the class's static map
				RDRName rdrName = new RDRName(productID, csn, satellite,
												sensor, typeID,
												numAPIDs.intValue(),
												granSize.intValue(),
												numPktTrackers.intValue());

				// 6.0: Now register all relevant Packet Names into this RDR Name
				initPacketNames(rname, rdrName);

				// 6.0: Finally, add the RDRName to the static RDRName map
				RDRName.addRDRName(rdrName.getShortName(), rdrName);
				numInit++;
			}
		}

		// 6.0: Print out status messages
		if(numInit != numElems)
			System.out.println("WARNING - RDR Names defined: " + numElems + ", initialized: " + numInit);

		System.out.println("INFO - RDR names map successfully initialized!");
	}

	/**
	 * 6.0: Class that registers Packet Names into an RDR Name, and initializes the PacketName.java class
	 * @param root Element object representing the root element of the XML definitions file
	 * @param rdrName RDRName object to register the Packet Names to
	 */
	private static void initPacketNames(Element element, RDRName rdrName) throws RtStpsException{
		// 6.0: Get the child nodes of the Packet element
		NodeList pnList = element.getChildNodes();
		int length = pnList.getLength();

		// 6.0: Counters for status messages, number of elements found vs. initialized
		int numElems = 0;
		int numInit = 0;

		// 6.0: Iterate through each Packet Names entry
		for(int c = 0; c < length; c++){
			// 6.0: Always do Element checks because newlines are treated as text nodes
			if(pnList.item(c).getNodeType() == Node.ELEMENT_NODE){
				// 6.0: Get the element from the node list
				Element pname = (Element)pnList.item(c);
				numElems++;

				// 6.0: Make sure this is an Packet Name entry; do not proceed if it isn't
				if(!pname.getTagName().equals("Packet")) continue;

				/**************************************************************************************
				*   6.0: Create a new PacketName object from this element's attributes; do not proceed if
				*   any attributes are missing:
				***************************************************************************************/
				// 6.0: Parse the Packet's APID. The value cannot be negative as that is illogical
				Integer apid = null;
				try{
					apid = Integer.valueOf(pname.getAttribute("apid"));
					if(apid == null || apid.intValue() < 0) continue;
				} 
				catch(NumberFormatException nfe){
					System.out.println("ERROR - non-integer value for apid attribute encountered!");
					continue;
				}

				// 6.0: Parse the Packet's short name
				String shortname = pname.getAttribute("apidShortName");
				if(shortname == null || shortname.isEmpty()) continue;

				// 6.0: Parse the Packet's description
				String description = pname.getAttribute("description");
				if(description == null || description.isEmpty()) continue;

				// 6.0: Parse the Packet's total group count. The value cannot be less than 1 as it is illogical
				Integer totalGroupCount = null;
				try{
					totalGroupCount = Integer.valueOf(pname.getAttribute("totalGroupCount"));
					if(totalGroupCount == null || totalGroupCount.intValue() <= 0) continue;
				} 
				catch(NumberFormatException nfe){
					System.out.println("ERROR - non-integer value for totalGroupCount attribute encountered!");
					continue;
				}

				// 6.0: Now create a PacketName object for this packet
				PacketName packetName = new PacketName(shortname, rdrName.getShortName(), description,
														apid.intValue(), totalGroupCount.intValue());

				// 6.0: Add this PacketName to both the RDRName, and the static PacketName map
				rdrName.addPacketToRDR(apid, packetName);
				PacketName.addPacketName(apid, packetName);
				numInit++;
			}
		}

		// 6.0: Print out status messages
		if(numInit != numElems)
			System.out.println("WARNING - Packet names defined: " + numElems + ", initialized: " + numInit);
	}

	/**
	 * 6.0: Class initializes the GranuleBoundaryCalculator.java class
	 * @param root Element object representing the root element of the XML definitions file
	 */
	private static void initGranuleLengths(Element element, String satellite) throws RtStpsException{
		// 6.0: Get the child nodes of the GRAN_CFG element
		NodeList gnList = element.getChildNodes();
		int length = gnList.getLength();

		// 6.0: Counters for status messages, number of elements found vs. initialized
		int numElems = 0;
		int numInit = 0;

		// 6.0: Iterate through each RDR Names entry
		for(int c = 0; c < length; c++){
			// 6.0: Always do Element checks because newlines are treated as text nodes
			if(gnList.item(c).getNodeType() == Node.ELEMENT_NODE){
				// 6.0: Get the element from the node list
				Element glength = (Element)gnList.item(c);
				numElems++;

				// 6.0: Make sure this is a granule entry; do not proceed if it isn't
				if(!glength.getTagName().equals("granule")) continue;

				// 6.0: Parse the RDR collection short name (CSN):
				String csn = glength.getAttribute("csn");
				if(csn == null || csn.isEmpty()) continue;

				// 6.0: Parse the granule length. The value cannot be less than 1 as it is illogical
				Long granuleLength = null;
				try{
					granuleLength = Long.valueOf(glength.getAttribute("length"));
					if(granuleLength == null || granuleLength.longValue() <= 0) continue;
				} 
				catch(NumberFormatException nfe){
					System.out.println("ERROR - non-long value for granuleLength attribute encountered!");
					continue;
				}

				// 6.0: Now add this granule length to the Granule Boundary Calculator
				GranuleBoundaryCalculator.addGranuleLength(csn, granuleLength);
				numInit++;
			}
		}

		// 6.0: Print out status messages
		if(numInit != numElems)
			System.out.println("WARNING - Granule lengths defined: " + numElems + ", initialized: " + numInit);

		System.out.println("INFO - Granule lengths map successfully initialized!");
	}

	/**
	 * 6.0: Error Handler implementation
	 */
	private static class DefinitionsErrorHandler implements org.xml.sax.ErrorHandler {
		/**
		 * Returns a string describing parse exception details
		 */
		private String getParseExceptionInfo(SAXParseException spe){
			String systemId = spe.getSystemId();
			if (systemId == null) systemId = "null";
			String info = "URI=" + systemId + " Line=" + spe.getLineNumber() +
				": " + spe.getMessage();
			return info;
		}

		public void warning(SAXParseException spe) throws SAXException{
			System.err.println("Warning: " + getParseExceptionInfo(spe));
        }

		public void error(SAXParseException spe) throws SAXException{
			String message = "Error: " + getParseExceptionInfo(spe) + "at line #: " + spe.getLineNumber();
			throw new SAXException(message);
		}

		public void fatalError(SAXParseException spe) throws SAXException{
			String message = "Fatal Error: " + getParseExceptionInfo(spe);
			throw new SAXException(message);
		}
	}
}
