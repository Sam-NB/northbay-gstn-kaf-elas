/*
Copyright (c) 1999-2007, United States Government, as represented by
the Administrator for The National Aeronautics and Space Administration.
All rights reserved.
*/
package gov.nasa.gsfc.drl.rtstps.core.output.rdr;

import gov.nasa.gsfc.drl.rtstps.core.RtStpsException;

/**
 * Factory style class to build specific RawAppPackets classes such as VIIRSRawApplicationPackets.
 * At this time this class is only used by Granule when it dereferences to the RawApplicationPacket
 * associated with it.
 * 
 * Typically used in a READ scenario for an already existing RDR file
 *
 */
public class RawApplicationPacketsFactory {

	public static RawApplicationPackets make(int rawAppsId, RDRName rdrName, int granuleNumber) throws RtStpsException {
		// 6.0: RDR Name is now a class and not an enum value
		if (rdrName.getShortName().equals("CRIS-SCIENCE-RDR")) {
			return new CRISRawApplicationPackets(rawAppsId, granuleNumber, true);
		} else if (rdrName.getShortName().equals("ATMS-SCIENCE-RDR")) {
			return new ATMSRawApplicationPackets(rawAppsId, granuleNumber, true);
		} else if (rdrName.getShortName().equals("VIIRS-SCIENCE-RDR")) {
			return new VIIRSRawApplicationPackets(rawAppsId, granuleNumber, true); 
		} else if (rdrName.getShortName().equals("SPACECRAFT-DIARY-RDR")) {
			return new SpacecraftDiaryRawApplicationPackets2(rawAppsId, granuleNumber, true);
		} else {
			// 6.0: For all other cases
			return new GenericRawApplicationPackets(rawAppsId, granuleNumber, true);
		}
		// 6.0: now unreachable
		//return null;
	}

	public static RawApplicationPackets make(RDRName rdrName, int rootGroup, int counter) throws RtStpsException {
		// 6.0: RDR Name is now a class and not an enum value
		if (rdrName.getShortName().equals("CRIS-SCIENCE-RDR")) {
			return new CRISRawApplicationPackets(rootGroup, counter);
		} else if (rdrName.getShortName().equals("ATMS-SCIENCE-RDR")) {
			return new ATMSRawApplicationPackets(rootGroup, counter);
		} else if (rdrName.getShortName().equals("VIIRS-SCIENCE-RDR")) {
			return new VIIRSRawApplicationPackets(rootGroup, counter); 
		} else if (rdrName.getShortName().equals("SPACECRAFT-DIARY-RDR")) {
			return new SpacecraftDiaryRawApplicationPackets2(rootGroup, counter);
		} else{
			// 6.0: For all other cases
			return new GenericRawApplicationPackets(rootGroup, counter);
		}
		// 6.0: now unreachable
		//return null;
	}

	public static RawApplicationPackets makeRandomAccess(RDRName rdrName, int rootGroup, int counter) throws RtStpsException {
		
		return new RawApplicationPacketsRandomAccess(rdrName, rootGroup, counter);

	}
	
}
