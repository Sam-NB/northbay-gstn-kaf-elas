/*
Copyright (c) 1999-2007, United States Government, as represented by
the Administrator for The National Aeronautics and Space Administration.
All rights reserved.
*/
package gov.nasa.gsfc.drl.rtstps.core.xstps.pds;
import gov.nasa.gsfc.drl.rtstps.core.ccsds.Packet;

import java.util.Iterator;

/**
 * This class checks for packet sequence gaps. It collects gap information.
 * 
 * 
 */
class GapList
{
    private Sequencer sequencer;
    private java.util.LinkedList<Item> gaplist;

    /**
     * This class contains information about one gap.
     */
    class Item
    {
		// Packet kernels for tracking gap start/stop CDS times. Expected to have both CDS/ESH times
        PacketKernel prePacket = new PacketKernel();
        PacketKernel postPacket = new PacketKernel();
		
		// NPDS 6.1/6.6: Augmented to keep track of packet ESH time IMMEDIATELY BEFORE/AFTER the gap.
		// Expected to have ESH times, but not necessarily CDS times (from CCSDS secondary header)
		PacketKernel prePacketESH = new PacketKernel();
		PacketKernel postPacketESH = new PacketKernel();

        long datasetOffset = 0;
        int expected = 0;
        int missing = 0;

		// NPDS 6.1/6.6: Augmented to keep track of packet ESH time IMMEDIATELY BEFORE/AFTER the gap
        Item(int missing, PacketKernel current, PacketKernel previous, PacketKernel previousESH, long datasetOffset)
        {
            expected = sequencer.getExpectedNextCount();
            this.missing = missing;

			/* NPDS: Section 6.6 of EDOS ICD states that for gaps in group packets, the packet start/stop
			*  times must contain the first packet time of the group. If the first packet is unavailable,
			*  the preceding group's time is used instead. 
			*
			*  The "previous" passed by Appid is the latest packet it encountered which has a secondary 
			*  header. In the case of grouped packets, this is the "first" packet.
			*/
            prePacket.copy(previous);
			postPacket.copy(current);

			// NPDS 6.1/6.6: Packet ESH time is handled separately; still derived from packets immediately before/after the gap
			prePacketESH.copy(previousESH);
			postPacketESH.copy(current);

            this.datasetOffset = datasetOffset;
        }

		// NPDS 6.6: To allow the creation of a gap Item without calling the Sequencer. Otherwise, the same as the constructor above.
        Item(int expected, int missing, PacketKernel current, PacketKernel previous, PacketKernel previousESH, long datasetOffset)
        {
            this.expected = expected;
            this.missing = missing;

            prePacket.copy(previous);
			postPacket.copy(current);

			prePacketESH.copy(previousESH);
			postPacketESH.copy(current);

            this.datasetOffset = datasetOffset;
        }

		// NPDS: function to allow external modification of prePacket
		void setPrePacket (PacketKernel newprepacket) {
			prePacket.copy(newprepacket);
		}

		// NPDS: function to allow external modification of postPacket
		void setPostPacket (PacketKernel newpostpacket) {
			postPacket.copy(newpostpacket);	
		}
    }

	// NPDS: This linked list represents the latest gap(s) encountered for an Appid
	private java.util.LinkedList<Item> latestGaps;

	// NPDS: For debugging purposes; not actually used in processing
	private int APid = 0;

    /**
     * Create a gap list.
     * @param stepsize A non-zero sequence step size.
     */
    GapList(int stepsize)
    {
        sequencer = new Sequencer(stepsize);
        gaplist = new java.util.LinkedList<Item>();
		
		// NPDS: Initialize the list of "incomplete" gap Items:
		latestGaps = new java.util.LinkedList<Item>();
    }

    /**
     * Get the number of detected gaps.
     */
    final synchronized int getGapCount()
    {
		// NPDS 6.6 fix: Pending gaps are consolidated into one, so only count them as one
		if(latestGaps.size() > 0)
			return (gaplist.size() + 1);
		else
			return gaplist.size();
    }

    /* Developer Note (200X-MM-DD):
       I have a difficult bug in that printCS occasionally throws ConcurrentModificationException.
       This should be impossible because the loop does not modify gaplist, and processing is single
       threaded, so no one else could change it because there is no one else.
       I am synchronizing to collect more information. */

    /**
     * Check a packet for a gap between it and the previous packet.
	 * NPDS 6.1/6.6: Augmented to keep track of packet ESH time IMMEDIATELY before a gap
     * @return true if a gap was detected
     */
    boolean check(Packet packet, PacketKernel current, PacketKernel previous, PacketKernel previousESH, long datasetOffset)
    {
        boolean seeGap = false;
        int missing = sequencer.check(packet);

        if (missing > 0) {
            synchronized (this) {
                Item g = new Item(missing, current, previous, previousESH, datasetOffset);
				
				/* NPDS 6.6 fix: 
				*  If this gap has end time info, or its APID is standalone, it is considered "complete" and can
				*  be safely added to "gaplist"
				*
				*  Note: "||" is used here to handle the special case for housekeeping packets. Some of them are
				*  standalone packets, but do not have a secondary header as would be expected of such packets
				*/
				if (current.getSecHdrFlag() || current.getSequenceFlag() == 3){
					/* 
					   Case 1: gap's APID is a standalone packet. Add it to list of gaps.
					   Note: In this case, completeGapItems occurs BEFORE the add so that
					   if for some reason there is a group gap before this, they are added
					   to gaplist before this new gap and no gaps end up out-of-order 
					*/
					if(current.getSequenceFlag() == 3){
						if(current.getSecHdrFlag())
							completeGapItems(current);
                		gaplist.add(g);
					}
					/* 
					   Case 2: The gap includes a missing "last" packet for the current grouped 
					   packet. It must be inluded in "latestGaps" so that it may be consolidated 
					   with other gaps from the same group.
					   Note: In this case, completeGapItems occurs AFTER the add so that this latest
					   gap is included in the consolidation of all gaps for the grouped packets
					*/
					else{
						latestGaps.add(g);
						if(current.getSecHdrFlag())
							completeGapItems(current);
					}
				}
				/* NPDS 6.6 fix:
				*  Else, this is a gap within a CCSDS grouped packet and does not have gap end time info.
				*  Also, these will need to be consolidated into one big gap, so add it to "latestGaps"
				*  instead for post-processing
				*/
				else {
					latestGaps.add(g);
				}

                seeGap = true;
            }
        }
		else if(current.getSecHdrFlag()) {
			// NPDS 6.6 fix: No gaps for the current packet. Just attempt to complete any pending gaps in 
			// "latestGaps" if "current" contains a secondary header
			synchronized(this){
				completeGapItems(current);
			}
		}

        return seeGap;
    }

	/**
     * NPDS: Provide new packet CDS time information (from the latest "first" packet) to finalize
	 * gap items without complete gap start/stop time information (e.g. gaps
	 * in grouped CCSDS packets), before the next group of packets come in.
	 *
	 * By successfully calling this method, it tells GapList that there are no more gaps
	 * in the current grouped packets (represented by latestGap), and all gap info about
	 * the current group may now be written into the CSR
     */
	synchronized void completeGapItems (PacketKernel postPacketTime){
		// NPDS: Do nothing if there are no "incomplete" gap Items
		if(latestGaps.size() < 1)
			return;

		/* NPDS 6.6 fix: According to the EDOS ICD:
		*  "If there are multiple gaps in the same group, the packets between the first gap and 
		*   the last gap are discarded and only one gap is reported in the construction record." So...
		*/

		// 1.) Remove the first gap from latestGaps
		Item firstGap = latestGaps.remove();

		// 2.) In this case, there are multiple gaps in the same group so consolidate them into one
		if(latestGaps.size() > 0){
			
			// Get the last gap in this group
			Item lastGap = latestGaps.removeLast();

			// Loop through all "middle" gaps in latestGaps to get sum of all missing packets
			int conMissing = 0;
			Iterator<Item> itemIter = latestGaps.iterator();
			while(itemIter.hasNext()){
				Item lgap = (Item)itemIter.next();
				conMissing += lgap.missing;
			}

			// Consolidate all gaps into one, and add it to gaplist
			Item consolidatedGaps = new Item(firstGap.expected,
											(int)(firstGap.missing + conMissing + lastGap.missing),
											postPacketTime, // set the new gap end time
											firstGap.prePacket,
											firstGap.prePacketESH,
											lastGap.datasetOffset); // data offset points to packet immediately after gap
			gaplist.add(consolidatedGaps);
		}
		// 3.) Otherwise, there is only one gap in the group. Set its gap end time before adding to gaplist
		else{
			firstGap.setPostPacket(postPacketTime);
			gaplist.add(firstGap);
		}

		// 4.) Once all consolidation is done, empty latestGaps to prepare for next group
		latestGaps.clear();
	}

	/**
	 * NPDS: Set/Get this GapList's application packet ID. For debugging purposes only
	 */
	public void setAPID (int newAPID){
		APid = newAPID;
	}
	
	public int getAPID () {
		return APid;
	}

    /**
     * Write gap information to the construction record.
     */
    synchronized void printCS(java.io.DataOutput out) throws java.io.IOException
    {
		/* NPDS 6.6 fix: At this point, any pending gaps in latestGaps must be finalized even if
		*  the next expected first packet has not arrived. In this case, according to 6.6:
		*
		*  "...if the first packet time of the group is not available, the construction record will
		*  contain the preceding group time"
		*
		*  So the gap end time that will be used is the preceding group time, which should be contained
		*  in these pending gap Items' "prePacket" member variable:
		*/
		if(latestGaps.size() > 0){
				System.out.println("INFO - APID " + APid + ": Finalizing all remaining pending gap items");
				PacketKernel thefirst = latestGaps.getFirst().prePacket;
				completeGapItems(thefirst);
		}

		// Write each gap information to construction record
        int count = gaplist.size();
        out.writeInt(count);

		//System.out.println("INFO - APID " + APid + ": Detected " + count + " sequence errors");

        Iterator<Item> i = gaplist.iterator();

        while (i.hasNext())
        {
            Item gap = (Item)i.next();
            out.writeInt(gap.expected);
            out.writeLong(gap.datasetOffset);
            out.writeInt(gap.missing);
            out.writeLong(gap.prePacket.getPacketTime());
            out.writeLong(gap.postPacket.getPacketTime());
	
			// NPDS 6.1/6.6: Packet ESH times are decoupled from Packet times
            //out.writeLong(gap.prePacket.getEshTime());
            //out.writeLong(gap.postPacket.getEshTime());
			out.writeLong(gap.prePacketESH.getEshTime());
            out.writeLong(gap.postPacketESH.getEshTime());
        }
    }
}
