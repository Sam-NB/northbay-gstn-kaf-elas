/*
Copyright (c) 1999-2007, United States Government, as represented by
the Administrator for The National Aeronautics and Space Administration.
All rights reserved.
*/
package gov.nasa.gsfc.drl.rtstps.core.output.rdr;

import java.util.EnumSet;

import gov.nasa.gsfc.drl.rtstps.core.RtStpsException;
import gov.nasa.gsfc.drl.rtstps.core.ccsds.Packet;

public class RCERSRawApplicationPackets extends RawApplicationPackets {

	/**
	* The parent class contains long "firstTime" and "lastTime" to keep track of
	* packet CDS times.
	* These here are to keep track of CERES granule boundaries (IET times):
	*/
	private long currentgranule_startboundary = -1L;
	private long currentgranule_endboundary = -1L;

	/**
	* This will be used to keep track of the number of CERES-SCIENCE-RDR packets encountered
	*/
	private int sciPacketCount = 0;

	/**
	* Other member variables
	*/
	private int scansPerGranule;	
	private Stats stats;

	/**
	* The maximum number of packets per CERES Science granule:
	*	- CERES SCIENCE granule size: 660 seconds
	*	- One APID 149 (CERES SCI) packet every 6.6 seconds
	*	- One APID 147 (CERES CAL) packet every 6.6 seconds, but ONLY ON SOLAR CALIBRATION MODE
	*
	* However, it appears that 147 and 149 are never simultaneously produced; it's one or the other,
	* depending on CERES's current science mode
	*/
	private static int CERES_SCIENCE_RDR_MAXPACKETS = 100;

	/**
	 * Constructor for creating an nth instance of a CERES Science raw application data packet area
	 * @param satellite  the name of the spacecraft
	 * @param setNum  the set number
	 */
	public RCERSRawApplicationPackets(SpacecraftId satellite, int setNum, int scansPerGranule, PacketPool packetPool) {
		// 6.0: Treat RDR Name as a class and no longer an enum
		super(satellite, RDRName.fromRDRNameStr("CERES-SCIENCE-RDR"), setNum, packetPool);
		
		if (setNum < 0) {
			throw new IllegalArgumentException("Illegal Index [" + setNum + "]");
		}

		this.scansPerGranule = scansPerGranule;
	}
	
	public RCERSRawApplicationPackets(Stats stats, SpacecraftId satellite, int setNum, int scansPerGranule, PacketPool packetPool) {
		// 6.0: Treat RDR Name as a class and no longer an enum
		super(satellite, RDRName.fromRDRNameStr("CERES-SCIENCE-RDR"), setNum, packetPool);
		
		if (setNum < 0) {
			throw new IllegalArgumentException("Illegal Index [" + setNum + "]");
		}
		
		this.scansPerGranule = scansPerGranule;
		this.stats = stats;
	}
	
	/**
	 * Constructor which attempts to read the RawApplicationPacket entry that pre-exists.
	 * The contents of the dataspace are read into a memory buffer... assuming it will fit.
	 * @param allRDRId  the rdrAll Groups id
	 * @param setNum the set number of raw entry 
	 * @throws RtStpsException 
	 */
	public RCERSRawApplicationPackets(int allRDRId, int setNum) throws RtStpsException {
		super(allRDRId, setNum);
	}
	
	public RCERSRawApplicationPackets(int readId, int setNum, boolean usedByGranuleOnly) throws RtStpsException {
		super(readId, setNum, true);
	}

	/**
	 * (Abstact method implementation)
	 * Determine if the RawApplicationPacket is full or not. 
	 * @param p the packet to be added to the RawApplicationPacket
	 * @return true or false
	 * @throws RtStpsException 
	 */
	public boolean notFull(Packet p) throws RtStpsException {
	
		// 6.0: Removed the rdr name check here as it is redundant (thanks to RDRCreateFile) and may cause race conditions

		// Local variables used for status information
		boolean notFullStatus = true;
		long ietTimeCurrentPacket = 0L;

		// Check if the packet has a secondary header
		if(p.hasSecondaryHeader()) {

			// If yes, obtain CDS time and convert to IET (microseconds). But don't proceed if timestamp is corrupt
			ietTimeCurrentPacket = LeapDate.getMicrosSinceEpoch(p.getTimeStamp(8));

			// TODO: Is this the proper way to check for corrupted packet timestamps?
			if(ietTimeCurrentPacket <= 0){
				System.out.println("INFO - Corrupted CERES-SCIENCE-RDR packet timestamp encountered; not using packet.");
				return notFullStatus;
		    }

			// Calculate the current granule start and end boundaries if they are still undetermined
			if(currentgranule_startboundary < 0) {
				currentgranule_startboundary = RCERSGranule.getStartBoundary(ietTimeCurrentPacket);
				currentgranule_endboundary = RCERSGranule.getEndBoundary(ietTimeCurrentPacket);
			}

			// This RawApplicationPacket is only considered "full" if the latest packet's IET time exceeds the calculated
			// granule boundaries:
			if(ietTimeCurrentPacket >= currentgranule_startboundary && ietTimeCurrentPacket < currentgranule_endboundary)
				notFullStatus = true;
			else			
				notFullStatus = false;
		}

		return notFullStatus;
	}

	/**
	 * (Abstract method implementation)
	 * Put a packet into the RawApplicationPacket after checking if it is full or not.
	 * @param p packet to be written
	 * @throws RtStpsException 
	 */
	public void put(Packet p) throws RtStpsException {

		// Update the APID counters
		this.updateAppIdCounters(p.getApplicationId());

		// 6.0: Removed the rdr name check here as it is redundant (thanks to RDRCreateFile) and may cause race conditions

		// Check if the packet has a secondary header
		if(p.hasSecondaryHeader()) {

			// Record this as the first packet CDS time encountered if "firstTime" is at default
			if (getFirstTime() == 0L) 
				setFirstTime(p.getTimeStamp(8));
			
			// Record this as the latest packet CDS time encountered
			setLastTime(p.getTimeStamp(8));

			// Initialize the first system time, if it's not done so already.
			if (getFirstSystemTime() == 0L) 
				setFirstSystemTime(PDSDate.getCurrentSystemTimeMicrosSinceEpoch());
			
			// Set the latest system time since receiving this science packet
			setLastSystemTime(PDSDate.getCurrentSystemTimeMicrosSinceEpoch());
		}

		/*
		* The packet is then deep copied; it is allocated off a pool
		* which may hold previously copied packets. They must be put
		* back on the pool when done...
		*/
		Packet pcopy = CopyPacket.deep(p, packetPool);
		getPacketList().add(pcopy);
		sciPacketCount++;
	}

	/**
	 * (Override)
	 * Write the collected group of packets to the designated HDF file using the handle
	 * @return true if the RawApplicationPacket was written, false if not
	 * @exception any HDF exceptions are wrapped in an RtStpsException
	 */
	public boolean write(int hdfFile) throws RtStpsException {
		boolean ret = true;
		
		// Calculate the percent missing data for this granule
		float percentMissingData= ( (CERES_SCIENCE_RDR_MAXPACKETS - sciPacketCount) / (float)CERES_SCIENCE_RDR_MAXPACKETS ) * 100;
		if(percentMissingData < 0) {
			System.out.println("INFO - CERES SCI and CAL packets encountered for the same granule");
			percentMissingData = 0.0f;	
		}
		
		setPercentMissingData(percentMissingData);
		
		// Make sure that there are actually data to write to the file
		if(getPacketList().size() > 0)
			super.write(hdfFile); 
		else
			ret = false;
		
		// Update stats if applicable
		if (stats != null && ret) {
			stats.sci_createdGranules.value++;
		}
				
		sciPacketCount = 0;
		
		return ret;
	}

	/**
	 * (Override)
	 * Close out the RawApplicationPacket which writes the results to the HDF file and cleans up.
	 * @exception any HDF exceptions are wrapped in an RtStpsException
	 */
	public void close() throws RtStpsException {
		super.close();
		sciPacketCount = 0;
	}
}
