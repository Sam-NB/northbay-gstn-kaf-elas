/*
Copyright (c) 1999-2007, United States Government, as represented by
the Administrator for The National Aeronautics and Space Administration.
All rights reserved.
*/

package gov.nasa.gsfc.drl.rtstps.core.xstps.pds;

import gov.nasa.gsfc.drl.rtstps.core.ccsds.Packet;
import gov.nasa.gsfc.drl.rtstps.core.output.rdr.LeapDate;

import java.io.BufferedOutputStream;
import java.io.DataOutput;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;

import java.util.Iterator;
import java.util.HashMap;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.ArrayDeque;

import java.lang.Integer;
import java.lang.Long;
import java.lang.Boolean;

public class ScanWriter {

	// A HashMap with a secondary header time (representing scan time) as the keys, 
	// and a corresponding scan construct object as the value:
	private HashMap<Long, ScanConstruct> scans;

	// A HashMap with APID as the keys, and the latest scan time encountered for that
	// APID. This is to keep track of which scan construct an APID packet belongs to,
	// even if that packet contains no secondary header:
	private HashMap<Integer, Long> apidScanMap;

	// A double-ended queue that will keep track of the scan construct flush order.
	// This contains the secondary header time of scan constructs.
	private ArrayDeque<Long> flushOrder;

	// An integer to store the number of expected APIDs
	private int expectedAPIDs;

	// An integer that represents the size of the scan sliding window
	private int scanWindowSize = 3;

	// Exit condition
	private boolean writeActive = true;

	/**
	 * Constructor that accepts the number of expected APIDs
	 * @param numapids Number of expected APIDs
	 */
	public ScanWriter(int numapids){
		this.expectedAPIDs = numapids;
		this.scans = new HashMap<Long, ScanConstruct>();
		this.apidScanMap = new HashMap<Integer, Long>();
		this.flushOrder = new ArrayDeque<Long>();
	}

	/**
	 * Constructor that accepts the number of expected APIDs and sliding window size
	 * @param numapids Number of expected APIDs
	 * @param windowSize Size of the scan sliding window
	 */
	public ScanWriter(int numapids, int windowsize){
		this.expectedAPIDs = numapids;
		this.scanWindowSize = windowsize;
		this.scans = new HashMap<Long, ScanConstruct>();
		this.apidScanMap = new HashMap<Integer, Long>();
		this.flushOrder = new ArrayDeque<Long>();
	}

	/**
	 * Function to put a packet into this PdsWriter instance, which handles the
	 * packets' eventual write to file
	 * @param p A Packet object
	 * @param out The OutputStream object to write to
	 */
	public void write(Packet p, OutputStream out){
		// Do not continue if this writer is no longer active
		if(!writeActive) return;

		// See if this packet has a secondary header
		Long packetTime = -1L;
		Integer packetAPID = Integer.valueOf(p.getApplicationId());
		boolean hasSecondaryHeader = p.hasSecondaryHeader();

		// If it does, get its timestamp and put it in the proper scan construct. Add the
		// construct to the processing queue if needed.
		if(hasSecondaryHeader){
			packetTime = Long.valueOf(LeapDate.getMicrosSinceEpoch(p.getTimeStamp(8)));
			if(!scans.containsKey(packetTime)){
				scans.put(packetTime, new ScanConstruct(this.expectedAPIDs));
				flushOrder.addLast(packetTime);
			}
		}
		// If it doesn't, check the apid scan map to see where this packet belongs to.
		else if(apidScanMap.containsKey(packetAPID)){
			packetTime = apidScanMap.get(packetAPID);
		}
		// Else, no scan time is associated with this APID yet, so it's an orphaned packet.
		// Simply return and do not attempt to process this packet
		else{
			System.out.println("DEBUG - EARLY ORPHAN PACKET FOR APID " + packetAPID.intValue()); 
			return;
		}
		
		// This is a safeguard in case a packet is interspersed in a far later scan after all
		// packets from the same scan have been written to file already, in which case this
		// packet is treated as an orphaned packet
		if(!scans.containsKey(packetTime)){
			System.out.println("DEBUG - LATE ORPHAN PACKET FOR APID " + packetAPID.intValue());
			return;
		}
		
		// Update the APID scan map and put this packet in the appropriate scan construct
		apidScanMap.put(packetAPID, packetTime);
		scans.get(packetTime).putPacket(p);

		// After putting each packet, check if the ScanConstruct that packet belongs
		// to is complete. If so, write this ScanConstruct and everything temporally 
		// before it to the PDS file and remove them from the mappings:
		if(scans.get(packetTime).isComplete()){
			flushScan(packetTime, out, true);
		}
		// There are times when we don't actually get all expected APIDs. In this case,
		// we maintain a n-scan sliding window. Flush when this sliding window is exceeded.
		else if(scanWindowSize > 0 && flushOrder.size() > scanWindowSize){
			flushScan(packetTime, out, false);
		}
	}

	/**
	 * Function to write all scans up to the provided packet time (inclusive) to file
	 * @param packetTime Long representing the latest packet time to write to file
	 * @param out OutputStream to write to
	 * @param incl boolean to indicate whether to write up to packetTime inclusively or not
	 */
	private void flushScan(Long packetTime, OutputStream out, boolean incl){
		boolean flushActive = true;
		while(flushActive && !flushOrder.isEmpty()){
			Long scanCounter = flushOrder.getFirst();

			// Stop further iterations if the current scan time is reached. If the
			// write is non-inclusive, stop right here:
			if(scanCounter.equals(packetTime)){
				flushActive = false;
				if(!incl) break;
			}

			// Write the scan construct to the PDS file, then remove it from mappings
			scans.get(scanCounter).flushToFile(out);
			scans.remove(scanCounter);
			flushOrder.removeFirst();
		}
	}

	/**
	 * Function to write all scans to file. Should only be used upon closing of ScanWriter
	 */
	private void flushAll(OutputStream out){
		while(!flushOrder.isEmpty()){
			Long packetTime = flushOrder.removeFirst();

			// Keep going if for some reason this scan construct no longer exists
			if(!scans.containsKey(packetTime)) continue;

			// Write the scan construct to the PDS file, then remove it from mappings
			scans.get(packetTime).flushToFile(out);
			scans.remove(packetTime);
		}
	}

	/**
	 * Function designed to clean up everything. We rely on PdsOutput for synchronizing write
	 * and close methods.
	 */
	public void close(OutputStream out){
		writeActive = false;
		flushAll(out);
		apidScanMap.clear();
		scans.clear();
	}

} // END OF CLASS ScanWriter
