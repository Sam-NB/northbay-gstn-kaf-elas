/*
Copyright (c) 1999-2007, United States Government, as represented by
the Administrator for The National Aeronautics and Space Administration.
All rights reserved.
*/

package gov.nasa.gsfc.drl.rtstps.core.ccsds;

import gov.nasa.gsfc.drl.rtstps.core.Configuration;
import gov.nasa.gsfc.drl.rtstps.core.Convert;
import gov.nasa.gsfc.drl.rtstps.core.RtStpsException;
import gov.nasa.gsfc.drl.rtstps.core.RtStpsNode;
import gov.nasa.gsfc.drl.rtstps.core.Receiver;
import gov.nasa.gsfc.drl.rtstps.core.Sender;
import gov.nasa.gsfc.drl.rtstps.core.status.StatusItem;
import gov.nasa.gsfc.drl.rtstps.core.status.LongStatusItem;
import gov.nasa.gsfc.drl.rtstps.core.ccsds.path.PacketRouter;


import org.w3c.dom.Element;
import org.w3c.dom.NodeList;

import java.util.TreeMap;

/**
 * 5.9: This node receives all CCSDS packets; it sorts packets and redirects them
 * to service processors based on the application packet ID
 * 
 * 
 */
public final class PacketService extends RtStpsNode implements PacketReceiver, Sender {

	public static final String CLASSNAME = "packet_service";

	/* These will manage all potential PacketReceiver outputs */
	private PacketReceiver output = null;
	private PacketOutputTool potool = null;

	/* This will contain all user-defined packet links */
	private NodeList pklinks;

	/* Status items used by this node */
	private LongStatusItem totalPacketsReceived;

	/**
	 * PacketService Constructor
	 */
	public PacketService(){
		/* There's only one packet_service element at any given time, so use CLASSNAME for
		   the link name as well */
		super(CLASSNAME);
		super.setLinkName(CLASSNAME);
	}

	/**
     * RtStpsNode: Configure from an XML document. You cannot assume that any other stps nodes
     * have been created.
     */
    public void load(Element element, Configuration configuration) throws RtStpsException {
		/* Initialize packet links on load */
		pklinks = element.getElementsByTagName("pklink");

		/* Initialize the RtStpsNode statusItemList */
		if(statusItemList == null)
			statusItemList = new java.util.ArrayList<StatusItem>(1);

		/* Initialize the status items, and add them to the statusItemList */
		totalPacketsReceived = new LongStatusItem("Total Packets Received");
		statusItemList.add(totalPacketsReceived);
	}

	/**
     * RtStpsNode: Finish the setup. When this method is called, you may assume all nodes
     * have been created and exist by name in the map, and all standard links
     * have been resolved. This is a last chance to prepare for data flow.
     */
    public void finishSetup(Configuration configuration) throws RtStpsException {
		/* Get the pklinks from the configuration object */
		TreeMap<String, RtStpsNode> stpsNodes = configuration.getStpsNodes();
		int length = pklinks.getLength();

		if (length > 0) {
			/* The packet receiver we'll use is a PacketRouter, which has a table of APID/Packet 
			   Receivers */
			PacketRouter router = new PacketRouter(toString() + ".PacketRouter", statusItemList);

			/* Use addReceiver to "wrap" the PacketRouter with the PacketOutputTool. This 
			   conforms to coding standards */
			addReceiver(router);

			/* Iterate through each packet link and add them to the Packet Router if applicable, 
			   i.e. if packet links are Packet Receivers */
            for (int n = 0; n < length; n++) {
				Element pklink = (Element)pklinks.item(n);
				int appid = Convert.toInteger(pklink, "appid", 0);
				String target = pklink.getAttribute("label");
				RtStpsNode stpsNode = (RtStpsNode)stpsNodes.get(target);

				if (stpsNode instanceof PacketReceiver) {
					router.addPacketReceiver(appid,(PacketReceiver)stpsNode);
				}
				else {
					pklinks = null;
					throw new RtStpsException("ERROR - packet_service: " + target + 
												" is not a packet receiver.");
				}
			}
		}

		/* Clean up the pklinks Node List once setup is complete */
		pklinks = null;

		/* Have the PacketOutputTool return the final form of the Packet Receiver */
		output = potool.getOutput();

		/* Then finally, close the PacketOutputTool as it's unneeded at this point */
		potool = null;
		if (output == null) {
			throw new RtStpsException(toString() + " demands an output link.");
		}
	}

	/**
     * Sender: Add a Receiver to this sender's list of receivers.
     * @param receiver If the receiver is not of the expected type,
     *          then the method throws an RtStpsException.
     */
	public void addReceiver(Receiver receiver) throws RtStpsException {
		if (potool == null){
			potool = new PacketOutputTool(getLinkName());
		}

		potool.addReceiver(receiver);
		output = potool.getOutput();
	}

	/**
     * PacketReceiver: Give an array of packets to this PacketReceiver.
     */
    public void putPackets(Packet[] packets) throws RtStpsException {
		if(packets != null){
			for (int n = 0; n < packets.length; n++)
				putPacket(packets[n]);
		}
	}

    /**
     * PacketReceiver: Give a packet to this PacketReceiver.
     */
    public void putPacket(Packet packet) throws RtStpsException {
		/* PacketService's only job is to route all packets to the 
		   proper PacketPipelines */
		if(packet != null){
			++totalPacketsReceived.value;
        	output.putPacket(packet);
		}
	}

    /**
     * PacketReceiver: Flush the data pipeline.
     */
    public void flush() throws RtStpsException {
		/* Flush all nodes downstream of this node */
		output.flush();
	}
}
