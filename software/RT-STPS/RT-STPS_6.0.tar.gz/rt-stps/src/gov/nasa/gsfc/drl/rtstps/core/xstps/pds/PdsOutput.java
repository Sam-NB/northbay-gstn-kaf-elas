/*
Copyright (c) 1999-2007, United States Government, as represented by
the Administrator for The National Aeronautics and Space Administration.
All rights reserved.
*/
package gov.nasa.gsfc.drl.rtstps.core.xstps.pds;
import gov.nasa.gsfc.drl.rtstps.core.Configuration;
import gov.nasa.gsfc.drl.rtstps.core.Convert;
import gov.nasa.gsfc.drl.rtstps.core.RtStpsException;
import gov.nasa.gsfc.drl.rtstps.core.ccsds.Packet;
import gov.nasa.gsfc.drl.rtstps.core.status.LongStatusItem;
import gov.nasa.gsfc.drl.rtstps.core.status.StatusItem;

import java.io.BufferedOutputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileOutputStream;

// 5.7.3a: Additional imports for HashMap APID lookup
import java.util.HashMap;
import java.lang.Integer;

/**
 * This RT-STPS node is a java version of the Sorcerer program. It creates Terra
 * and Aqua PDS or EDS files.
 * 
 * 
 */
public final class PdsOutput extends gov.nasa.gsfc.drl.rtstps.core.RtStpsNode
        implements gov.nasa.gsfc.drl.rtstps.core.ccsds.PacketReceiver, Cloneable
{
    /**
     * This is the class name for this RT-STPS node type, which is also the
     * element name. It is not necessarily the link name, which is the name
     * of one particular object.
     */
    public static final String CLASSNAME = "sorcerer";

    //When a flush is issued, I generate the construction record. The command thread
    //performs the flush, which is a different thread then the data processing thread.
    //This creates synchronization issues here because I maintain lists of information
    //such as gap lists, which get concurrent modification errors if packets arrive
    //while I am creating the construction record. I use the following flag with
    //synchronization to ignore any post-flush data.
    private boolean flushActive = false;

    //Users have complained that sometimes the PDS files from one pass do not all have
    //the same timestamp in their file names. This is natural because each instance of
    //this class is responsible for creating its own PDS, so files from the same pass
    //could have times as much as one second apart. Some users do not like this. To
    //silence them, I define a static variable for the time that the first-up loads
    //and all others use. I reset it to null at flush time so that it will be ready
    //for the next pass.
    private static String commonTimestamp = null;

    private Appid[] apList;
    private int totalPackets = 0;
    private long totalBytes = 0L;
    private OutputFiles output;
    private int major = 0;
    private int minor = 0;
    private int spid = 42;
    private boolean test = false;
    private boolean isPDS = true;
    private StringBuffer constructionRecordName;
    private boolean isQuicklookTypeEDS = false;
    private LongStatusItem packetsWritten;

	/*
	 * NPDS: PdsOutput uses PacketKernel objects: firstPacket and lastPacket.
	 * These will represent the first and last packets encountered which contain a
	 * secondary header (hence, timestamp). 
	 *
	 * In the case of an APID that lacks secondary headers, PacketKernel defaults all time
	 * information to zero values (which translate to epoch).
	 */
    private PacketKernel firstPacket;
    private PacketKernel lastPacket;
    private PacketKernel current;

	/* NPDS 6.1: ESH time represents session time; these should still be calculated even if
	 * packets do not have secondary headers for packet time calculation
	 */
	private long firstESHtime = 0L;
	private long lastESHtime = 0L;

	/**
	 * NPDS: This indicates the max temporal range (in microseconds) of each PDS file, in T-PDS mode
	 */
	private long timeSpan = 0L;

	/**
	 * 5.7.3a: A local copy of element to be able to regenerate PDS/CSR file name pairs on the fly
	 */
	private org.w3c.dom.Element elemcopy;

	/**
	 * 5.7.3a: Hash map required for quick APID lookups. Mainly used for PDS granulation
	 */
	private HashMap<Integer,Integer> apMap;
	private PacketKernel pkChecker;

	/**
	 * 5.7.3a: Various variables from load turned into member variables so they may be reused during
	 * PDS granulation (i.e. creating new PDS/CSR pair from the same session)
	 */
	int appidCount;
	boolean discardBadLengthPackets;
	String path;
	long bytesPerFile;
	String PDSformat = "";
	String PDSProductID = "singleAPID";
	String PDSIndicator = "S";

	/**
	 * 5.7.3a: For internal IPOPP purposes; will determine if S-PDS granulation will use the granule
	 * boundary calculator (for temporally-aligned, granulated S-PDS/CSR file pairs)
	 */
	String boundaryMode = "default";

	/**
	 * 5.7.3a: For internal IPOPP purposes; this non-static timestamp is used for granulated S-PDS/CSR
	 * pairs, as "commonTimestamp" is static and intended only for non-granulated PDS/CSR pairs and T-PDS
	 */
	private String granTimestamp = null;

	// 5.9a: For global processing purposes; tells this class whether to expect packets from multiple VCs
	private boolean multiVC = false;
	private int scanWindowSize = 203;

    /**
     * A null constructor.
     */
    public PdsOutput()
    {
        super(CLASSNAME);
    }

    /**
     * Configure from an XML document. You cannot assume that any other stps
     * nodes have been created.
     */
    public void load(org.w3c.dom.Element element,
            Configuration configuration) throws RtStpsException
    {
		// NPDS: Initialize PacketKernels so they can have default (epoch) time values:
        firstPacket = new PacketKernel();
        lastPacket = new PacketKernel();
        current = new PacketKernel();

		// 5.7.3a: Store a local copy of element
		elemcopy = element;

        statusItemList = new java.util.ArrayList<StatusItem>(3);	
        packetsWritten = new LongStatusItem("Packets Written");
        statusItemList.add(packetsWritten);

        String name = element.getAttribute("label");
        super.setLinkName(name);

        isQuicklookTypeEDS = Convert.toBoolean(element,"QuicklookEDS",isQuicklookTypeEDS);

        String spds = element.getAttribute("type");
        if (spds.length() > 0) isPDS = spds.equals("PDS");

        major = Convert.toInteger(element,"major",major,0,255);
        minor = Convert.toInteger(element,"minor",minor,0,255);
        spid = Convert.toInteger(element,"spid",spid);
        test = Convert.toBoolean(element,"test",test);

		// 5.9a: Get the value for multiVC and scan window size
		multiVC = Convert.toBoolean(element,"multiVC",false);
		scanWindowSize = Convert.toInteger(element,"scanWindow",203);

        org.w3c.dom.NodeList nodes = element.getElementsByTagName("appid");
		// 5.7.3a: Get the number of APIDs (now a member variable)
        appidCount = nodes.getLength();

		// 5.7.3a: Get the desired PDS format (now a member variable)
		PDSformat = element.getAttribute("format");

		// 5.7.3a: Get the desired product name (now a member variable). If EDOS PDS format, product name must be 17-characters (bytes) long
		PDSProductID = element.getAttribute("productID");
		if (isEDOSPDS(PDSformat) && PDSProductID.length() != 17 && !PDSProductID.equals("singleAPID")) {
			throw new RtStpsException("sorcerer: Product ID must be 17 characters long in SNPP/J1 PDS files.");
		}

		// 5.7.3a: Get the PDS time/session indicator (now a member variable)
		PDSIndicator = element.getAttribute("tsIndicator");
		if (isEDOSPDS(PDSformat) && PDSIndicator.length() != 1) {
			throw new RtStpsException("sorcerer: T/S Indicator must be either T (Time-based) or S (Session-based).");
		}

		// 5.7.3a: Get the boundary mode
		boundaryMode = element.getAttribute("mode");

		// NPDS: Get the PDS temporal range (time span):
		timeSpan = Long.parseLong(element.getAttribute("timespan"), 10);

		// NPDS: Only allow more than 3 APIDs per PDS if we are using the EDOS ICD SNPP/J1 PDS formats
        if (appidCount < 1) {
            throw new RtStpsException("sorcerer: There must be 1-3 appid elements in Sorcerer.");
        }
		if (appidCount > 3 && !isEDOSPDS(PDSformat)) {
            throw new RtStpsException("sorcerer: There must be 1-3 appid elements in Sorcerer.");
        }

		// 5.7.3a: Determine if bad length packets are discarded (now a member variable)
        discardBadLengthPackets = Convert.toBoolean(element, "discardBadLengthPackets", true);

        apList = new Appid[appidCount];

		// 5.7.3a: Initialize the APID HashMap lookup table and pkChecker; key/value are APID/index (value is
		// unneeded at the moment, but may be changed in the future based on need)
		apMap = new HashMap<Integer,Integer>();
		pkChecker = new PacketKernel();

        for (int n = 0; n < appidCount; n++)
        {
            org.w3c.dom.Element e = (org.w3c.dom.Element)nodes.item(n);
            apList[n] = new Appid(e,spid,discardBadLengthPackets,isQuicklookTypeEDS);
			
			// 5.7.3a: Put APID information into HashMap
			apMap.put( Integer.valueOf(apList[n].getId()), Integer.valueOf(n) );
        }

        int kbPerFile = Convert.toInteger(element,"KBperFile",0,0);
		// 5.7.3a: Get bytes per file (now a member variable)
        bytesPerFile = 1024L * (long)kbPerFile;

		// NPDS: Use the new createFileName instead
        //constructionRecordName = createFileName(element);
		constructionRecordName = createFileName(element, PDSformat, PDSProductID, PDSIndicator);

		// 5.7.3a: Get the output directory (now a member variable)
        path = element.getAttribute("path");

        try
        {
			// NPDS: Use the OutputFiles constructor that takes the number of APIDs:
            //output = new OutputFiles(constructionRecordName,path);
			output = new OutputFiles(constructionRecordName,path,appidCount);

			// 5.7.3a: let OutputFiles know what kind of PDS we're dealing with
			output.setPDSType(PDSIndicator);

			// 5.7.3a: let OutputFiles know whether to use the granule calculator
			output.calculateGranules(boundaryMode);

			// 5.9a: let OutputFiles know whether to expect packets from multiple VCs
			output.setMultiVC(multiVC, scanWindowSize);

			// 5.7.3a: Set the T-PDS temporal range if applicable
			if (timeSpan > 0L) output.setPDSTemporalRange(timeSpan);

            if (bytesPerFile > 0) output.setBytesPerFile(bytesPerFile);
            for (int n = 0; n < appidCount; n++)
            {
                output.setAppidSpid(n,apList[n].getId(),apList[n].getSpacecraftId());
            }
        }
        catch (java.io.IOException ioe)
        {
            throw new RtStpsException(ioe);
        }
    }

    /**
     * Finish the setup. When this method is called, you may assume all nodes
     * have been created and exist by name in the map, and all standard links
     * have been resolved. This is a last chance to prepare for data flow.
     */
    public void finishSetup(Configuration configuration) throws RtStpsException
    {
        flushActive = false;
    }

    /**
     * Create a PDS/EDS file name for the construction record.
     */
    private StringBuffer createFileName(org.w3c.dom.Element element) throws RtStpsException
    {
        java.text.DecimalFormat dfspid = new java.text.DecimalFormat("000");
        java.text.DecimalFormat dfapid = new java.text.DecimalFormat("0000");
        StringBuffer id = new StringBuffer(40);

        id.append(isPDS? 'P' : 'E');

        for (int n = 0; n < apList.length; n++)
        {
            Appid ap = apList[n];
            id.append(dfspid.format((long)ap.getSpacecraftId()));
            id.append(dfapid.format((long)ap.getId()));
        }

        if (apList.length < 3) id.append("AAAAAAA");
        if (apList.length == 1) id.append("AAAAAAA");

        java.text.SimpleDateFormat sdf = new java.text.SimpleDateFormat("yyDDDHHmmss");
        String gmt = element.getAttribute("create");
        if ((gmt == null) || (gmt.length() == 0))
        {
            if (commonTimestamp == null)
            {
               commonTimestamp = sdf.format(new java.util.Date());
            }
            gmt = commonTimestamp;
        }
        else
        {
            try
            {
                sdf.parse(gmt);
            }
            catch (java.text.ParseException pe)
            {
                throw new RtStpsException(pe);
            }
        }
        id.append(gmt);

        //dataset counter
        int n = Convert.toInteger(element,"datasetCounter",0,0,9);
        id.append(Character.forDigit(n,10));

        id.append("00");
        id.append(isPDS? ".PDS" : ".EDS");
        return id;
    }

	/**
	* NPDS: Function which constructs a PDS filename based on the parameters set in the "sorcerer"
	* element. This overloaded function is a more generic version that can create filenames that follow
	* different naming conventions (e.g. EDOS ICD for SNPP).
	*
	* EDOS to SIPS ICD: the following PDS naming convention is used if the format is "SNPP" or "J1"
	* "P" + SCID + Product ID + T/S ID + PDS Creation Time + Numeric ID + Unique File Number + ".PDS"
	*/
	public StringBuffer createFileName (org.w3c.dom.Element element, 
										String pdsFormat, 
										String productID, 
										String pdsIndicator) throws RtStpsException {

		java.text.DecimalFormat dfspid = new java.text.DecimalFormat("000");
		java.text.DecimalFormat dfapid = new java.text.DecimalFormat("0000");
		StringBuffer id = new StringBuffer(40);

		// Append "P" for PDS, "E" for EDS
		id.append(isPDS? 'P' : 'E');

		// NPDS: If we are creating EDOS SNPP/J1 PDS, use the EDOS ICD convention
		if(isEDOSPDS(pdsFormat)) {
			Appid ap = apList[0];
			id.append(dfspid.format((long)ap.getSpacecraftId()));
			if (productID.equals("singleAPID")) {
				// NPDS: QoL change to allow automatic product ID generation for single APID PDSs
				id.append(dfapid.format((long)ap.getId()));
				id.append("AAAAAAAAAAAAA");
			}
			else {
				// NPDS: Otherwise, just append the user-specified product ID
				id.append(productID);
			}
			id.append(pdsIndicator);
		}
		// NPDS: Else, use the standard MODIS PDS convention
		else {
			for (int n = 0; n < apList.length; n++) {
				Appid ap = apList[n];
				id.append(dfspid.format((long)ap.getSpacecraftId()));
				id.append(dfapid.format((long)ap.getId()));
			}
			if (apList.length < 3) id.append("AAAAAAA");
        	if (apList.length == 1) id.append("AAAAAAA");
		}
		
		// NPDS: Calculate the PDS creation timestamp, then append to filename
		java.text.SimpleDateFormat sdf = new java.text.SimpleDateFormat("yyDDDHHmmss");
		String gmt = element.getAttribute("create");

		// 5.7.3a: Case where "create" isn't defined; override the "create" attribute if S-PDS granulation is enabled
		if ((gmt == null) || (gmt.length() == 0) || isGranSPDS()) {
			// 5.7.3a: In case of S-PDS granulation, USE THE LOCAL TIMESTAMP or else granulated files may overwrite each other
			if(isGranSPDS()){
				// 5.7.3a: Create a new PDS creation timestamp from current system time
				String tempTimestamp = sdf.format(new java.util.Date());

				// 5.7.3a: If timestamp is the same as previous granule's, wait for 1 sec then try again (throttle data)
				if (granTimestamp != null && tempTimestamp.equals(granTimestamp)) {
					try {
						Thread.sleep(1000);
					} catch(InterruptedException ieex) {
						System.out.println("WARNING - Data throttling for " + super.getLinkName() + " stopped prematurely!");
					}
					tempTimestamp = sdf.format(new java.util.Date());
					if(tempTimestamp.equals(granTimestamp))
						System.out.println("ERROR - Data throttling failed; PDS creation time overlap occurred for " + super.getLinkName());
				}

				granTimestamp = tempTimestamp;
				gmt = granTimestamp;
			}
			// 5.7.3a: Otherwise, use static timestamp. Only set it if it's still null
			else{
				if(commonTimestamp == null)
					commonTimestamp = sdf.format(new java.util.Date());
				gmt = commonTimestamp;
			}
		}
		else {
		    try {
		        sdf.parse(gmt);
		    }
		    catch (java.text.ParseException pe) {
		        throw new RtStpsException(pe);
		    }
		}

		id.append(gmt);

		//dataset counter
		int n = Convert.toInteger(element,"datasetCounter",0,0,9);
		id.append(Character.forDigit(n,10));

		id.append("00");
		id.append(isPDS? ".PDS" : ".EDS");
		return id;
	}

    /**
     * Give an array of packets to this PacketReceiver.
     */
    public void putPackets(Packet[] packets) throws RtStpsException
    {
        for (int n = 0; n < packets.length; n++)
        {
            putPacket(packets[n]);
        }
    }

    /**
     * Give a packet to this PacketReceiver.
     */
    public synchronized void putPacket(Packet packet) throws RtStpsException
    {
        if (flushActive) return;

		// 5.7.3a: If we are dealing with granulated S-PDS, do the granule boundary checks
		if (timeSpan > 0L && PDSIndicator.equals("S")){
			check(packet);
		}

        ++packetsWritten.value;

        //First I identify to which appid the packet belongs.
        Appid ap = null;
        int apindex = 0;
        int a = packet.getApplicationId();
        for (int n = 0; n < apList.length; n++)
        {
            if (apList[n].getId() == a)
            {
                ap = apList[n];
                apindex = n;
                break;
            }
        }

        //If ap==null, then I don't recognize the appid.
        if (ap != null)
        {
            //I store packet information in its appid. I load "current"
            //with "packet" in ap and not here because ap knows critical
            //information about how the packet is formed.
            boolean save = ap.putPacket(packet,current,totalBytes);

            if (save)
            {
                ++totalPackets;

				// NPDS 6.1: Record the ESH time(s) separately from packet times (decouple them)
				if(firstESHtime == 0L)
					firstESHtime = current.getEshTime();
				lastESHtime = current.getEshTime();

				// NPDS: Set this packet as "first" packet if it's the first packet we get with a secondary header
                //if (totalPackets == 1)
				if(firstPacket.isEmpty() && packet.hasSecondaryHeader())
                {
                    //ap loaded current.
                    firstPacket.copy(current);
                }
				// NPDS: Set this packet as "last" packet if it's the latest packet we get with a secondary header
				if(packet.hasSecondaryHeader())
                	lastPacket.copy(current);
                totalBytes += packet.getSize();

                try
                {
                    output.write(packet,current,apindex);
                }
                catch (java.io.IOException ioe)
                {
                    throw new RtStpsException(ioe);
                }
            }
        }
    }

	/**
     * 5.7.3a: Function that checks the current PDS granule boundaries. 
	 * If the packet exceeds the current PDS granule boundaries, the session
	 * is ended and a session for a new PDS/CSR pair is started.
	 *
	 * This should only be used for session-based PDS with a granule period (timeSpan)
	 * specified.
	 *
	 * Returns true if packet exceeds the boundary, false otherwise.
     */
	public synchronized void check(Packet packet) throws RtStpsException
    {
		// Return immediately if flush is already occurring
		if (flushActive) return;

        // First I identify to which appid the packet belongs. Only do the checks if this packet
		// belongs to one of the registered application IDs.
		Integer APID = Integer.valueOf(packet.getApplicationId());
		if(apMap.containsKey(APID)){
			// Load pkChecker with the packet's information (use appropriate Appid from apList)
			pkChecker.set(packet, 
						apList[apMap.get(APID).intValue()].getHasCucSecondaryHeaderTime(), 
						apList[apMap.get(APID).intValue()].getTimeOffset() );

			// Now check if packet exceeds the latest granule boundary
			boolean exceedBoundary = false;
			exceedBoundary = output.check(pkChecker);

			// Reload if needed
			if(exceedBoundary)
				reload();
		}
	}

    /**
     * The session is over. Create the construction record file.
     */
    public void flush() throws RtStpsException
    {
        commonTimestamp = null;  //reset for next pass.
		granTimestamp = null;	 // 5.7.3a: also reset local timestamp

        //I synchronize so that I do not do this while inside putPacket.
        synchronized (this)
        {
			// NPDS: this seems to be called more than once during the shutdown sequence resulting in an erroneous CSR file,
    		// so only close everything up one time.  Load resets it.
			if(flushActive) return;

            flushActive = true;
        }

        try
        {
			System.out.println("Number of files before close for " + constructionRecordName.toString() + ": " + output.getFileCount());
            output.close(); //close the last data file
			System.out.println("Number of files after close for " + constructionRecordName.toString() + ": " + output.getFileCount());
            /**
             * If the total packets is zero, then the session was shut down
             * without processing any packets. I skip the creation of the
             * construction record.
             */
            if (totalPackets == 0) return;

            File file = new File(output.getPath(),constructionRecordName.toString());
            FileOutputStream fos = new FileOutputStream(file);
            BufferedOutputStream bos = new BufferedOutputStream(fos,8192);
            DataOutputStream crecord = new DataOutputStream(bos);

            crecord.writeByte(major);
            crecord.writeByte(minor);

            int type = 2;
            if (isPDS) type = 1;
            else if (isQuicklookTypeEDS) type = 3;
            crecord.writeByte(type);

            crecord.writeByte(0);
            crecord.writeBytes(constructionRecordName.substring(0,36));
            crecord.writeByte(test? 1 : 0);
            crecord.writeByte(0);
            crecord.writeLong(0L);

            crecord.writeShort(1);

			// NPDS 6.1: To decouple packet and session time calculations
            //crecord.writeLong(firstPacket.getEshTime());  //session start
            //crecord.writeLong(lastPacket.getEshTime());  //session stop
			crecord.writeLong(firstESHtime);
            crecord.writeLong(lastESHtime);

            long totalFillBytes = 0;
            int wrongLengthPackets = 0;
            int totalGaps = 0;
            int reedSolomonCorrectedPackets = 0;

            for (int n = 0; n < apList.length; n++)
            {
                Appid ap = apList[n];
                totalFillBytes += ap.getTotalFillBytes();
                wrongLengthPackets += ap.getTotalPacketsWithBadLength();
                totalGaps += ap.getTotalGaps();
                reedSolomonCorrectedPackets += ap.getReedSolomonCorrectedPacketCount();
            }

            crecord.writeLong(totalFillBytes);
            crecord.writeInt(wrongLengthPackets);

			// 5.7.3a: For internal use only, determine if we want to write packet start/end times
			// or calculated granule boundaries
			if(boundaryMode.equals("granulate") && timeSpan > 0L){
				crecord.writeLong(output.getBoundaries(0));
				crecord.writeLong(output.getBoundaries(1));
			}
			else{
            	crecord.writeLong(firstPacket.getPacketTime());
            	crecord.writeLong(lastPacket.getPacketTime());
			}

			// NPDS 6.1: To decouple packet and session time calculations
            //crecord.writeLong(firstPacket.getEshTime());
            //crecord.writeLong(lastPacket.getEshTime());
			crecord.writeLong(firstESHtime);
            crecord.writeLong(lastESHtime);

            crecord.writeInt(reedSolomonCorrectedPackets);
            crecord.writeInt(totalPackets);
            crecord.writeLong(totalBytes);
            crecord.writeInt(totalGaps);

			// NPDS 6.1: To decouple packet and session time calculations
            //crecord.writeLong(lastPacket.getEshTime());
            crecord.writeLong(lastESHtime);

            crecord.writeLong((long)apList.length);

            for (int n = 0; n < apList.length; n++)
            {
                apList[n].printCS(crecord);
            }

            int files = output.getFileCount() + 1;
            crecord.writeInt(files);
            crecord.writeBytes(constructionRecordName.toString());
            for (int n = 0; n < 7; n++)
            {
                crecord.writeInt(0);
            }
            output.writeCS(crecord);
            crecord.close();
        }
        catch (java.io.IOException ioe)
        {
            throw new RtStpsException(ioe);
        }
    }

	/**
     * Checks if the PDS format is EDOS SNPP/J1
     */
	private boolean isEDOSPDS(String pdsformat) {
		return pdsformat.equals("SNPP") || pdsformat.equals("J1");
	}

	/**
     * 5.7.3a: Checks if this sorcerer is configured for granulated S-PDS/CSR file pairs
     */
	private boolean isGranSPDS(){
		return (timeSpan > 0L && PDSIndicator.equals("S"));
	}

	/**
     * 5.7.3a: Function to end the current session for the PDS/CSR pair. This is basically
	 * a copy of flush(), but does not change the value of flushActive as to not override
	 * the master switch for processing
     */
	private void endSession() throws RtStpsException {
        // I synchronize so that I do not do this while inside putPacket.
        synchronized (this) {
			// NPDS: this seems to be called more than once during the shutdown sequence resulting in an erroneous CSR file,
    		// so only close everything up one time.  Load resets it.
			if(flushActive) {
				System.out.println("WARNING - Cannot end current session for " + super.getLinkName() + "; flush() already in progress.");
				return;
			}
        }

		// 5.7.3a: Don't null this; We want to keep track of this to ensure granulated pairs have different timestamps
		//commonTimestamp = null;

        try
        {
			// close the current PDS file			
			System.out.println("INFO - Ending session for " + super.getLinkName() + ": " + constructionRecordName.toString());
            output.close();
			
            /**
             * If the total packets is zero, then the session was shut down
             * without processing any packets. I skip the creation of the
             * construction record.
             */
            if (totalPackets == 0) return;

            File file = new File(output.getPath(),constructionRecordName.toString());
            FileOutputStream fos = new FileOutputStream(file);
            BufferedOutputStream bos = new BufferedOutputStream(fos,8192);
            DataOutputStream crecord = new DataOutputStream(bos);

            crecord.writeByte(major);
            crecord.writeByte(minor);

            int type = 2;
            if (isPDS) type = 1;
            else if (isQuicklookTypeEDS) type = 3;
            crecord.writeByte(type);

            crecord.writeByte(0);
            crecord.writeBytes(constructionRecordName.substring(0,36));
            crecord.writeByte(test? 1 : 0);
            crecord.writeByte(0);
            crecord.writeLong(0L);

            crecord.writeShort(1);

			// NPDS 6.1: To decouple packet and session time calculations
			crecord.writeLong(firstESHtime);
            crecord.writeLong(lastESHtime);

            long totalFillBytes = 0;
            int wrongLengthPackets = 0;
            int totalGaps = 0;
            int reedSolomonCorrectedPackets = 0;

            for (int n = 0; n < apList.length; n++)
            {
                Appid ap = apList[n];
                totalFillBytes += ap.getTotalFillBytes();
                wrongLengthPackets += ap.getTotalPacketsWithBadLength();
                totalGaps += ap.getTotalGaps();
                reedSolomonCorrectedPackets += ap.getReedSolomonCorrectedPacketCount();
            }

            crecord.writeLong(totalFillBytes);
            crecord.writeInt(wrongLengthPackets);
            // 5.7.3a: For internal use only, determine if we want to write packet start/end times
			// or calculated granule boundaries
			if(boundaryMode.equals("granulate") && timeSpan > 0L){
				crecord.writeLong(output.getBoundaries(0));
				crecord.writeLong(output.getBoundaries(1));
			}
			else{
            	crecord.writeLong(firstPacket.getPacketTime());
            	crecord.writeLong(lastPacket.getPacketTime());
			}

			// NPDS 6.1: To decouple packet and session time calculations
			crecord.writeLong(firstESHtime);
            crecord.writeLong(lastESHtime);

            crecord.writeInt(reedSolomonCorrectedPackets);
            crecord.writeInt(totalPackets);
            crecord.writeLong(totalBytes);
            crecord.writeInt(totalGaps);

			// NPDS 6.1: To decouple packet and session time calculations
            crecord.writeLong(lastESHtime);

            crecord.writeLong((long)apList.length);

            for (int n = 0; n < apList.length; n++)
            {
                apList[n].printCS(crecord);
            }

            int files = output.getFileCount() + 1;
            crecord.writeInt(files);
            crecord.writeBytes(constructionRecordName.toString());
            for (int n = 0; n < 7; n++)
            {
                crecord.writeInt(0);
            }
            output.writeCS(crecord);
            crecord.close();
        }
        catch (java.io.IOException ioe)
        {
            throw new RtStpsException(ioe);
        }
	}

	/**
     * 5.7.3a: Function to finalize current PDS/CSR pair, and start a new one.
	 * Time-segmented S-PDS pairs, for global processing purposes. Reuses the
	 * configuration file initially used during load().
     */
	private void reload() throws RtStpsException {
		// Call to finalize current session
		synchronized (this) {
			if(flushActive){
				System.out.println("WARNING - Could not reload " + super.getLinkName() + "; data pipeline is already being flushed!");
				return;
			}
			else{
				endSession();
			}
		}

		// Reset this sorcerer's packet counter for the current session
		totalPackets = 0;

		// Reset this sorcerer's counter for bytes written
		totalBytes = 0L;

		// Reset this sorcerer's first and last ESH times recorded
		firstESHtime = 0L;
		lastESHtime = 0L;

		// Reinitialize PacketKernels so they can have default (epoch) time values:
        firstPacket = new PacketKernel();
        lastPacket = new PacketKernel();
        current = new PacketKernel();

		// Clear the HashMap APID lookup table
		apMap.clear();

		// Reinitialize the Appid objects to do a "hard" reset
        org.w3c.dom.NodeList nodes = elemcopy.getElementsByTagName("appid");

        for (int n = 0; n < appidCount; n++)
        {
            org.w3c.dom.Element e = (org.w3c.dom.Element)nodes.item(n);
            apList[n] = new Appid(e, spid, discardBadLengthPackets, isQuicklookTypeEDS);
			apMap.put( Integer.valueOf(apList[n].getId()), Integer.valueOf(n) );
        }

		// Create a new construction record name
		constructionRecordName = createFileName(elemcopy, PDSformat, PDSProductID, PDSIndicator);

		// Create a new output file(s)
        try
        {
			output = new OutputFiles(constructionRecordName, path, appidCount);
			output.setPDSType(PDSIndicator);
			// 5.7.3a: let OutputFiles know whether to use the granule calculator
			output.calculateGranules(boundaryMode);
			if (timeSpan > 0L) output.setPDSTemporalRange(timeSpan);
            if (bytesPerFile > 0) output.setBytesPerFile(bytesPerFile);

            for (int n = 0; n < appidCount; n++)
            {
                output.setAppidSpid(n, apList[n].getId(), apList[n].getSpacecraftId());
            }
        }
        catch (java.io.IOException ioe)
        {
            throw new RtStpsException(ioe);
        }

		// Print out a status message showing the new session
		System.out.println("INFO - Starting new session for " + super.getLinkName() + ": " + constructionRecordName.toString());
	}
}
