/*
Copyright (c) 1999-2007, United States Government, as represented by
the Administrator for The National Aeronautics and Space Administration.
All rights reserved.
*/
package gov.nasa.gsfc.drl.rtstps.core.output.rdr;

import gov.nasa.gsfc.drl.rtstps.core.RtStpsException;

import java.text.ParseException;

public class RCERSGranule extends Granule {

	// CERES-SCIENCE-RDR granule size in microseconds (660 seconds)
	private final static long granuleSize = 660000000;

	// S-NPP's base epoch time, used for calculating granule boundaries!
	private static long baseTime = 1698019234000000L;
	private static boolean baseTimeSet = false;

	// Various member variables:
	private LPEATEDate firstDateTime;
	private LPEATEDate lastDateTime;

	private PDSDate predictedEndDateTime;
	private PDSDate beginningTimeDateTime;
	private PDSDate predictedEndingTimeDateTime;

	public static boolean isBaseTimeSet() {
		return baseTimeSet;
	}

	public static void setBaseTimeSet(boolean baseTimeSet) {
		RCERSGranule.baseTimeSet = baseTimeSet;
	}

	public static long getBaseTime() {
		return baseTime;
	}

	public static void setBaseTime() {
		// Uses the S-NPP base time
		RCERSGranule.baseTimeSet = true;
	}

	public static void setBaseTime(long baseTime) {
		long baseTimedivide = baseTime / 1000000;
		long baseTimeEvenSecond = baseTimedivide * 1000000;
		RCERSGranule.baseTime = baseTimeEvenSecond;
		System.out.println("Set RCERS baseTime = " + RCERSGranule.baseTime);
		RCERSGranule.baseTimeSet = true;
	}

	/**
	 * Constructor for a Granule instance, the arguments are associated with the granule's attributes.
	 * An instance of this class in this packet is created by some other factory method.
	 * 
	 * @param rap the corresponding RawApplicationPackets area
	 * @param orbit the orbit number of the pass
	 * @param granuleId the granuleId {@link GranuleId}
	 * @param leoaState the LEO state flag
	 * @param docName the document name of the specification controlling this granules construction
	 * @param packetTypes an array of packet types received in this granule
	 * @param packetTypeCounts the counts per type of the packets received
	 * @param referenceId the reference identifier which is a UUID {@link java.util.UUID}
	 * @param granuleNumber the granule number which corresponds to the RawApplicationPackets number in the RDR/HDF file
	 * @param dataSpaceOfRaw the HDF DataSpace handle of the RawApplicationPackets area associated with this granule
	 */
	public RCERSGranule(RawApplicationPackets rap,
					long orbit,
					GranuleId granuleId,
					LEOAFlag leoaState,
					String docName,
					String[] packetTypes,
					long[] packetTypeCounts,
					ReferenceId referenceId,
					int granuleNumber, 
					int dataSpaceOfRaw) {
		// 6.0: RDR Name is now a class and not an enum value
		super(rap, 
			orbit, 
			granuleId, 
			leoaState, 
			docName, 
			packetTypes, 
			packetTypeCounts, 
			referenceId, 
			granuleNumber,  
			dataSpaceOfRaw,
			RDRName.fromRDRNameStr("CERES-SCIENCE-RDR"));
	}

	/**
	 * Read the Granule out of the HDF file and fill in the various attributes and items in it for
	 * these access methods
	 * @param groupId the HDF group handle
	 * @param granuleName  the name of the granule
	 * @throws ParseException 
	 */
	public RCERSGranule(int groupId, String granuleName) throws RtStpsException {
		super(groupId, granuleName);
	}

	long getScansPerGranule() {
		return 100;
	}

	/**
	* (Abstract method implementation)
	* Returns the beginning observation date time, as a PDSDate object
	*/
	public PDSDate getBeginningObservationDateTime(RawApplicationPackets rap) {
		this.firstDateTime = new LPEATEDate(rap.getFirstTime());
		return this.firstDateTime;
	}

	/**
	* (Abstract method implementation)
	* Returns the ending observation date time, as a PDSDate object
	*/
	public PDSDate getEndingObservationDateTime(RawApplicationPackets rap) {
		this.lastDateTime = new LPEATEDate(rap.getLastTime());
		
		// TODO: What is this for? What was the rationale for 50000L?
		// Is a private member, and has no "get" function. So it's unused...
		//this.predictedEndDateTime = firstDateTime.addMicros(getEndOffSet() + 50000L);
		
		return this.lastDateTime;
	}

	/**
	* (Abstract method implementation)
	* Returns the beginning date time, as a PDSDate object. This requires the 
	* Granule's beginning IET to be calculated first!
	*/
	public PDSDate getBeginningTimeDateTime() {
		this.beginningTimeDateTime = LeapDate.ietToPDSNoLeap( getBeginningIET() );
		return beginningTimeDateTime;
	}

	/**
	* (Abstract method implementation)
	* Returns the ending date time, as a PDSDate object. This requires the 
	* Granule's ending IET to be calculated first!
	*/
	public PDSDate getEndingTimeDateTime() {
		this.predictedEndingTimeDateTime = LeapDate.ietToPDSNoLeap( getEndingIET() );
		return predictedEndingTimeDateTime;
	}

	public static long getGranulesize() {
		return granuleSize;
	}

	/**
	* Taken from InfUtil_GranuleID.cpp; these two methods are used to calculate CERES-SCIENCE-RDR
	* granule start/stop boundaries given an arbitrary packet IET time (converted from CDS time)
	* ----------------------------------------------------------------------
	* The following steps calculate the granule ID, granule start time, and
	* granule end time:
	*	1.) Subtract the spacecraft base time from the arbitrary time to obtain
	*		an elapsed time.
	*	2.) Divide the elapsed time by the granule size to obtain the granule number; 
	*		the integer division will give the desired FLOOR value.
	*	3.) Multiply the granule number by the granule size, then add the spacecraft
	*		base time to obtain the granule start boundary time. Add the granule
	*		size to the granule start boundary time to obtain the granule end
	*		boundary time.
	* ----------------------------------------------------------------------
	*/
	public static long getStartBoundary(long arbitraryTime) {
		long elapsedTime = arbitraryTime - baseTime;
		long granuleNumber = elapsedTime / granuleSize;
		long startBoundary = (granuleNumber * granuleSize) + baseTime;
		return startBoundary;
	}

	public static long getEndBoundary(long arbitraryTime) {
		long elapsedTime = arbitraryTime - baseTime;
		long granuleNumber = elapsedTime / granuleSize;

		// Calculate and print granule ID. For logging purposes only
		long granuleIDValue = (granuleNumber * granuleSize) / 100000;
		//System.out.println("CERES-SCIENCE-RDR granule ID = " + granuleIDValue);

		long startBoundary = (granuleNumber * granuleSize) + baseTime;
		long endBoundary = startBoundary + granuleSize;
		return endBoundary;
	}
}
