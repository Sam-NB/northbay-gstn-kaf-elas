/*
Copyright (c) 1999-2007, United States Government, as represented by
the Administrator for The National Aeronautics and Space Administration.
All rights reserved.
*/

package gov.nasa.gsfc.drl.rtstps.core.output.rdr;

import gov.nasa.gsfc.drl.rtstps.core.RtStpsException;

/**
 * RT-STPS 5.7:
 * A class that contains static status variables, to assist with multi-mission and multi-spacecraft support.
 * These status variables are private and static, and contain synchronized get/set methods
 * 
 */
public class GlobalRDRStatus {

	/* 
	 * Define global status variables here:
	 */

	// Spacecraft ID. Default is S-NPP
	private static SpacecraftId G_SPID = SpacecraftId.npp;


	// Set & Get methods for Spacecraft ID:
	public static synchronized void setSpacecraftId (SpacecraftId newSPID){
		GlobalRDRStatus.G_SPID = newSPID;
	}
	public static synchronized SpacecraftId getSpacecraftId(){
		return GlobalRDRStatus.G_SPID;
	}
}
