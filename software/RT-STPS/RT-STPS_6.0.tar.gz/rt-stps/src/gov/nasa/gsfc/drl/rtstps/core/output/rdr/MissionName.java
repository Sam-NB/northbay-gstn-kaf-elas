/*
Copyright (c) 1999-2007, United States Government, as represented by
the Administrator for The National Aeronautics and Space Administration.
All rights reserved.
*/
package gov.nasa.gsfc.drl.rtstps.core.output.rdr;

/**
 * Official mission names
 * RT-STPS 5.7: Updated with JPSS-1/2
 *
 */
public enum MissionName {
	NPP("NPP"),
	NPOESS("N01"),
	JPSS_1("J01"),
	JPSS_2("J02"),
	GCOM_W("GW1"),
	NPP_NPOESS("N01");

	private String platformShortName;
	
	private MissionName(String platformShortName){
		this.platformShortName = platformShortName;
	} 

	/**
	 * Return the description of the identifier
	 * @return the description in a String
	 */
	public String getPlatformShortName(){
		return platformShortName;
	}

	@Override
	/**
	 * Returns the mission name as string, the _ is replaced with / in the NPP_NPOESS item.
	 * RT-STPS 5.7: For others, the _ is replaced with -
	 * @return a string of the name
	 */
	public String toString() {
		if(this.name().equals("NPP_NPOESS"))
			return this.name().replace('_', '/');
		else
			return this.name().replace('_', '-');
	}
}
