/*
	Copyright (c) 1999-2007, United States Government, as represented by
	the Administrator for The National Aeronautics and Space Administration.
	All rights reserved.
*/
package gov.nasa.gsfc.drl.rtstps.core.output.rdr.tools;

import gov.nasa.gsfc.drl.rtstps.core.RtStpsException;
import gov.nasa.gsfc.drl.rtstps.core.ccsds.Packet;
import gov.nasa.gsfc.drl.rtstps.core.ccsds.PacketI;
import gov.nasa.gsfc.drl.rtstps.core.output.rdr.PacketFactoryI;
import gov.nasa.gsfc.drl.rtstps.core.output.rdr.PDSDate;
import gov.nasa.gsfc.drl.rtstps.core.output.rdr.LeapDate;
import gov.nasa.gsfc.drl.rtstps.core.output.rdr.IETTime;

/* Import PacketKernel so we have a packet timestamp "wrapper" that is able
   to handle CUC time with varying byte offsets */
import gov.nasa.gsfc.drl.rtstps.core.xstps.pds.PacketKernel;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;

/**
 * 5.9a: Class that takes in a packet/PDS file and prints out all packet info in the order they are read
 *
 */
public class PacketReaderDriver {

	// Default buffer size for the packet reader is 1024 kB x 100
	public static final int BUFFER_SIZE = 1024 * 100;

	public static void main(String[] args) throws RtStpsException {

		// The first argument is the absolute path to packet file. Create 
		// the file packet reader object
		FilePacketReader fpr = new FilePacketReader(new CopyPacketFactory(), args[0]);

		// The second (optional) argument determines whether or not we print packets w/o secHdr
		boolean printPacketsNoSecHdr = true;
		if (args.length > 1) {
			printPacketsNoSecHdr = java.lang.Boolean.parseBoolean(args[1]);
		}

		/* The third (optional) argument is whether or not packets are expected to have CUC secondary
		   header timestamps. Default is false. */
		boolean isCUCTime = false;
		if (args.length > 2) {
			isCUCTime = java.lang.Boolean.parseBoolean(args[2]);
		}

		/* The fourth (optional) argument is the byte offset for the secondary header timestamp.
		   Default is 6 bytes, but some APIDs use a 7-byte (or more?) offset for the secondary
		   header timestamp. Adjust as necessary. */
		int secHdrTimeOffset = 6;
		if (args.length > 3) {
			secHdrTimeOffset = java.lang.Integer.parseInt(args[3]);
		}

		// Keep reading through the file until EOF is reached; print out packet information
		// in the order that they are read
		while(fpr.hasNext()){
			Packet packet = (Packet)fpr.next();

			// Print out warning if we get a null packet
			if(packet == null){
				System.out.println("WARNING - NULL PACKET");
				continue;
			}

			// Otherwise, get packet information:
			int appId = packet.getApplicationId();
			boolean secHdrFlag = packet.hasSecondaryHeader();
			int sequenceFlag = packet.getSequenceFlags();
			int sequenceCount = packet.getSequenceCounter();

			/* For the packet timestamp, we will use the PDS node's "PacketKernel" so we can handle
			   packets with "CUC" time or different byte offsets for the timestamp */
			PacketKernel packetKernel = new PacketKernel();
			packetKernel.set(packet, isCUCTime, secHdrTimeOffset);

			/* Now get the packet time from the packet's PacketKernel */
			long packetTimeStamp = 0L;
			if(secHdrFlag) packetTimeStamp = packetKernel.getPacketTime();

			/* This was corrected to use LeapDate.java instead of IETTime.java for IET time calculation */
			PDSDate packetPDSTime = LeapDate.ietToPDSNoLeap(LeapDate.getMicrosSinceEpoch(packetTimeStamp));

			// Determine the type of packet based on sequence flag
			char packetType = 'F';
			switch(sequenceFlag){
				case 0:
					packetType = 'M';
					break;
				case 1:
					packetType = 'F';
					break;
				case 2:
					packetType = 'L';
					break;
				case 3:
					packetType = 'S';
					break;
				default:
					packetType = '?';
					break;
			}

			// Now print out packet information if applicable
			if( printPacketsNoSecHdr || (!printPacketsNoSecHdr && secHdrFlag) ){
				System.out.println("APID: " + appId + "\tType: " + packetType + "\tSize(Bytes): " + packet.getPacketSize() + "\tSeqCnt: " + 
									sequenceCount + "\tSecHdr: " + secHdrFlag + "\tSecHdrTime: " + getReadablePDSTime(packetPDSTime, secHdrFlag));
			}
		}
	}

	/**
	 * Function that takes a LeapDate and returns its information in a human-readable String
	 */
	public static String getReadablePDSTime(PDSDate pdsdate, boolean sechdrflag){
		// If there's no secondary header, this doesn't apply; return N/A
		if(!sechdrflag) return "N/A";

		// Note that 1 is added to the month because PDSDate's month starts at zero, not 1.
		return ( "" + pdsdate.getYear() + "-" + (pdsdate.getMonth()+1) + "-" + pdsdate.getDayOfMonth() + " " +
				pdsdate.getHours() + ":" + pdsdate.getMinutes() + ":" + pdsdate.getSeconds() + ":" +
				pdsdate.getMilliseconds() + ":" + pdsdate.getMicroseconds() ); 
	}
}
