/*
Copyright (c) 1999-2007, United States Government, as represented by
the Administrator for The National Aeronautics and Space Administration.
All rights reserved.
*/
package gov.nasa.gsfc.drl.rtstps.rdrviewer;


import gov.nasa.gsfc.drl.rtstps.core.RtStpsException;
import gov.nasa.gsfc.drl.rtstps.core.output.rdr.AllDataReader;
import gov.nasa.gsfc.drl.rtstps.core.output.rdr.RDRAllReader;
import gov.nasa.gsfc.drl.rtstps.core.output.rdr.PacketTrackerList;
import gov.nasa.gsfc.drl.rtstps.core.output.rdr.PacketTrackerItem;
import gov.nasa.gsfc.drl.rtstps.core.output.rdr.RDRAppIdItem;
import gov.nasa.gsfc.drl.rtstps.core.output.rdr.RDRAppIdList;
import gov.nasa.gsfc.drl.rtstps.core.output.rdr.RDRFileReader;
import gov.nasa.gsfc.drl.rtstps.core.output.rdr.RDRName;
import gov.nasa.gsfc.drl.rtstps.core.output.rdr.RawApplicationPackets;
import gov.nasa.gsfc.drl.rtstps.core.output.rdr.StaticHeader;

// 6.0: Now needed for any RDR-related processing
import gov.nasa.gsfc.drl.rtstps.core.output.rdr.Definitions;

import java.util.List;

/**
 * Open an RDR file and locate the Spacecraft Diary granules.  Compare the times
 * stored in the granules with the times in its RawApplicationPackets through the reference
 * in the granule.  If the granule times do not encapsulate the RawApplicationPacket,
 * issue and error message.
 * 
 *
 */
public class PrintStaticHeader {
	
	private static void print(StaticHeader sh) throws RtStpsException {
		System.out.println("StaticHeader -- Satellite: " + sh.readSatelliteString());
		String sensor = sh.readSensorString();
		String typeID = sh.readTypeIDString();
		RDRName rdrName = RDRName.fromSensorAndTypeID(sensor, typeID);
		
		System.out.println("             -- Sensor: " + sensor);
		System.out.println("             -- TypeID: " + typeID);
		System.out.println("             -- NumAppIds: " + sh.readNumAppIds() + " -- should be: " + rdrName.getNumberOfAppIdsInRDR());
		
		System.out.println("             -- ApidListOffset  : " + sh.readApidListOffset());
		
		
		
		System.out.println("             -- PktTrackerOffset: " + sh.readPktTrackerOffset());
		System.out.println("             -- ApStorageOffset : " + sh.readApStorageOffset());
		
		System.out.println("             -- NextPktPos      : " + sh.readNextPktPos());
		
		System.out.println("             -- StartBoundary: " + sh.readStartBoundary());
		System.out.println("             -- EndBoundary  : " + sh.readEndBoundary());
		
		RDRAppIdList appIdList = sh.readRDRAppIdList();
		
		List<RDRAppIdItem> items = appIdList.getAppIdItemList();
		for (int i = 0; i < items.size(); i++) {
			RDRAppIdItem item = items.get(i);
			System.out.println("             -- AppIdItem[" + i + "] " );
			System.out.println("                -- Name            : " + item.getName());
			System.out.println("                -- AppId           : " + item.getValue());
			System.out.println("                -- PktsReserved    : " + item.getPktsReserved());
			System.out.println("                -- PktsReceived    : " + item.getPktsReceived());
			System.out.println("                -- PktTrackerIndex : " + item.getPktTrackerIndex());
		}
	
		// 5.8.1: Now get and print the packet tracker list
		PacketTrackerList pktTrackerList = sh.readPacketTrackerList();
		List<PacketTrackerItem> ptitems = pktTrackerList.getPacketTrackerItemList();
		System.out.println("\n*******START PACKET TRACKER LIST*******");

		for (int i = 0; i < ptitems.size(); i++){
			PacketTrackerItem ptitem = ptitems.get(i);
			System.out.println("[" + i + "] - obsTime: " + ptitem.getObsTime() + " sequenceNumber: " + ptitem.getSequenceNumber() +
								" size: " + ptitem.getSize() + " offset: " + ptitem.getOffset() + " fillPercent: " + ptitem.getFillPercent() );
		}
		System.out.println("\n*******END PACKET TRACKER LIST*******");
	}
	
	/**
	 * @param args the RDR HDF file
	 */
	public static void main(String[] args) {
		// 6.0: This now takes in two arguments; file path and mission name
		if (args.length < 1) {
			System.out.println("No file to process... ");
			System.exit(-1);
		}
		if (args.length < 2) {
			System.out.println("Mission name must be provided, e.g. NPP or JPSS-1 ");
			System.exit(-1);
		}

		try {
			// 6.0: Mission name is the second argument
			// 6.0: TODO as a workaround, we replace underscore with hyphen to accomodate for mission names
			// using "_" instead of "-" (e.g. JPSS_1 instead of JPSS-1). Make sure this workaround is removed
			// in the future once hard-coded enumsets are no longer used by RT-STPS
			String missionName = args[1].replace('_', '-');

			// 6.0: Initialize the Definitions class
			Definitions.initDefs(missionName);

			RDRFileReader readRDR = new RDRFileReader(args[0]);
			
			AllDataReader allDataReader = readRDR.createAllDataReader();
			
			while (allDataReader.hasNext()) {
				
				RDRAllReader rar = allDataReader.next();
				
				while (rar.hasNext()) {
					RawApplicationPackets rap = rar.next();
					
					StaticHeader sh = rap.getStaticHeader();
					
					PrintStaticHeader.print(sh);
					/***
					byte[] data = rap.getData();
					int offset = sh.getApStorageOffset();
					
					SequentialPacketReader spr = sh.createSequentialPacketReader();
					
					while (spr.hasNext()) {
						PacketI p = spr.next();
						
						//System.out.println("AppId=" + p.getApplicationId() + " Size: " + p.getPacketSize());
					}
					
					//System.out.println("Offset into storage area: " + offset);
					**/
					rap.close();
				}
				rar.close();
			}
			

			allDataReader.close();
			readRDR.close();

			// 6.0: Close the definitions class
			Definitions.clearDefs();

		}  catch (RtStpsException e) {
			
			e.printStackTrace();
	
		} 
	}



}
