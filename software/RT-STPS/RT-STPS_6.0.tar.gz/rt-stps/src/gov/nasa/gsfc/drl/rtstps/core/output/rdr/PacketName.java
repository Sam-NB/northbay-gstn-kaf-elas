/*
Copyright (c) 1999-2007, United States Government, as represented by
the Administrator for The National Aeronautics and Space Administration.
All rights reserved.
*/
package gov.nasa.gsfc.drl.rtstps.core.output.rdr;

// 6.0: Necessary imports as of RT-STPS 6.0
import java.util.Iterator;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Set;

/**
 * The following table is used by this package to determine which packets it receives are going to processed.
 * Each packet is given its official name from the JPSS/NPOESS documentation and the application identifier which is 
 * of critical importance.  The description and a group designation are given but are largely unused in this package.
 * (VIIRS are group or segmented packets but none of the other this package currently processes, ATMS and CRIS, are like this)
 * This table is used to when defining the RDR packages this will process see {@link RDRName}.
 *
 * 
 * RT-STPS 5.7: Added all APIDs for all JPSS-1/S-NPP RDR types...
 * Notes:
 *  - To clarify, "totalGroupCount" is the total number of CCSDS packets for ONE grouped packet of that APID, if it's even
 *    a grouped packet to begin with. If it's a standalone packet, this value is 1.
 */
public class PacketName {

	// 6.0: Adding the APID short name as one of the member variables
	private String apidShortName;

	// 6.0: Adding the RDR Collection Short Name (CSN) that this APID belongs to
	private String rdrShortName;

	// 6.0: Other member variables
	private String description;
	private int appId;
	private int totalGroupCount;

	// 6.0: Static data structure that keeps track of all PacketNames created and registered.
	// Make sure that this map is cleared during a pipeline flush(), to prepare for the next run.
	private final static HashMap<Integer, PacketName> packetNames = new HashMap<Integer, PacketName>();

	// 6.0: This will serve as the access lock to the static packet names hash map. A thread must have access
	// to this lock before it can read or write the packet names static hash map.
	private final static Object accessLock = new Object();

	/**
	 * 6.0: Constructor which accepts parameters parsed from the XML definitions file:
	 * @param apidShortName the short name of the APID, e.g. "CRITICAL", "DIARY", "ADCS_HKH", etc.
	 * @param rdrShortName the RDR Collection Short Name (CSN) this APID belongs to
	 * @param description APID description taken from the appropriate JPSS Data Dictionaries
	 * @param appId the packet's APID
	 * @param totalGrouCount total number of CCSDS packets for ONE grouped packet of that APID
	 */
	public PacketName(String apidShortName, String rdrShortName, String description, int appId, int totalGroupCount) {
		this.apidShortName = apidShortName;
		this.rdrShortName = rdrShortName;
		this.description = description;
		this.appId = appId;
		this.totalGroupCount = totalGroupCount;
	}

	/**
	 * 6.0: Return the appropriate Packet Name based on the application id
	 * @param appId
	 * @return one of Packets short names
	 */
	public static PacketName fromAppId(int appId) {
		// 6.0: No more need to handle special cases as these are now defined in each spaceraft's unique
		// XML definitions file
		PacketName returnVal = null;
		synchronized(accessLock){
			returnVal = packetNames.get(Integer.valueOf(appId));
		}

		// 6.0: Print a little warning if the desired Packet name wasn't found
		if(returnVal == null)
			System.out.println("WARNING - Unknown packet application ID: " + appId);

		return returnVal;
	}

	/**
	 * 6.0: Given an APID, return a string representing the RDR collection short
	 * name the APID belongs to. Returns null if APID is not found in the static
	 * map.
	 * @param packetApid the application identifier of a packet in the RDR
	 */
	public static String getRdrFromAppId(Integer packetApid){
		synchronized(accessLock){
			// 6.0: Return null immediately if the APID is not present in the static map
			if(!packetNames.containsKey(packetApid)){
				System.out.println("WARNING - Unknown packet application ID: " + 
									packetApid.intValue());
				return null;
			}

			// 6.0: Otherwise, return the rdrShortName of the appropriate PacketName. Check for
			// null values because HashMap allows them.
			PacketName tpname = packetNames.get(packetApid);
			if(tpname != null)
				return tpname.getRdrShortName();
			else
				return null;
		}
	}

	/**
	 * 6.0: Insert an Packet apid/PacketName key/value pair into the static map
	 * @param appId the application identifier of a packet in the RDR
	 * @param packetName the PacketName object to add
	 */
	public static void addPacketName(Integer packetApid, PacketName packetName){
		synchronized(accessLock){
			// 6.0: First check to see if the given Apid is already present
			if(packetNames.containsKey(packetApid)){
				System.out.println("WARNING - Packet name map already has APID " + 
									packetApid.intValue() + 
									"; replacing previous registration.");
			}

			// 6.0: Add it to the static Packet name map
			packetNames.put(packetApid, packetName);
		}
	}

	/**
	 * 6.0: Clear the static Packet names map
	 */
	public static void clearPacketNames(){
		// 6.0: Clear the RDR map
		synchronized(accessLock){
			packetNames.clear();
			System.out.println("INFO - Packet names map successfully cleared.");
		}
	}

	/**
	 * 6.0: Returns the number of Packet Names currently registered in the static map
	 */
	public static int packetCount(){
		// 6.0: Return the current number of Packet Names in the static map
		int rcount = 0;
		synchronized(accessLock){
			rcount = packetNames.size();
		}

		return rcount;
	}
	
	/**
	 * 6.0: Return the name of the packet. As of RT-STPS 6.0, this is identical to
	 * getApidShortName(); it is preserved for API backwards compatibility
	 * @return the name of the packet in a String
	 */
	public String toString() {
		// 6.0: Return this packet's APID short name
		return apidShortName;
	}
	/**
	 * 6.0: Return the APID short name
	 * @return string description
	 */
	public String getApidShortName(){
		return apidShortName;
	}
	/**
	 * 6.0: Return the RDR short name this APID belongs to
	 * @return string description
	 */
	public String getRdrShortName(){
		return rdrShortName;
	}
	/**
	 * Return the description
	 * @return string description
	 */
	public String getDescription() {
		return description;
	}
	
	/**
	 * Get the application id associate with the short name
	 * @return the application id
	 */
	public int getAppId() {
		return appId;
	}
	/**
	 * Return the number of total number of first, middle and last packets associated with the short name
	 * @return int count
	 */
	public int getTotalGroupCount() {
		return totalGroupCount;
	}
}
