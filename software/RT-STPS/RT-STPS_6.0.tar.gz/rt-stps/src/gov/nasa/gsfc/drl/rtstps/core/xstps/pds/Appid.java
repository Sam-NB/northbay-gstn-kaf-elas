/*
Copyright (c) 1999-2007, United States Government, as represented by
the Administrator for The National Aeronautics and Space Administration.
All rights reserved.
*/
package gov.nasa.gsfc.drl.rtstps.core.xstps.pds;
import gov.nasa.gsfc.drl.rtstps.core.Convert;
import gov.nasa.gsfc.drl.rtstps.core.RtStpsException;
import gov.nasa.gsfc.drl.rtstps.core.ccsds.Packet;

/**
 * This class accumulates information about one application id.
 * 
 */
final class Appid
{
	/*
	 * NPDS: An Appid object uses two PacketKernel objects: firstPacket and lastPacket.
	 * These will represent the first and last packets encountered which contain a
	 * secondary header (hence, timestamp). 
	 *
	 * In the case of an APID that lacks secondary headers, PacketKernel defaults all time
	 * information to zero values (which translate to epoch).
	 */
    private PacketKernel firstPacket;
    private PacketKernel lastPacket;

	/* NPDS 6.1: ESH time represents session time; these should still be calculated even if
	 * packets do not have secondary headers for packet time calculation. Basically, decouple
	 * packet time vs. session time calculations
	 */
	private PacketKernel lastPacketESH;
	private long firstESHtime = 0L;
	private long lastESHtime = 0L;

    private GapList gapList;
    private FillList fillList;
    private WrongLengthList wrongLengthList;
    private int reedSolomonCorrectedPackets = 0;
    private long firstByte;
    private long totalBytes = 0L;
    private int packets = 0;
    private int vcids;
    private int vcid1;
    private int vcid2 = -1;
    private int spid;
    private int id;
    private int timeOffset;
    private boolean discardBadLengthPackets = true;
    private boolean isQuicklookTypeEDS = false;
    private boolean hasCucSecondaryHeaderTime = false;

    /**
     * Create an application id object.
     * @param element a related XML element
     * @param defaultSpid a default spacecraft id, which may be overridden
     *          by a field in the element.
     * @param discardBadLengthPackets true=discard bad length packets
     * @param isQuicklookEDS true=this is a quicklook EDS
     */
    Appid(org.w3c.dom.Element element, int defaultSpid, boolean discardBadLengthPackets,
            boolean isQuicklookEDS) throws RtStpsException
    {
		// NPDS: Initialize PacketKernels so they can have default values:
        firstPacket = new PacketKernel();
        lastPacket = new PacketKernel();
		lastPacketESH = new PacketKernel();

        wrongLengthList = new WrongLengthList();
        fillList = new FillList();

        this.discardBadLengthPackets = discardBadLengthPackets;
        this.isQuicklookTypeEDS = isQuicklookEDS;

        id = Convert.toInteger(element,"id",0,0,2047);
        vcid1 = Convert.toInteger(element,"vcid",0,0,63);
        vcid2 = Convert.toInteger(element,"vcid2",-1,-1,63);
        if (vcid2 == -1)
        {
            vcid2 = 0;
            vcids = 1;
        }
        else
        {
            vcids = 2;
        }

        spid = Convert.toInteger(element,"spid",defaultSpid,0);

        timeOffset = Convert.toInteger(element,"timeOffset",6,6);
        hasCucSecondaryHeaderTime = Convert.toBoolean(element,"CUCtime",false);

        int stepsize = Convert.toInteger(element,"stepsize",1);
        if (stepsize == 0) stepsize = 1;

		// NPDS: Initialize GapList to keep track of gaps between packets
        gapList = new GapList(stepsize);
		gapList.setAPID(id);

        int min = Convert.toInteger(element,"minLength",-1);
        int max = Convert.toInteger(element,"maxLength",-1);

        if ((min != -1) || (max != -1))
        {
            wrongLengthList.setMinMaxLengths(min,max);
        }

        org.w3c.dom.NodeList nodes = element.getElementsByTagName("packetLength");
        for (int n = 0; n < nodes.getLength(); n++)
        {
            org.w3c.dom.Element e = (org.w3c.dom.Element)nodes.item(n);
            int len = Convert.toInteger(e,"length",0,15);
            wrongLengthList.addPacketLength(len);
        }
    }

    /**
     * Get the total number of fill bytes that are appended to short packets.
     */
    final long getTotalFillBytes()
    {
        return fillList.getTotalBytes();
    }

    /**
     * Get the number of packets that had an incorrect length. (deleted or not)
     */
    final int getTotalPacketsWithBadLength()
    {
        return wrongLengthList.getPacketCount();
    }

    /**
     * Get the number of gaps in sequence count.
     */
    final int getTotalGaps()
    {
        return gapList.getGapCount();
    }

    /**
     * Get the number of packets from Reed Solomon-corrected frames.
     */
    final int getReedSolomonCorrectedPacketCount()
    {
        return reedSolomonCorrectedPackets;
    }

    /**
     * Get the spacecraft id.
     */
    final int getSpacecraftId()
    {
        return spid;
    }

    /**
     * Get the application id.
     */
    final int getId()
    {
        return id;
    }

	/**
	 * 5.7.3a: Get functions for hasCucSecondaryHeaderTime
	 */
	public boolean getHasCucSecondaryHeaderTime(){
		return hasCucSecondaryHeaderTime;
	}

	/**
	 * 5.7.3a: Get functions for timeOffset
	 */
	public int getTimeOffset(){
		return timeOffset;
	}

    /**
     * Store a packet in this application ID.
     * @return false if the packet should be discarded
     */
    boolean putPacket(Packet packet, PacketKernel packetKernel, long offset)
    {
        boolean bad = wrongLengthList.check(packet);
        if (bad && discardBadLengthPackets) return false;

        byte[] data = packet.getData();

        /**
         * If I'm doing a quicklook-flag EDS, then I skip packets with the
         * flag turned off.
         */
        if (isQuicklookTypeEDS)
        {
            int flags = (timeOffset == 6)? 14 : 6;
            if (data[flags] == 0) return false;
        }

        // Load the packet kernel with the current packet.
        packetKernel.set(packet,hasCucSecondaryHeaderTime,timeOffset);
        ++packets;

		// NPDS 6.1: Record the ESH time(s) separately from packet times (decouple them)
		if(firstESHtime == 0L)
			firstESHtime = packetKernel.getEshTime();
		lastESHtime = packetKernel.getEshTime();

		// NPDS: Set this packet as "firstPacket" if it's the first packet we get with a secondary header
        //if (packets == 1)
		if ( firstPacket.isEmpty() && packetKernel.getSecHdrFlag() )
        {
            firstPacket.copy(packetKernel);
            firstByte = offset;
        }

		// NPDS 6.6 fix: Can't call GapList's completeGapItems() anymore; it has moved to GapList.java's check() method
		
		// NPDS 6.1 & 6.6: Gaps must still be checked even if secondary header doesn't exist!
		/** Post 5.7a fix: Requiring a non-empty PacketKernel before a gap check may cause the first seq. error to not be
		 * accounted for in the construction record. Hence, ALL packets are always checked for gaps regardless of PacketKernel
		 * status
		 */
        //if (!isQuicklookTypeEDS && !lastPacket.isEmpty())
		//if (!isQuicklookTypeEDS && !lastPacketESH.isEmpty())
		if (!isQuicklookTypeEDS)
        {
			/**
			 * NPDS 6.1/6.6: Pass both lastPacket and lastPacketESH:
			 * 1.) lastPacket - contains the earliest preceding packet time (secondary header) before gap
			 * 2.) lastPacketESH - contains packet ESH time of packet IMMEDIATELY before the gap
			 */
            //gapList.check(packet,packetKernel,lastPacket,offset);
			gapList.check(packet,packetKernel,lastPacket,lastPacketESH,offset);
        }

		// These lines must follow the gap check!

		// NPDS 6.1 & 6.6: Keep track of the latest packet's ESH time
		lastPacketESH.copy(packetKernel);

		// NPDS: Set this packet as "lastPacket" if it's the latest packet we get with a secondary header
		if ( packetKernel.getSecHdrFlag() ) {
        	lastPacket.copy(packetKernel);
		}

        fillList.check(packet,offset);

        if (packet.getFrameAnnotation().isRsCorrected)
        {
            ++reedSolomonCorrectedPackets;
        }

        totalBytes += packet.getSize();
        return true;
    }

    /**
     * Write information to the construction record file.
     */
    void printCS(java.io.DataOutput crecord) throws java.io.IOException
    {
        crecord.writeShort(spid);
        crecord.writeShort(id);
        crecord.writeLong(firstByte);
        crecord.writeInt(vcids);
        crecord.writeInt(vcid1 | (spid << 6));
        if (vcids == 2) crecord.writeInt(vcid2 | (spid << 6));

        gapList.printCS(crecord);
        fillList.printCS(crecord);
        wrongLengthList.printCS(crecord);

        crecord.writeLong(firstPacket.getPacketTime());
        crecord.writeLong(lastPacket.getPacketTime());

		// NPDS 6.1 Decouple session time from packet time calculation
        //crecord.writeLong(firstPacket.getEshTime());
        //crecord.writeLong(lastPacket.getEshTime());
		crecord.writeLong(firstESHtime);
		crecord.writeLong(lastESHtime);

        crecord.writeInt(reedSolomonCorrectedPackets);
        crecord.writeInt(packets);
        crecord.writeLong(totalBytes);
        crecord.writeLong(0L);
    }
}
