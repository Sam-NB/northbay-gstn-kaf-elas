/*
Copyright (c) 1999-2007, United States Government, as represented by
the Administrator for The National Aeronautics and Space Administration.
All rights reserved.
*/
package gov.nasa.gsfc.drl.rtstps.core.xstps.pds;
import gov.nasa.gsfc.drl.rtstps.core.ccsds.Packet;

// 5.7.3a: Importing these from RDR to do granulated S-PDS, and T-PDS
import gov.nasa.gsfc.drl.rtstps.core.output.rdr.LeapDate;
import gov.nasa.gsfc.drl.rtstps.core.output.rdr.PDSDate;

import java.io.BufferedOutputStream;
import java.io.DataOutput;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.util.Iterator;

/**
 * This class manages the output files. It deals with naming conventions and
 * switching between data files, which it hides from its user.
 * 
 * 
 */
class OutputFiles
{
    private java.util.ArrayList<DSFile> fileList = new java.util.ArrayList<DSFile>(10);	
    private long bytesPerFile = Long.MAX_VALUE;
    private PacketKernel previousPacketKernel = new PacketKernel();
    private long bytesWritten = 0;
    private DSFile currentFile;
    private StringBuffer fileNameTemplate;
    private String path;
    private OutputStream out;

	// NPDS: Come on, let's not hardcode the number of APIDs...
    //private int[] xappid = new int[3];
    //private int[] xspid = new int[3];

	// NPDS: Don't initialize these int arrays yet:
	private int[] xappid;
    private int[] xspid;
	private int numAPIDs;

	/**
	 * 5.7.3a: These time variables will be used to keep track of temporal ranges
	 * when creating T-PDS or granulated S-PDS/CSR files
	 */
	private long timespan = 0L;
	private long startBoundaryIET = 0L;
	private long endBoundaryIET = 0L;

	// 5.7.3a: This is now required to accomodate for granulation of S-PDS files
	private String PDSType = "S";

	// 5.7.3a: For internal IPOPP purposes. If true, use calculated granule boundaries
	// instead of packet times
	private boolean granCalc = false;

	// 5.9a: To determine whether this Sorcerer is dealing with multiple VCs
	private boolean multiVC = false;
	private ScanWriter scanWriter = null;

	// NPDS: This is for file naming purposes
	private java.text.DecimalFormat dffilenum;
	private java.text.DecimalFormat dfnumid;

    /**
     * Create an OutputFiles object.
     * @param constructionRecordName The construction record file name
     * @param path The directory where it will put the data files
     */
    OutputFiles(StringBuffer constructionRecordName, String path) throws IOException
    {
        fileNameTemplate = new StringBuffer(constructionRecordName.toString());
        fileNameTemplate.setCharAt(35,'1');
        this.path = path;

		// NPDS: Initialize int arrays to default size of 3:
		numAPIDs = 3;
		xappid = new int[numAPIDs];
		xspid = new int[numAPIDs];
	
		// NPDS: initialize the DecimalFormat for file naming purposes
		dffilenum = new java.text.DecimalFormat("00");
		dfnumid = new java.text.DecimalFormat("0");

        openFile();
    }

	/**
     * NPDS: Create an OutputFiles object.
     * @param constructionRecordName The construction record file name
     * @param path The directory where it will put the data files
	 * @param numapid The number of APIDs this PDS will contain
     */
	OutputFiles(StringBuffer constructionRecordName, String path, int numapid) throws IOException
	{
		fileNameTemplate = new StringBuffer(constructionRecordName.toString());
        fileNameTemplate.setCharAt(35,'1');
        this.path = path;

		// NPDS: Initialize int arrays to size of "numapid":
		numAPIDs = numapid;
		xappid = new int[numAPIDs];
		xspid = new int[numAPIDs];

		// NPDS: initialize the DecimalFormat for file naming purposes
		dffilenum = new java.text.DecimalFormat("00");
		dfnumid = new java.text.DecimalFormat("0");

        openFile();
	}

    /**
     * Set the number of bytes per file. By default, there is only one output
     * file.
     */
    final void setBytesPerFile(long length)
    {
        bytesPerFile = length;
    }

	/**
     * NPDS: Set the temporal range per file. By default, we generate S-PDS and do not
	 * care about temporal ranges
     */
	final void setPDSTemporalRange(long trange){
		timespan = trange;
	}

	/**
     * 5.7.3a: Set the PDS type, either "S" for S-PDS or "T" for T-PDS
     */
	final void setPDSType(String ptype){
		PDSType = ptype;
	}

	/**
     * 5.7.3a: Set the flag for granule calculation
     */
	final void calculateGranules(String mode){
		if(mode.equals("granulate"))
			granCalc = true;
		else
			granCalc = false;
	}

	/**
     * 5.7.3a: Returns IET start/end boundaries as CDS time. Does NOT remove
	 * leap seconds from the IET time!
     */
	public long getBoundaries(int bdry){
		// Determine which boundary we want
		long dbound = 0L;
		if(bdry == 0)
			dbound = startBoundaryIET;
		else
			dbound = endBoundaryIET;

		// Use PDSDate to convert IET to CDS time
		return PDSDate.ietToPDS(dbound).getOriginalPacketTime();
	}

	/**
	 * 5.9a: Set the flag for multiVC
	 * @param mvcflag boolean to represent presence of multi VCs
	 * @param windowsize int to represent size of sliding window
	 */
	final void setMultiVC(boolean mvcflag, int windowsize){
		multiVC = mvcflag;

		// Initialize the ScanWriter if multi VCs are expected
		if(multiVC){
			scanWriter = new ScanWriter(numAPIDs, windowsize);
		}
	}

    /**
     * Get the directory where this class is putting data files.
     */
    final String getPath()
    {
        return path;
    }

    /**
     * Set the application id and spacecraft id for a specific application
     * index. The index is an array index (0,1,2) and not an application id.
     */
    final void setAppidSpid(int apindex, int appid, int spid)
    {
        xappid[apindex] = appid;
        xspid[apindex] = spid;
    }

    /**
     * Get the number of created data files.
     */
    final int getFileCount()
    {
        return fileList.size();
    }

    /**
     * Open a file.
     */
    private void openFile() throws FileNotFoundException
    {
        String baseName = fileNameTemplate.toString();
        currentFile = new DSFile(path,baseName);
        FileOutputStream fos = new FileOutputStream(currentFile.file);
        out = new BufferedOutputStream(fos,8192);
    }

	/**
     * 5.7.3a: Function that takes in a packet kernel, and checks if that packet
	 * kernel's time exceeds the current granule end boundary. Only use this function
	 * for granulating S-PDS files, as it also calculates/adjusts end boundaries!
	 *
	 * Returns true if granule boundary is exceeded, false otherwise
     */
	public boolean check(PacketKernel packetKernel){
		// Only do the check if granule extent is defined, and if the packet has a secondary header
		if (timespan > 0L && packetKernel.getSecHdrFlag()) {
			// Calculate granule start boundary if it's still at default
			if(granCalc && startBoundaryIET == 0L){
				startBoundaryIET = PDSGranuleCalculator.getStartBoundary(LeapDate.getMicrosSinceEpoch(packetKernel.getPacketTime()),
																		PDSGranuleCalculator.getBaseTime(),
																		timespan);
			}
			// Granule end boundary hasn't been calculated yet, so calculate it
			if(endBoundaryIET == 0L){
				if(granCalc)
					endBoundaryIET = PDSGranuleCalculator.getEndBoundary(LeapDate.getMicrosSinceEpoch(packetKernel.getPacketTime()),
																		PDSGranuleCalculator.getBaseTime(),
																		timespan);
				else				
					endBoundaryIET = LeapDate.getMicrosSinceEpoch(packetKernel.getPacketTime()) + timespan;
				return false;
			}
			// Granule end boundary has been exceeded
			else if(LeapDate.getMicrosSinceEpoch(packetKernel.getPacketTime()) > endBoundaryIET){
				return true;
			}
		}
		// All other cases, return false to indicate granule boundary hasn't been exceeded
		return false;
	}

    /**
     * Write a packet to a data file.
     */
    void write(Packet packet, PacketKernel packetKernel, int apindex)
            throws IOException
    {
        long written = bytesWritten + packet.getSize();

		/**
		 * NPDS: For T-PDS purposes. Keep track of current packet time vs. PDS temporal range,
		 * and open up a new file if applicable
		 *
		 * 5.7.3a: Now also check if we are dealing with T-PDS first; skip this part for S-PDS
		 */
		if (PDSType.equals("T") && timespan > 0L && packetKernel.getSecHdrFlag()){
			if(endBoundaryIET == 0L){
				// NPDS: No end boundary calculated yet, so calculate one using this packet's timestamp
				endBoundaryIET = LeapDate.getMicrosSinceEpoch(packetKernel.getPacketTime()) + timespan;
			}
			else if(LeapDate.getMicrosSinceEpoch(packetKernel.getPacketTime()) > endBoundaryIET) {
				// NPDS: The current packet received now has timestamp that exceeds the current end boundary,
				// so packets now have to be placed in a new PDS file

				// Close the current file and add it to the list of files
				out.close();
		        fileList.add(currentFile);

				// Extract the unique file number (UFN) from the current file name
		        String ufn_string = fileNameTemplate.substring(34,36);

				// Increment UFN by one
		        int ufn = Integer.parseInt(ufn_string) + 1;
				
				// Special case - wraparound. If UFN exceeds 99, reset it to 01 but increment the filename's numeric identifier
				if(ufn > 99){
					ufn = 1;

					// Parse the numeric identifier from the file name
					 String numid_string = fileNameTemplate.substring(33,34);

					// Convert to integer, increment by one
					int numid_int = Integer.parseInt(numid_string) + 1;

					// Convert back to string, and update the current file name
					numid_string = dfnumid.format(numid_int);
					fileNameTemplate.replace(33,34,numid_string);
				}

				// Convert the new UFN back into a string
				ufn_string = dffilenum.format(ufn);

				// Now modify the current file name with the new UFN, and open a new file
		        fileNameTemplate.replace(36-ufn_string.length(),36,ufn_string);
		        openFile();

				// current file's written bytes get reset to zero + current packet size
		        written = packet.getSize();

				// finally, adjust the end boundary
				endBoundaryIET = LeapDate.getMicrosSinceEpoch(packetKernel.getPacketTime()) + timespan;
			}
		}

		// This is if "KBperFile" is specified and the packets have to be put into a new file
        if ((written > bytesPerFile) && !previousPacketKernel.isEmpty() &&
            (packetKernel.comparePacketTime(previousPacketKernel) > 0))
        {
            out.close();
            fileList.add(currentFile);
            String s = fileNameTemplate.substring(34,36);
            int n = Integer.parseInt(s) + 1;

			if(n > 99){
				n = 1;
				String numid_string = fileNameTemplate.substring(33,34);
				int numid_int = Integer.parseInt(numid_string) + 1;
				numid_string = dfnumid.format(numid_int);
				fileNameTemplate.replace(33,34,numid_string);
			}

            s = Integer.toString(n);
            fileNameTemplate.replace(36-s.length(),36,s);
            openFile();
            written = packet.getSize();
        }

        currentFile.ap[apindex].store(packetKernel);

		// 5.9a: If expecting multiple VCs, use ScanWriter
		if(multiVC && scanWriter != null)
			scanWriter.write(packet, out);
		else
        	out.write(packet.getData(),0,packet.getSize());

        bytesWritten = written;
        previousPacketKernel.copy(packetKernel);
    }

    /**
     * Close the current data file.
     */
    void close() throws IOException
    {
		// 5.9a: close the scan writer if applicable
		if(multiVC && scanWriter != null){
			scanWriter.close(out);
		}

        out.close();
        if (currentFile.hasData())
        {
            fileList.add(currentFile);
        }
        else
        {
            currentFile.file.delete();
        }
    }

    /**
     * Write file information to the construction record.
     */
    void writeCS(DataOutput crecord) throws IOException
    {
        Iterator<DSFile> i = fileList.iterator();
        while (i.hasNext())
        {
            DSFile file = (DSFile)i.next();
            crecord.writeBytes(file.id);
            
			int appids = numAPIDs;

			//*** NPDS2: This whole block has been deprecated so that APID info is still recorded in CSR even if
			// no packets have been received for it.
			//int appids = 0;
			// NPDS: Come on, let's not hard-code the number of APIDs please...			
            //if (file.ap[0].hasData) ++appids;
            //if (file.ap[1].hasData) ++appids;
            //if (file.ap[2].hasData) ++appids;
			//for (int n = 0; n < numAPIDs; n++){
			//	if (file.ap[n].hasData) ++appids;
			//}
			//***

            crecord.writeInt(appids);

            for (int n = 0; n < appids; n++)
            {
                Ap a = file.ap[n];
                crecord.writeShort(xspid[n]);
                crecord.writeShort(xappid[n]);
                crecord.writeLong(a.start);
                crecord.writeLong(a.stop);
                crecord.writeInt(0);
            }
        }
    }

    /**
     * This class holds a small amount of information about an
     * application id.
     */
    class Ap
    {
		// NPDS: The first and last times encountered for this APID
        long start = 0L;
        long stop = 0L;

		// NPDS: Must have TWO separate booleans, one to indicate that packets
		// have been received, and another to indicate that times have been obtained
        boolean hasData = false;
		boolean hasTime = false;

        void store(PacketKernel pk)
        {
			// NPDS: Only record timestamps from packets' secondary headers
			if(pk.getSecHdrFlag()){
		        stop = pk.getPacketTime();
		        //if (!hasData)
				if (!hasTime)
		        {
					//hasData = true;
					hasTime = true;
		            start = stop;
		        }
			}
			/* 
				NPDS TODO: Originally, APID was considered to "have data" when a timestamp is
				properly calculated. I believe this was to handle cases where a PDS file
				would only have "middle" CCSDS packets which have no timestamps (secondary header)

				Now, even in such a case, AP is now considered to "have data" as long as
				a packet has been received for it. This is done to account for EDOS ICD 6.1, 
				where HSK packets do NOT have secondary headers. How would this affect Sorcerer 
				as a whole?
			*/ 
			hasData = true;
        }
    }

    /**
     * This class holds information about one data file.
     */
    class DSFile
    {
        String id;

		// NPDS: Come on, let's not hard-code the number of APIDs...
        //Ap[] ap = new Ap[3];
		Ap[] ap = new Ap[numAPIDs];

        File file;  //complete file name spec

        DSFile(String directory, String filename)
        {
            file = new File(directory,filename);
            id = filename;

			// NPDS: Come on, let's not hard-code the number of APIDs...
            //ap[0] = new Ap();
            //ap[1] = new Ap();
            //ap[2] = new Ap();
			for (int g = 0; g < numAPIDs; g++){
				ap[g] = new Ap();
			}
        }

        boolean hasData()
        {
			// NPDS: Come on, let's not hard-code the number of APIDs...
            //return ap[0].hasData || ap[1].hasData || ap[2].hasData;
			for (int g = 0; g < numAPIDs; g++){
				if (ap[g].hasData)
					return ap[g].hasData;
			}
			return false;
        }

        public String toString()
        {
            return id;
        }
    }
}
