/*
Copyright (c) 1999-2007, United States Government, as represented by
the Administrator for The National Aeronautics and Space Administration.
All rights reserved.
*/
package gov.nasa.gsfc.drl.rtstps.core.output.rdr;

import gov.nasa.gsfc.drl.rtstps.core.RtStpsException;

/**
 * RT-STPS 5.7:
 * The generic specialization of the RDR class which creates the /All_Data/XXX-RDR_All and /Data_Products/XXX-RDR structures.
 * This overrides the createRawApplicationPackets method, the bulk of the work is still done by the base RDR class.
 * 
 */

public class Generic_RDR extends RDR {
	// 5.7: No need for this as stats is now a protected member in RDR.java
	//private Stats stats = null;
	private int scansPerGranule;

	/**
	 * Create a new instance of this class for building the RDR structures
	 * @param allData The {@link AllData} object which created the /All_Data structure
	 * @param dataProds The [@link DataProducts} objects which created the /Data_Products structure
	 * @param dev The Development domain is where the processing is being done, although passed in, this is fixed when the instance is created
	 * @param rdrname The RDRName that this generic RDR object will morph into
	 * @throws RtStpsException Wraps HDF library exceptions
	 */
	public Generic_RDR(AllData allData, DataProducts dataProds, SpacecraftId spid, FixedDomainDescription dev, RDRName rdrname) throws RtStpsException {
		super(null, rdrname, allData, dataProds, spid, dev);
		// FIXME: This may report inaccurate information, as some RDRs have variable scan rates
		scansPerGranule = rdrname.getGranuleSize();
	}

	public Generic_RDR(Stats stats, AllData allData, DataProducts dataProds, SpacecraftId spid, FixedDomainDescription dev, RDRName rdrname) throws RtStpsException {
		super(stats, rdrname, allData, dataProds, spid, dev);
		// 5.7: No need for this as stats is now a protected member in RDR.java
		//this.stats = stats;
		// FIXME: This may report inaccurate information, as some RDRs have variable scan rates
		scansPerGranule = rdrname.getGranuleSize();
	}

	/**
	 * Create the specific {@link GenericRawApplicationPackets}, this overrides the base RDR method
	 * @return RawApplicationPackets returns the instance as a generic {@link RawApplicationPackets} object
	 */
	protected RawApplicationPackets createRawApplicationPackets(RDRName rdrName) {
		RawApplicationPackets rap = new GenericRawApplicationPackets(stats, spid, getSetNum(), scansPerGranule, getPacketPool(), rdrName);
		this.getRaps().push(rap);
		return rap;
	}
}
