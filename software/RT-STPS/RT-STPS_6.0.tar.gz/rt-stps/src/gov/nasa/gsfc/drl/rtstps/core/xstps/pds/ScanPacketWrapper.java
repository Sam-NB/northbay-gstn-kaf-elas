/*
Copyright (c) 1999-2007, United States Government, as represented by
the Administrator for The National Aeronautics and Space Administration.
All rights reserved.
*/

package gov.nasa.gsfc.drl.rtstps.core.xstps.pds;

import gov.nasa.gsfc.drl.rtstps.core.ccsds.Packet;
import gov.nasa.gsfc.drl.rtstps.core.output.rdr.LeapDate;

import java.lang.System;

/**
 * Class that "deep-copies" packet payloads, and provides methods for
 * concatenating arrays
 */
public class ScanPacketWrapper{

	// byte array representing the overall packet payloads
	private byte[] payload = null;

	/**
	 * Default constructor
	 */
	public ScanPacketWrapper(){
		
	}

	/**
	 * Function that appends more data to existing instance
	 * @param newdata byte[] of new data to add
	 * @param length int number of elements to be copied
	 */
	public void addData(byte[] newdata, int length){
		byte[] newPayload;

		// Case where payload isn't initialized
		if(payload == null){
			// Initialize the new payload, and simply copy the new data to it
			newPayload = new byte[length];
			System.arraycopy(newdata, 0, newPayload, 0, length);
		}
		// Case where payload is initialized
		else{
			// Initialize the new payload with combined array lengths
			newPayload = new byte[payload.length + length];

			// First copy the current payload into the new payload
			System.arraycopy(payload, 0, newPayload, 0, payload.length);

			// Then append the new data to be added into the new payload
			System.arraycopy(newdata, 0, newPayload, payload.length, length);
		}

		// This instance's payload is now assigned to the new payload
		payload = newPayload;
	}

	/**
	 * Function that returns all of this instance's payload
	 */
	public byte[] getData(){
		return payload;
	}

	/**
	 * Cleanup function
	 */
	public void flushData(){
		payload = null;
	}
}
