/*
Copyright (c) 1999-2007, United States Government, as represented by
the Administrator for The National Aeronautics and Space Administration.
All rights reserved.
*/
package gov.nasa.gsfc.drl.rtstps.core.output.rdr;



import gov.nasa.gsfc.drl.rtstps.core.RtStpsException;
import gov.nasa.gsfc.drl.rtstps.core.ccsds.Packet;

import java.io.File;
import java.util.Date;
import java.util.LinkedList;
import java.util.List;
import java.util.UUID;

// ETR 1.3: ArrayList implementation of granulation window
import java.util.ArrayList;

/*
* This is the class that handles the proper creation/renaming of the actual
* HDF file generated from all of the CCSDS packets it receives.
*
* It uses an instance of the RDRCreateFile class to fill the contents of the
* HDF file according to standard JPSS RDR file format
*/
public class RDRFileWriter {
	
	private String tempFilename;
	private String destPath;

	// ETR 1.3: Limit to the size of the granulation window. Adjustable, but defaults at 2
	private int granuleWindowLimit = 2;

	// ETR 1.3: Using array list for a dynamic granulation window.
	private List<RDRCreateFile> granuleWindow = new ArrayList<RDRCreateFile>(granuleWindowLimit);

	// Specified granule time span for an RDR file
	private long granuleTimeSpan = 0L;	

	private Stats stats = null;
	private int orbit;
	private int rdrCount;
	private Origin distributor;
	private MissionName missionName;
	private Origin datasetSource;
	private PlatformShortName platformShortname;
	private boolean multiMode = false;

	public RDRFileWriter(String destPath, 
			int orbit, 
			int rdrCount, 
			Origin distributor, 
			MissionName missionName, 
			Origin datasetSource, 
			PlatformShortName platformShortname) throws RtStpsException {

		this.distributor = distributor;
		this.missionName = missionName;
		this.datasetSource = datasetSource;
		this.platformShortname = platformShortname;
		this.orbit = orbit;
		this.rdrCount = rdrCount;
		this.destPath = destPath;

		// Generate a random temp. filename for this HDF file...
		tempFilename = UUID.randomUUID().toString() + ".tmp";

		// 5.7 Set the global RDR status for Spacecraft ID
		GlobalRDRStatus.setSpacecraftId(SpacecraftId.valueOf(this.platformShortname.getSpacecraftID()));

		// ETR 1.3: Create an initial RDR and add it to the granule window
		addRDRToGranuleWindow();
	}
	
	public RDRFileWriter(Stats stats, 
			String destPath, 
			int orbit, 
			int rdrCount, 
			Origin distributor, 
			MissionName missionName, 
			Origin datasetSource, 
			PlatformShortName platformShortname,
			long gtspan ) throws RtStpsException {
		
		this.stats = stats;
		this.distributor = distributor;
		this.missionName = missionName;
		this.datasetSource = datasetSource;
		this.platformShortname = platformShortname;
		this.orbit = orbit;
		this.rdrCount = rdrCount;
		this.destPath = destPath;
		this.granuleTimeSpan = gtspan;

		// Generate a random temp. filename for this HDF file...
		tempFilename = UUID.randomUUID().toString() + ".tmp";

		// 5.7 Set the global RDR status for Spacecraft ID
		GlobalRDRStatus.setSpacecraftId(SpacecraftId.valueOf(this.platformShortname.getSpacecraftID()));

		// ETR 1.3: Create an initial RDR and add it to the granule window
		addRDRToGranuleWindow();
	}

	// Sets this class's multiMode boolean
	public void setMultiMode(boolean blv){
		this.multiMode = blv;
	}

	/**
	 * ETR 1.3: Set this class's granulation window size limit
	 * @param newlimit integer representing the new granulation window size limit
	 */
	public void setGranuleWindowLimit(int newlimit){
		if(newlimit > 0)
			this.granuleWindowLimit = newlimit;
	}

	/** 
	*	ETR 1.3: Internal method to add a new RDR to the granulation window
	*	@return integer indicating success (0) or failure (1)
	*/
	private int addRDRToGranuleWindow() throws RtStpsException{
		// ETR 1.3: Do not add to the granulation window if limit is reached
		if(granuleWindow.size() >= granuleWindowLimit)
			return 1;
		
		// ETR 1.3: Generate random file name
		String prelimFilename = UUID.randomUUID().toString() + ".tmp";

		// ETR 1.3: Then create the RDR and append it to the granulation window
		if(this.stats != null)
			granuleWindow.add(new RDRCreateFile(stats, destPath, prelimFilename, this.platformShortname, rdrCount, granuleTimeSpan));
		else
			granuleWindow.add(new RDRCreateFile(destPath, prelimFilename, this.platformShortname, rdrCount, granuleTimeSpan));

		return 0;
	}

	/** 
	*	ETR 1.3: Internal method to add a finalize the earliest RDR from the granulation window.
	*	This is mainly used in cases where an overflow of the granulation window occurs.
	*/
	private void finalizeEarliestRDR() throws RtStpsException{
		// ETR 1.3: Don't do anything if granulation window is empty
		if(granuleWindow.size() <= 0) return;

		//System.out.println("DEBUG - Granulation window reached limit: " + granuleWindow.size() +
		//					". Finalizing earliest RDR present in memory.");

		// ETR 1.3: Remove the first element of the granulation window
		RDRCreateFile tempRCF = granuleWindow.remove(0);

		// ETR 1.3: Get the co-temporal Spacecraft Diary granule
		RawApplicationPackets sd_overlap = tempRCF.getCurrentSpacecraftDiaryRAP();

		// ETR 1.3: If co-temporal spacecraft diary granule is not null, transfer it to the next RDR file.
		if(sd_overlap != null && granuleWindow.size() > 0){
			granuleWindow.get(0).createTransitioningSpacecraftDiaryRDR(sd_overlap);
		}

		// ETR 1.3: Finalize the RDR file
		Date creationDateAndTime = new Date();
		tempRCF.flushToDisk();
		finishFile(tempRCF, creationDateAndTime);
		rename(creationDateAndTime, tempRCF);
	}

	/**
	 * Put a CCSDS packet into this RDRFileWriter, which basically just calls the RDRCreateFile
	 * object's put(packet p) function...
	 *
	 * ETR 1.3: This entire method has been revamped to use the ArrayList implementation of the
	 * granulation window
	 *
	 * @param p packet to put into the RDR file(s)
	 */
	public void put(Packet p) throws RtStpsException {
		if(this.multiMode){
			// ETR 1.3: If window is currently empty, create and add an RDRCreateFile to it
			if(granuleWindow.size() == 0)
				addRDRToGranuleWindow();

			// ETR 1.3: Iterate through each RDR, but stop once the packet is added to an RDR
			int ctr = 0;
			while(ctr < granuleWindow.size()){
				// ETR 1.3: Get the RDR from the granulation window and attempt to put the packet in it
				RDRCreateFile tempRCF = granuleWindow.get(ctr);
				int toCurrentRDR = tempRCF.checkThenPut(p);

				if(toCurrentRDR == 0){
					/* ===== ETR 1.3: CASE 1 - Packet put successfully in this RDR. Just break. ===== */
					break;
				}
				else if(tempRCF.isComplete()){
					/* ===== ETR 1.3: CASE 2 - Packet not placed; this RDR is fully complete. ===== */

					// ETR 1.3: Pop this RDR from the window, which SHOULD shift subsequent elements by one step left
					granuleWindow.remove(ctr);

					// ETR 1.3: If there is a next RDR open, it'll be the current RDR. Else, create new RDR which will get any
					// co-temporal Spacecraft Diary granules (when ctr equals/exceeds the granule window no. of entries).
					if(ctr >= granuleWindow.size()){
						int addResult = addRDRToGranuleWindow();
						if(addResult != 0)
							System.out.println("WARNING - Failed to add to the granulation window!");
					}

					// ETR 1.3: Update current destPath and tempFilename
					this.destPath = tempRCF.getDestPath();
					this.tempFilename = tempRCF.getFilename();

					// ETR 1.3: Get the co-temporal Spacecraft Diary granule
					RawApplicationPackets sd_overlap = tempRCF.getCurrentSpacecraftDiaryRAP();

					// ETR 1.3: If co-temporal spacecraft diary granule is not null, transfer it to the new RDR file.
					// NOTE: ctr should now point to the next RDR, either newly created or shifted to the left.
					if(sd_overlap != null && ctr < granuleWindow.size()){
						granuleWindow.get(ctr).createTransitioningSpacecraftDiaryRDR(sd_overlap);
					}

					// ETR 1.3: Finalize the old file, and put the new packet into the new file
					Date creationDateAndTime = new Date();
					tempRCF.flushToDisk();
					finishFile(tempRCF, creationDateAndTime);
					rename(creationDateAndTime, tempRCF);

					// ETR 1.3: We don't increment the counter, which should allow the next loop iteration to point to 
					// the new granule which now has the same "ctr" index after left-shift due to the removal from
					// granuleWindow
				}
				else{
					/* ===== ETR 1.3: CASE 3 - Packet not placed; either main or spacecraft diary granules are complete ===== */

					// ETR 1.3: Create next RDR file, if it doesn't exist yet
					if((ctr + 1) >= granuleWindow.size()){
						// ETR 1.3: If granulation window is full, make room by finalizing the earliest granule
						if(granuleWindow.size() >= granuleWindowLimit)
							finalizeEarliestRDR();

						// ETR 1.3: Then create a new RDR file
						int addResult = addRDRToGranuleWindow();
						if(addResult != 0){
							System.out.println("WARNING - Granulation window full, and could not free up space!");
							break;
						}
					}

					// ETR 1.3: If signal received is SPACECRAFT_DIARIES_COMPLETE, this packet is an SD packet that 
					// already exceeds current RDR's SD encapsulation. Hence, copy the co-temporal SD granule.
					if( toCurrentRDR == RDRCreateFile.SPACECRAFT_DIARIES_COMPLETE ){
						// Get the co-temporal Spacecraft Diary granule
						RawApplicationPackets sd_overlap = tempRCF.getCurrentSpacecraftDiaryRAP();
				
						// If co-temporal spacecraft diary granule is not null, transfer it to the new RDR file
						if(sd_overlap != null){
							granuleWindow.get(ctr+1).createTransitioningSpacecraftDiaryRDR(sd_overlap);
						}
					}

					// ETR 1.3: Else, it's science data that exceeds the current RDR's science data span.
					// Just let it be put in the next RDR
					ctr++;
				}
			}
		}
		else{
			granuleWindow.get(0).put(p);
		}
	}

	/**
	 * Function to perform finalization and cleanup of RDR files
	 * @param hdfCleanup boolean indicating whether to clean up HDF5 objects
	 */
	public void close(boolean hdfCleanup) throws RtStpsException {
		
		Date creationDateAndTime = new Date();
			
		// ETR 1.3: Some RDRs remaining in the granulation window may not have co-temporal
		// Spacecraft Diary RDR granules upon close
		for(int c = 0; c < granuleWindow.size(); c++){
			if((c + 1) < granuleWindow.size()){
				RDRCreateFile rdrNext = granuleWindow.get(c+1);
				if(!rdrNext.hasSpacecraftDiary()){
					RawApplicationPackets sd_overlap = granuleWindow.get(c).getCurrentSpacecraftDiaryRAP();

					// 5.7: Added a null check before attempting a write
					if(sd_overlap != null){
						System.out.println("INFO - Copying co-temporal Spacecraft Diary granules to final RDR files");
						rdrNext.createTransitioningSpacecraftDiaryRDR(sd_overlap);
					}
				}
			}
		}

		// Close all RDR files, before entire HDF5 library is closed and flushed
		closeAll(creationDateAndTime);

		// No more need for HDF5 library, so flush it and free up all resources used
		if(hdfCleanup){
			HDF5Util.cleanup();
		}

		// Once HDF5 library is closed and freed up, rename RDR files to proper filenames
		finalizeAll(creationDateAndTime);

		// ETR 1.3: Null out the entire granulation window
		granuleWindow.clear();
	}

	/**
	 * Function to close all RDR files
	 * @param creationDateAndTime Date representing creation date/time of RDR files
	 */
	private void closeAll(Date creationDateAndTime) throws RtStpsException{
		// ETR 1.3: Close all RDR files in the granule window
		for(int cnt = 0; cnt < granuleWindow.size(); cnt++){
			finishFile(granuleWindow.get(cnt), creationDateAndTime);
		}
	}

	/**
	 * Function to rename all RDR files to final filenames
	 * @param creationDateAndTime Date representing creation date/time of RDR files
	 */
	private void finalizeAll(Date creationDateAndTime) throws RtStpsException{
		// ETR 1.3: Finalize all RDR files in the granule window
		for(int cnt = 0; cnt < granuleWindow.size(); cnt++){
			rename(creationDateAndTime, granuleWindow.get(cnt));
		}
	}

	/**
	 * Function to close an RDR file
	 * @param target RDR file to close
	 * @param creationDateAndTime Date representing creation date/time of RDR files
	 */
	private void finishFile(RDRCreateFile target, Date creationDateAndTime) throws RtStpsException{
		if(target != null){
			// Write attributes to the RDR file
			try{
				writeAttributes(creationDateAndTime, target);
			}
			catch (RtStpsException e){
				System.out.println("WARNING - finishFile() could not write attributes; skipping file...");				
			}
			// Now close the RDRCreateFile. This closes all "RDR" objects, which then
			// closes all RAPs, HDF5 groups/datasets, etc, and frees up resources
			try{
				target.close();
			}
			catch (RtStpsException e){
				// Regular close failed for some reason. Force close and free up all resources!
				target.closeAllRaps();
				System.out.println("WARNING - finishFile(): RDR file force closed!");
			}
		}
	}

	/**
	 * Function to write attributes to an RDR file
	 * @param creationDateAndTime Date representing creation date/time of RDR files
	 * @param target RDR file to close
	 */
	private void writeAttributes(Date creationDateAndTime, RDRCreateFile target) throws RtStpsException {
		target.writeAttributes(creationDateAndTime, distributor, this.missionName, this.datasetSource, platformShortname);
		//System.out.println("writeAttributes completed");
	}

	/**
	 * Function to rename an RDR file to its final filename
	 * @param creationDateAndTime Date representing creation date/time of RDR files
	 * @param target RDR file to rename
	 */
	private void rename(Date creationDateAndTime, RDRCreateFile target) throws RtStpsException{
		if( target == null ) {
			return;		
		}

		// Grab the current HDF file, which should still have its temp filename
		File old = new File(target.getDestPath(), target.getFilename());
		// We get a list of all the XXX-RDR groups; RDR groups should have all info we need to
		// identify the instrument (for the filename)
		List<RDR> rdrs = target.getRDRs();

		// Check for null aggregates.
		// If any are null, we won't be able to write the RDR
		// as it checks aggregates for timestamps
		for(int i = 0; i < rdrs.size(); i++) {
			// Check the Aggregates of each RDR handled by this RDRFileWriter
			// E.g. if it only handles VIIRS-SCIENCE-RDR, then only VIIRS-SCIENCE-RDR_Aggr is checked
			if(rdrs.get(i).getAggregate() == null){
				rdrs.remove(i);
			}
		}
		
		// 5.7: If there are no RDRs created at all, just delete the tmp file as it will have no data
		if (rdrs.size() <= 0) { 
			System.out.println("INFO - No data found in RDR, will delete temp file: " + target.getFilename());
			old.delete();	
			return;
		}
		// look for RDRs that only contain NPP ephemeris data
		// if one is found, do not rename file, and delete old temp file handle
		// 6.0: Treat RDR Name as a class and no longer an enum
		else if ( (rdrs.size() == 1) && (rdrs.get(0).getRDRName().getRDRStringName().equals("SPACECRAFT-DIARY-RDR")) ){
			System.out.println("INFO - No non-diary data in RDR, cannot write file " + target.getFilename());
			old.delete();
			return;
		}
		
		Aggregate firstAgg = findFirstScienceWeightedAggregate(rdrs);
		PDSDate temp1 = null; 
		PDSDate d1 = null;
		PDSDate d2 = null;
		
		// LPEATE seems to want the original data based times not the rounded/truncated times in the file name
		try { 
			temp1 = firstAgg.getBeginningDateTime();
			d1 = new PDSDate(temp1.getOriginalPacketTime());
			d2 = firstAgg.getEndingDateTime();	
		} 
		// FILE can't be written due to no/null aggregate; delete it.
		catch (NullPointerException e){	
			System.out.println("INFO - No data found in RDR, will delete temp file: " + target.getFilename());
			old.delete();
			return;
		}
		
		if (rdrs == null) return;
		if (rdrs.size() <= 0) return;
		if ((d1 == null) || (d2 == null)) return;
		
		// Create an NPOESSFilename object with the obtained information so far; this
		// will assemble the proper RDR filename for us (with correct instrument/timestamps)
		//NPOESSFilename nfn = new NPOESSFilename(rdrs, d1, d2, creationDateAndTime,
		//					SpacecraftId.npp, orbit, Origin.all);

		NPOESSFilename nfn = new NPOESSFilename(rdrs, d1, d2, creationDateAndTime,
							SpacecraftId.valueOf(platformShortname.getSpacecraftID()), orbit, Origin.all);
		
		// Finally, rename the temp file to its proper filename and create a new user block
		createUserBlock(old, target);
		String realFilename = nfn.toString();
		File nnew = new File(target.getDestPath(), realFilename);
		old.renameTo(nnew);
		//createUserBlock(nnew, target);
	}	

	/** 
	 * Given a List of XXX-RDR groups, it searches SCIENCE RDR groups for their XXX-RDR_Aggr (Aggregates)
	 * @param rdrs a List of RDRs to peruse
	 */
	private Aggregate findFirstScienceWeightedAggregate(List<RDR> rdrs) throws RtStpsException {
		// Initialize a List of RDRs which will only contain all RDRs (naming is due to legacy implementation)
		List<RDR> sciRDRs = new LinkedList<RDR>();
		RDR diaryRDR = null;
		// Loop through all RDR groups in the given list
		for (RDR rdr : rdrs) {
			// double-check for null aggregates
			if(rdr.getAggregate() == null)
				continue;
			
			// Avoid using toString() with RDRName; instead use the specialized getRDRStringName().
			String rdrNameStr = rdr.getRDRName().getRDRStringName();

			/* 5.7: Removing the SCIENCE-only limitation, as RT-STPS now supports all RDR types
			// If SCIENCE RDR, add it to the sciRDR List
			if (rdrNameStr.contains("SCIENCE")) {
				sciRDRs.add(rdr);
			}
			// If DIARY RDR, assign it to the diaryRDR variable (in the end, it will hold the latest) 
			else if (rdrNameStr.contains("DIARY")) {
				diaryRDR = rdr;
			}
			// Else, throw an exception because this RDR is not supported. 
			else {
				throw new RtStpsException("No support for non-science/non-diary RDRs [" + rdrNameStr + "]");
			}
			*/

			// 5.7: The block of code commented above is replaced with the following:
			if (rdrNameStr.contains("DIARY")) {
				diaryRDR = rdr;
			}
			else {
				sciRDRs.add(rdr);
			}
		}
		
		// If no RDRs were found, then we cannot get the desired Aggregates...
		if ((sciRDRs.size() <= 0) && (diaryRDR == null)) {
			return null;
			//throw new RtStpsException("No science/diary RDRs found -- unable to get first/last time for filename");			
		}
	
		// If there are any XXX-RDR groups, use their aggregates. Else, use Diary's.
		Aggregate firstAggregate = null;
		if (sciRDRs.size() > 0) {
			// If multiple XXX-RDR groups exist, sort each group's Aggregate by 
			// beginningDateTime and return the earliest.
			firstAggregate = findFirstAggregate(sciRDRs);
		} else {
			// Otherwise, there MUST be a non-null diary right?
			firstAggregate = diaryRDR.getAggregate();
		}
		
		return firstAggregate;
	}

	/** 
	 * Loop through RDRs and find the earliest RDR aggregate by beginningDateTime
	 * @param rdrs a List of RDRs to peruse
	 */
	private Aggregate findFirstAggregate(List<RDR> rdrs) {
		Aggregate firstAgg = null;
		long firstMicros = 0L;
		
		for (RDR rdr : rdrs) {
			Aggregate agg = rdr.getAggregate();
			if(agg == null)
				continue;
			long micros = agg.getBeginningDateTime().getMicrosSinceEpoch();
			
			if (firstMicros == 0L) {
				firstMicros = micros;
				firstAgg = agg;
			} else if (micros < firstMicros) {
				firstMicros = micros;
				firstAgg = agg;
			}
		}
		return firstAgg;
	}

	/** 
	 * Loop through RDRs and find the earliest RDR aggregate by beginningDateTime
	 * 5.7: Removed "NPP" hardcoding to enable support for other spacecrafts/missions
	 * @param file File object representing the RDR
	 * @param target RDR to create user block for
	 */
	private void createUserBlock(File file, RDRCreateFile target) throws RtStpsException {
		
		List<RDR> rdrs = target.getRDRs();
		
		if (rdrs == null) return;
		if (rdrs.size() <= 0) return;
		
		//UserBlock userBlock = new UserBlock(MissionName.NPP, PlatformShortName.NPP, rdrs);
		UserBlock userBlock = new UserBlock(missionName, platformShortname, rdrs);
		userBlock.write(file);
		userBlock.close();
	}

	/**
	 * Prints out RDR products
	 */
	public String toString() {
		// ETR 1.3: Changed the command to get the RDR from the granulation window
		return NPOESSFilename.productIdsToString(granuleWindow.get(0).getRDRs());
	}

	/**
	* Sets the desired granule time span for RDR files
	* @param timespan Desired granule time span (in microseconds) for RDR files
	*/
	public void setTimeSpan(long timespan){
		this.granuleTimeSpan = timespan;
	}
}
