/*
Copyright (c) 1999-2007, United States Government, as represented by
the Administrator for The National Aeronautics and Space Administration.
All rights reserved.
*/
package gov.nasa.gsfc.drl.rtstps.core.output.rdr;

import gov.nasa.gsfc.drl.rtstps.core.RtStpsException;

import java.text.ParseException;

public class GenericGranule extends Granule {
	// Granule size in microseconds
	private long granuleSize;

	// S-NPP's base epoch time, used for calculating granule boundaries!
	// TODO: Are these still applicable for JPSS-1?
	private static long baseTime = 1698019234000000L;
	private static boolean baseTimeSet = false;	
	
	// Various member variables:
	private LPEATEDate firstDateTime;
	private LPEATEDate lastDateTime;

	private PDSDate predictedEndDateTime;
	private PDSDate beginningTimeDateTime;
	private PDSDate predictedEndingTimeDateTime;

	private RDRName rdrname;

	public static boolean isBaseTimeSet() {
		return GenericGranule.baseTimeSet;
	}

	public static void setBaseTimeSet(boolean baseTimeSet) {
		GenericGranule.baseTimeSet = baseTimeSet;
	}

	public static long getBaseTime() {
		return GenericGranule.baseTime;
	}

	public static void setBaseTime() {
		// Uses the S-NPP base time
		GenericGranule.baseTimeSet = true;
	}

	public static void setBaseTime(long baseTime) {
		long baseTimedivide = baseTime / 1000000;
		long baseTimeEvenSecond = baseTimedivide * 1000000;
		GenericGranule.baseTime = baseTimeEvenSecond;
		System.out.println("INFO - GenericGranule baseTime changed to = " + GenericGranule.baseTime);
		GenericGranule.baseTimeSet = true;
	}

	/**
	 * Constructor for a Granule instance, the arguments are associated with the granule's attributes.
	 * An instance of this class in this packet is created by some other factory method.
	 * 
	 * @param rap the corresponding RawApplicationPackets area
	 * @param orbit the orbit number of the pass
	 * @param granuleId the granuleId {@link GranuleId}
	 * @param leoaState the LEO state flag
	 * @param docName the document name of the specification controlling this granules construction
	 * @param packetTypes an array of packet types received in this granule
	 * @param packetTypeCounts the counts per type of the packets received
	 * @param referenceId the reference identifier which is a UUID {@link java.util.UUID}
	 * @param granuleNumber the granule number which corresponds to the RawApplicationPackets number in the RDR/HDF file
	 * @param dataSpaceOfRaw the HDF DataSpace handle of the RawApplicationPackets area associated with this granule
	 */
	public GenericGranule(RawApplicationPackets rap,
					long orbit,
					GranuleId granuleId,
					LEOAFlag leoaState,
					String docName,
					String[] packetTypes,
					long[] packetTypeCounts,
					ReferenceId referenceId,
					int granuleNumber, 
					int dataSpaceOfRaw,
					RDRName rdrname) {

		super(rap, 
			orbit, 
			granuleId, 
			leoaState, 
			docName, 
			packetTypes, 
			packetTypeCounts, 
			referenceId, 
			granuleNumber,  
			dataSpaceOfRaw,
			rdrname);

		// Upon creation, record the RDRName
		this.rdrname = rdrname;

		// Use the RDRName to obtain this instance's granule size
		this.granuleSize = GranuleBoundaryCalculator.getGranuleSize(this.rdrname);
	}

	/**
	 * Read the Granule out of the HDF file and fill in the various attributes and items in it for
	 * these access methods
	 * @param groupId the HDF group handle
	 * @param granuleName  the name of the granule
	 * @throws ParseException 
	 */
	public GenericGranule(int groupId, String granuleName) throws RtStpsException {
		super(groupId, granuleName);
	}

	/**
	 * Abstract implementation, but is not applicable for the case of GenericGranule.
	 * returns an invalid value.
	 *
	 * Grep of source tree doesn't reveal any invocations of this method.
	 */
	long getScansPerGranule() {
		return -1L;
	}

	/**
	* (Abstract method implementation)
	* Returns the beginning observation date time, as a PDSDate object
	*/
	public PDSDate getBeginningObservationDateTime(RawApplicationPackets rap) {
		this.firstDateTime = new LPEATEDate(rap.getFirstTime());
		return this.firstDateTime;
	}

	/**
	* (Abstract method implementation)
	* Returns the ending observation date time, as a PDSDate object
	*/
	public PDSDate getEndingObservationDateTime(RawApplicationPackets rap) {
		this.lastDateTime = new LPEATEDate(rap.getLastTime());
		
		// TODO: What is this for? What was the rationale for 50000L?
		// Is a private member, and has no "get" function. So it's unused...
		//this.predictedEndDateTime = firstDateTime.addMicros(getEndOffSet() + 50000L);
		
		return this.lastDateTime;
	}

	/**
	* (Abstract method implementation)
	* Returns the beginning date time, as a PDSDate object. This requires the 
	* Granule's beginning IET to be calculated first!
	*/
	public PDSDate getBeginningTimeDateTime() {
		this.beginningTimeDateTime = LeapDate.ietToPDSNoLeap( getBeginningIET() );
		return beginningTimeDateTime;
	}

	/**
	* (Abstract method implementation)
	* Returns the ending date time, as a PDSDate object. This requires the 
	* Granule's ending IET to be calculated first!
	*/
	public PDSDate getEndingTimeDateTime() {
		this.predictedEndingTimeDateTime = LeapDate.ietToPDSNoLeap( getEndingIET() );
		return predictedEndingTimeDateTime;
	}

	// GenericGranule has no getStartBoundary or getEndBoundary; use GranuleBoundaryCalculator instead!
}
