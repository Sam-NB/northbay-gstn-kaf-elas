#!/bin/bash -e

ARCH=`uname -m`
if [ ${ARCH} == 'x86_64' ]; then

# 64-bit linux
HDF="./lib/hdf-java-2.7/linux64/hdf-java/lib"
HDF_LIB="linux"

elif [ $(ARCH) == 'ia64' ]; then

# 64-bit itanium
HDF="./lib/hdf-java-2.7/linux64i/hdf-java/lib"
HDF_LIB="linux"

else 

# 32-bit linux
HDF="./lib/hdf-java-2.7/linux32/hdf-java/lib"
HDF_LIB="linux"

fi
#find ./classes/* -not -iwholename '*.svn*' -type f -exec rm -rf {} \;
#rm -rf classes/*
javac -d ./classes -classpath ./classes:./lib/nsls.jar:\
$HDF/fits.jar:\
$HDF/jhdf.jar:\
$HDF/jhdf4obj.jar:\
$HDF/jhdf5.jar:\
$HDF/jhdf5obj.jar:\
$HDF/jhdfobj.jar:\
$HDF/jhdfview.jar:\
$HDF/junit.jar:\
$HDF/netcdf.jar:\
$HDF/ext/fitsobj.jar:\
$HDF/ext/nc2obj.jar \
src/gov/nasa/gsfc/drl/rtstps/*.java \
src/gov/nasa/gsfc/drl/rtstps/clients/*.java \
src/gov/nasa/gsfc/drl/rtstps/clients/spooler/*.java \
src/gov/nasa/gsfc/drl/rtstps/core/*.java \
src/gov/nasa/gsfc/drl/rtstps/core/ccsds/*.java \
src/gov/nasa/gsfc/drl/rtstps/core/ccsds/path/*.java \
src/gov/nasa/gsfc/drl/rtstps/core/fs/*.java \
src/gov/nasa/gsfc/drl/rtstps/core/fs/clock/*.java \
src/gov/nasa/gsfc/drl/rtstps/core/output/rdr/*.java \
src/gov/nasa/gsfc/drl/rtstps/core/output/rdr/tools/*.java \
src/gov/nasa/gsfc/drl/rtstps/core/output/*.java \
src/gov/nasa/gsfc/drl/rtstps/core/status/*.java \
src/gov/nasa/gsfc/drl/rtstps/core/xstps/*.java \
src/gov/nasa/gsfc/drl/rtstps/core/xstps/pds/*.java \
src/gov/nasa/gsfc/drl/rtstps/library/*.java \
src/gov/nasa/gsfc/drl/rtstps/library/layout/*.java \
src/gov/nasa/gsfc/drl/rtstps/sender/*.java \
src/gov/nasa/gsfc/drl/rtstps/server/*.java \
src/gov/nasa/gsfc/drl/rtstps/testing/*.java \
src/gov/nasa/gsfc/drl/rtstps/viewer/*.java \
src/gov/nasa/gsfc/drl/rtstps/viewer/bulbs/*.java \
src/gov/nasa/gsfc/drl/rtstps/viewer/commands/*.java \
src/gov/nasa/gsfc/drl/rtstps/viewer/path/*.java \
src/gov/nasa/gsfc/drl/rtstps/viewer/status/*.java \
src/gov/nasa/gsfc/drl/rtstps/viewer/tables/*.java \
src/gov/nasa/gsfc/drl/rtstps/rdrviewer/*.java

rmic -classpath ./classes:./lib/nsls.jar -d ./classes gov.nasa.gsfc.drl.rtstps.server.AbstractServer

jar -cf ./lib/rt-stps.jar -C ./classes . -C . images

#cd jsw/bin

# make sure the wrappers are executable
#chmod +x wrapper-*
#chmod +x wrapper-*

#if [ -f wrapper.lnk ]; then
#	echo "Removing old wrapper.lnk"
#	rm -f wrapper.lnk
#fi
#if [ -f wrapper ]; then
#	echo "Removing old wrapper symbolic link"
#	rm -f wrapper
#fi



#if [ ${ARCH} == 'x86_64' ]; then

# 64-bit linux
#echo "Creating wrapper symbolic link to wrapper-64"
#ln -s wrapper-64 wrapper

#elif [ $(ARCH) == 'ia64' ]; then

# 64-bit itanium
#echo "Creating wrapper symbolic link to wrapper-64"
#ln -s wrapper-64 wrapper

#else 

# 32-bit linux
#echo "Creating wrapper symbolic link to wrapper-32"
#ln -s wrapper-32 wrapper
#fi



#cd ../..

#cd jsw/lib

#if [ -f libwrapper.so ]; then
#	echo "Removing old wrapper.so symbolic link"
#	rm -f libwrapper.so
#fi


#if [ ${ARCH} == 'x86_64' ]; then

# 64-bit linux
#echo "Creating wrapper.so symbolic link to libwrapper-64.so"
#ln -s libwrapper-64.so libwrapper.so

#elif [ $(ARCH) == 'ia64' ]; then

# 64-bit itanium
#echo "Creating wrapper.so symbolic link to libwrapper-64.so"
#ln -s libwrapper-64.so libwrapper.so

#else 

# 32-bit linux
#echo "Creating wrapper.so symbolic link to libwrapper-32.so"
#ln -s libwrapper-32.so libwrapper.so
#fi


#cd ../..

cd jsw/conf

if [ -f rt-stps-server.conf ]; then
	echo "Removing old rt-stps-server.conf symbolic link"
	rm -f rt-stps-server.conf
fi


if [ ${ARCH} == 'x86_64' ]; then

# 64-bit linux
echo "Creating rt-stps-server.conf symbolic link to rt-stps-server64.conf"
ln -s rt-stps-server64.conf rt-stps-server.conf

elif [ $(ARCH) == 'ia64' ]; then

# 64-bit itanium
echo "Creating rt-stps-server.conf symbolic link to rt-stps-server64i.conf"
ln -s rt-stps-server64i.conf rt-stps-server.conf

else 

# 32-bit linux
echo "Creating rt-stps-server.conf symbolic link to rt-stps-server32.conf"
ln -s rt-stps-server32.conf rt-stps-server.conf
fi

cd ../..

echo "done."
