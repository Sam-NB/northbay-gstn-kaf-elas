from __future__ import absolute_import

from kafka.producer.kafka import KafkaProducer

__all__ = [
    'KafkaProducer'
]
